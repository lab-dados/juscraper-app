"""
Orchestrates the flow for DATAJUD (user entry point) - API BASED
"""
import logging
import tempfile
import time
import warnings
from collections import defaultdict
from typing import Any

import pandas as pd
from pydantic import ValidationError
from tqdm.auto import tqdm

from ...core.http import HTTPScraper
from ...utils.cnj import clean_cnj  # Assuming this utility exists and is relevant
from ...utils.params import normalize_paginas, pop_deprecated_alias, raise_on_extra_kwargs
from .download import build_contar_processos_payload, build_listar_processos_payload, call_datajud_api

# Import mappings for tribunal and justice aliases.
from .mappings import ID_JUSTICA_TRIBUNAL_TO_ALIAS, TIPOS_MOVIMENTACAO, TRIBUNAL_TO_ALIAS
from .parse import parse_datajud_api_response  # To be created for API response parsing
from .schemas import InputContarProcessosDataJud, InputListarProcessosDataJud

# Mapping inverso pra rotular o DataFrame devolvido por ``contar_processos``
# com a sigla do tribunal (não só o alias-índice do Elasticsearch).
ALIAS_TO_TRIBUNAL = {alias: sigla for sigla, alias in TRIBUNAL_TO_ALIAS.items()}

logger = logging.getLogger(__name__)


def _pop_plural_aliases(kwargs: dict) -> None:
    """Popa aliases plurais deprecados antes de instanciar o schema.

    Refs #232 — singular canonico (``assunto``); ``assuntos`` (plural) emite
    :class:`DeprecationWarning` e segue funcionando. Passar plural + singular
    juntos -> :class:`ValueError` (uso conflitante).
    """
    if "assuntos" not in kwargs:
        return
    if kwargs.get("assunto") is not None:
        kwargs.pop("assuntos")
        raise ValueError(
            "Nao e possivel passar 'assunto' e 'assuntos' simultaneamente."
        )
    kwargs["assunto"] = pop_deprecated_alias(kwargs, "assuntos", "assunto")


class DatajudScraper(HTTPScraper):
    """Scraper for CNJ's Datajud API.

    Note:
        Diferente de outros agregadores migrados em #204, o DataJud nao usa
        ``self._request_with_retry`` no caminho quente: a funcao
        :func:`download.call_datajud_api` aplica um retry especializado
        (504/Timeout -> refaz **1 vez** com ``size`` reduzido por
        ``FALLBACK_DIVISOR``), incompativel com o backoff exponencial do
        ``HTTPScraper``. A heranca aqui garante session/headers
        compartilhados e o cumprimento de #185, mas o transporte segue via
        :func:`call_datajud_api`.
    """

    # Chave pública oficial da API Pública do Datajud (CNJ): documentada e
    # idêntica para todos os usuários — não é um segredo vazado.
    DEFAULT_API_KEY = "cDZHYzlZa0JadVREZDJCendQbXY6SkJlTzNjLV9TRENyQk1RdnFKZGRQdw=="
    BASE_API_URL = "https://api-publica.datajud.cnj.jus.br"

    # Schema pydantic detectado por ``tests/schemas/test_signature_parity._is_wired``.
    INPUT_LISTAR_PROCESSOS = InputListarProcessosDataJud

    def __init__(
        self,
        api_key: str | None = None,
        verbose: int = 1,
        download_path: str | None = None,  # For temporary files if needed
        sleep_time: float = 0.5,
    ):
        # Preserva o prefix historico ``datajud_api_`` para download_path
        # default. ``set_download_path`` (em ``BaseScraper``) usa
        # ``tempfile.mkdtemp()`` sem prefix, entao resolvemos aqui antes
        # de delegar ao ``HTTPScraper``.
        resolved_path = download_path or tempfile.mkdtemp(prefix="datajud_api_")
        super().__init__(
            "DatajudAPI",
            verbose=verbose,
            download_path=resolved_path,
            sleep_time=sleep_time,
        )
        self.api_key = api_key or self.DEFAULT_API_KEY
        logger.info(
            "DatajudScraper initialized. API Key: %s. Temp path: %s",
            "Provided" if api_key else "Default",
            self.download_path,
        )

    def contar_processos(self, **kwargs) -> pd.DataFrame:
        """Conta processos no DataJud sem baixar nenhum documento.

        Útil para análise de viabilidade — antes de uma raspagem grande,
        descobrir o volume estimado por tribunal. Usa ``track_total_hits=True``
        com ``size=0`` (cap do Elasticsearch é 10000 quando ``track_total_hits``
        é ``True`` apenas via flag boolean — aqui exigimos a contagem exata,
        então o backend devolve ``relation="eq"`` quando o total é conhecido).

        Aceita o **mesmo conjunto de filtros** de :meth:`listar_processos`
        (``tribunal``, ``numero_processo``, ``ano_ajuizamento``, ``classe``,
        ``assunto``, ``data_ajuizamento_inicio``/``_fim``,
        ``tipos_movimentacao``, ``movimentos_codigo``, ``orgao_julgador``,
        ``query``), excluindo apenas os parametros de paginacao
        (``paginas``, ``tamanho_pagina``, ``mostrar_movs``) — nao ha
        paginacao numa contagem. Veja a docstring de
        :meth:`listar_processos` para a semantica de cada filtro
        (formato dual ISO+compacto em ``dataAjuizamento``, mapping
        amigavel de ``tipos_movimentacao``, escape-hatch ``query``).

        Args:
            **kwargs: Filtros aceitos pelo schema
                :class:`InputContarProcessosDataJud`.

        Returns:
            pd.DataFrame: Uma linha por tribunal consultado, com colunas
            ``tribunal`` (sigla), ``alias`` (índice ES), ``count`` (int) e
            ``relation`` (``"eq"`` exato ou ``"gte"`` truncado pelo cap
            interno do Elasticsearch). Quando a chamada falha para um
            tribunal, ``count`` é ``None`` e a coluna ``error`` traz o
            motivo.

        Raises:
            TypeError: Quando um kwarg desconhecido é passado.
            ValidationError: Quando um filtro tem formato inválido (ex.:
                ``data_ajuizamento_*`` fora de ISO 8601), quando
                ``ano_ajuizamento`` coexiste com ``data_ajuizamento_*``,
                quando ``query`` coexiste com filtros amigaveis, ou
                quando um nome em ``tipos_movimentacao`` nao esta mapeado.
            ValueError: Quando nem ``tribunal`` nem ``numero_processo``
                são informados, ou quando a sigla não tem alias mapeado.

        Exemplo:
            >>> import juscraper as jus
            >>> dj = jus.scraper("datajud")
            >>> dj.contar_processos(tribunal="TJSP", ano_ajuizamento=2023, classe="436")
              tribunal             alias  count relation error
            0     TJSP  api_publica_tjsp  12345       eq   None

            >>> # Range de data ajuizamento + categoria de movimentacao
            >>> dj.contar_processos(
            ...     tribunal="TRF1",
            ...     data_ajuizamento_inicio="2024-01-01",
            ...     data_ajuizamento_fim="2024-03-31",
            ...     tipos_movimentacao=["decisao"],
            ... )

        See also:
            :meth:`listar_processos` — usa o mesmo conjunto de filtros mas
            baixa os processos.
        """
        _pop_plural_aliases(kwargs)
        try:
            inp = InputContarProcessosDataJud(**kwargs)
        except ValidationError as exc:
            raise_on_extra_kwargs(exc, "DatajudScraper.contar_processos()")
            raise

        target_aliases = self._resolve_aliases(
            tribunal=inp.tribunal,
            numero_processo=inp.numero_processo,
        )

        # ``tipos_movimentacao`` (nomes amigaveis) -> codigos TPU; uniao com
        # ``movimentos_codigo`` direto. Mesma logica de ``listar_processos``.
        movimentos_codigo: list[int] | None = None
        if inp.tipos_movimentacao or inp.movimentos_codigo:
            codigos: list[int] = []
            for tipo in inp.tipos_movimentacao or []:
                codigos.extend(TIPOS_MOVIMENTACAO.get(tipo, []))
            codigos.extend(inp.movimentos_codigo or [])
            movimentos_codigo = list(dict.fromkeys(codigos))

        # ``_resolve_aliases`` devolve uma list[(alias, cnjs_pra_esse_alias)]
        # — segue o mesmo padrão do ``listar_processos`` para que ``numero_processo``
        # cruzando vários tribunais funcione (cada tribunal recebe só os seus CNJs).
        rows: list[dict[str, Any]] = []
        for alias, cnjs in target_aliases:
            payload = build_contar_processos_payload(
                numero_processo=cnjs,
                ano_ajuizamento=inp.ano_ajuizamento,
                classe=inp.classe,
                assunto=inp.assunto,
                data_ajuizamento_inicio=inp.data_ajuizamento_inicio,
                data_ajuizamento_fim=inp.data_ajuizamento_fim,
                movimentos_codigo=movimentos_codigo,
                orgao_julgador=inp.orgao_julgador,
                query=inp.query,
            )
            api_response = call_datajud_api(
                base_url=self.BASE_API_URL,
                alias=alias,
                api_key=self.api_key,
                session=self.session,
                query_payload=payload,
                verbose=self.verbose > 1,
            )
            tribunal_sigla = ALIAS_TO_TRIBUNAL.get(alias, "")
            if api_response is None:
                rows.append({
                    "tribunal": tribunal_sigla,
                    "alias": alias,
                    "count": None,
                    "relation": None,
                    "error": "API call failed (see logs)",
                })
                continue
            total = api_response.get("hits", {}).get("total", {}) or {}
            rows.append({
                "tribunal": tribunal_sigla,
                "alias": alias,
                "count": int(total.get("value") or 0),
                "relation": total.get("relation", "eq"),
                "error": None,
            })
            time.sleep(self.sleep_time)
        return pd.DataFrame(rows)

    def _resolve_aliases(
        self,
        *,
        tribunal: str | None,
        numero_processo: str | list[str] | None,
    ) -> list[tuple]:
        """Determina lista de ``(alias, cnjs_para_esse_alias)``.

        Mesma lógica usada por :meth:`listar_processos` — extraída pra ser
        reutilizada por :meth:`contar_processos` sem duplicar código.
        """
        if tribunal:
            alias = TRIBUNAL_TO_ALIAS.get(tribunal.upper())
            if not alias:
                raise ValueError(
                    f"Tribunal {tribunal!r} não encontrado nos mappings do DataJud. "
                    f"Verifique a sigla (ex: TJSP, TRT2, TRE-SP)."
                )
            cnjs: str | list[str] | None = numero_processo
            return [(alias, cnjs)]
        if numero_processo:
            processos_por_alias = defaultdict(list)
            cnjs_to_query = (
                [numero_processo] if isinstance(numero_processo, str) else numero_processo
            )
            for num_cnj in cnjs_to_query:
                num_limpo = clean_cnj(num_cnj)
                if len(num_limpo) == 20:
                    id_justica = num_limpo[13]
                    id_tribunal = num_limpo[14:16]
                    alias = ID_JUSTICA_TRIBUNAL_TO_ALIAS.get((id_justica, id_tribunal))
                    if alias:
                        processos_por_alias[alias].append(num_limpo)
                    else:
                        warnings.warn(
                            f"CNJ {num_cnj!r}: tribunal não mapeado no DataJud "
                            f"(id_justica={id_justica}, id_tribunal={id_tribunal}). "
                            f"Processo será ignorado.",
                            UserWarning,
                            stacklevel=2,
                        )
                else:
                    warnings.warn(
                        f"CNJ inválido: {num_cnj!r} (após limpeza tem {len(num_limpo)} "
                        f"dígitos, deveria ter 20). Processo será ignorado.",
                        UserWarning,
                        stacklevel=2,
                    )
            if not processos_por_alias:
                return []
            return list(processos_por_alias.items())
        raise ValueError(
            "É necessário especificar 'tribunal' (sigla) ou 'numero_processo' (CNJ)."
        )

    def listar_processos(
        self,
        paginas: int | list[int] | range | None = None,
        **kwargs,
    ) -> pd.DataFrame:
        """Lista processos do DataJud via API publica do CNJ.

        Filtros sao validados pelo schema :class:`InputListarProcessosDataJud`
        (``extra="forbid"``); kwargs desconhecidos viram ``TypeError`` com a
        mensagem ``DatajudScraper.listar_processos() got unexpected keyword
        argument(s): '<nome>'`` em vez de serem silenciosamente ignorados.

        Args:
            **kwargs: Filtros aceitos pelo schema
                :class:`InputListarProcessosDataJud`. Listados abaixo (todos
                opcionais; ``None`` = sem filtro):

                * ``numero_processo`` (str | list[str]): CNJ formatado ou
                  lista de CNJs. Quando informado sem ``tribunal``, o alias-
                  indice e inferido pelos digitos ``id_justica`` (pos. 14) +
                  ``id_tribunal`` (pos. 15-16). CNJs invalidos ou nao
                  mapeados emitem ``UserWarning`` e sao ignorados.
                * ``tribunal`` (str): Sigla do tribunal (ex.: ``"TJSP"``,
                  ``"TRT2"``, ``"TRE-SP"``). Mutuamente exclusivo com
                  inferencia via ``numero_processo``.
                * ``ano_ajuizamento`` (int): Filtra por ano de ajuizamento.
                  Backend recebe ``range`` dual em ``dataAjuizamento`` (ISO
                  ``YYYY-01-01`` + compacto ``YYYYMMDDhhmmss``). Mutuamente
                  exclusivo com ``data_ajuizamento_inicio``/``_fim``.
                * ``data_ajuizamento_inicio`` / ``data_ajuizamento_fim`` (str):
                  Range de data de ajuizamento, formato ``YYYY-MM-DD`` (ISO
                  8601). Backend recebe ``bool.should`` com 2 ``range`` em
                  ``dataAjuizamento`` (ISO + compacto), mesmo padrao dual-
                  format do ``ano_ajuizamento`` (refs #51). Pode informar
                  apenas inicio, apenas fim, ou ambos. **Nao** ha alias
                  ``data_inicio``/``data_fim`` aqui (a convencao generica
                  do projeto mapeia esses para ``data_julgamento_*``, e o
                  DataJud filtra por ajuizamento, nao julgamento).
                * ``classe`` (str): Codigo da classe processual CNJ.
                * ``assunto`` (list[str | int]): Lista de codigos de
                  assuntos CNJ (TPU). Aceita int e str — int e a forma
                  natural (codigos TPU sao inteiros); str e aceita por
                  compatibilidade. O schema normaliza para str antes do
                  payload, ja que o Elasticsearch coage int -> str em
                  campos ``keyword``. Backend: ``terms`` em
                  ``assuntos.codigo``. ``assuntos`` (plural) e aceito como
                  alias deprecado. Refs #232.
                * ``tipos_movimentacao`` (list[str]): Nomes amigaveis de
                  categorias de movimentacao (ex.: ``["decisao", "sentenca"]``).
                  Resolvidos via ``TIPOS_MOVIMENTACAO`` para uma lista plana
                  de codigos TPU CNJ. Para nomes nao mapeados, usar
                  ``movimentos_codigo`` direto. Categorias atuais:
                  ``decisao``, ``sentenca``, ``julgamento``, ``tutela``,
                  ``transito_julgado``.
                * ``movimentos_codigo`` (list[int | str]): Codigos TPU
                  CNJ diretos. Aceita int e str — int e a forma natural;
                  str e aceita por conveniencia (ex.: vinda de planilha/
                  CSV) e normalizada para int antes do payload.
                  Concatenado com a lista resolvida de
                  ``tipos_movimentacao`` (uniao). Backend: ``terms`` em
                  ``movimentos.codigo``.
                * ``orgao_julgador`` (str): Nome do orgao julgador (ex.:
                  ``"Vara Civel de Brasilia"``). Backend: ``match`` em
                  ``orgaoJulgador.nome``.
                * ``query`` (dict): **Override total** da query Elasticsearch.
                  Quando fornecido, vira a chave ``query`` do payload
                  literalmente. Mutuamente exclusivo com TODOS os filtros
                  amigaveis acima (``numero_processo``, ``ano_ajuizamento``,
                  ``classe``, ``assunto``, ``data_ajuizamento_*``,
                  ``tipos_movimentacao``, ``movimentos_codigo``,
                  ``orgao_julgador``). Exige ``tribunal`` explicito (sem
                  inferencia via CNJ). Em troca, oferece paridade com
                  requisicao direta a ``/<alias>/_search`` —
                  ``must_not``, ``should`` com ``minimum_should_match``,
                  ``range`` em campos arbitrarios, ``wildcard``, ``nested``,
                  etc. ``size``/``sort``/``_source``/``search_after`` (paginacao)
                  continuam sendo controlados pela biblioteca. Shape oficial
                  documentado em https://datajud-wiki.cnj.jus.br/api-publica/.
                * ``mostrar_movs`` (bool): Se ``True``, inclui
                  ``movimentos``/``movimentacoes`` no ``_source``. Default
                  ``False`` (paginacao mais leve).
                * ``paginas`` (int | list[int] | range): Intervalo 1-based.
                  Aceita as 4 formas do contrato unico (refs #118):
                  ``int`` (``3`` -> ``range(1, 4)``), ``list``
                  (``[3, 5]`` -> ``range(3, 6)``, baixa 3-5 contiguamente
                  porque o cursor ``search_after`` e forwards-only),
                  ``range`` (passthrough), ``None`` (default, todas).
                * ``tamanho_pagina`` (int): Hits por requisicao (default
                  5000, range 10-10000 conforme cap da API publica). Em
                  caso de ``HTTP 504``/``Timeout``, o client refaz a
                  chamada com ``size // 4`` automaticamente (1 retry,
                  ``UserWarning``); ainda assim, valores proximos de
                  10000 sao instaveis na pratica.

        Aliases deprecados:
            Sem aliases nesta API — DataJud nao tem ``pesquisa`` nem
            filtros de data baseados em ``DD/MM/AAAA``, entao o
            pipeline canonico ``normalize_pesquisa``/``normalize_datas``
            nao se aplica. Todos os filtros aceitam apenas o nome
            canonico listado acima.

        Raises:
            TypeError: Quando um kwarg desconhecido e passado (traduzido de
                ``ValidationError`` por ``raise_on_extra_kwargs``).
            ValidationError: Quando um filtro tem formato invalido (ex.:
                ``ano_ajuizamento`` nao-int, ``data_ajuizamento_*`` fora de
                ISO 8601), quando ``ano_ajuizamento`` coexiste com
                ``data_ajuizamento_*``, quando ``query`` coexiste com
                filtros amigaveis, ou quando um nome em ``tipos_movimentacao``
                nao esta mapeado.
            ValueError: Quando nem ``tribunal`` nem ``numero_processo`` sao
                informados, ou quando a sigla nao tem alias mapeado.

        Returns:
            pd.DataFrame: Um DataFrame com uma linha por processo. ``extra``
            do parser e passthrough do ``_source`` Elasticsearch — colunas
            seguem nomenclatura camelCase do CNJ.

        Exemplo:
            >>> import juscraper as jus
            >>> dj = jus.scraper("datajud")
            >>> # Caminho amigavel: range de data + categoria de movimentacao
            >>> df = dj.listar_processos(
            ...     tribunal="TRF1",
            ...     data_ajuizamento_inicio="2024-01-01",
            ...     data_ajuizamento_fim="2024-03-31",
            ...     tipos_movimentacao=["decisao", "sentenca"],
            ...     paginas=range(1, 3),
            ... )
            >>> # Caminho query-override: paridade com requisicao direta
            >>> df = dj.listar_processos(
            ...     tribunal="TRF1",
            ...     query={
            ...         "bool": {
            ...             "must_not": [{"exists": {"field": "orgaoJulgador.nome"}}],
            ...             "should": [{"match": {"classe.nome": "tutela"}}],
            ...             "minimum_should_match": 1,
            ...         }
            ...     },
            ...     paginas=1,
            ... )

        See also:
            :class:`InputListarProcessosDataJud` — fonte da verdade dos
            filtros aceitos.
        """
        # ``paginas`` e int|list|range|None na API publica (contrato de
        # PaginasMixin). O cursor ``search_after`` da API DataJud e
        # forwards-only e o client interno consome ``.start``/``.stop``,
        # entao convertemos ``int``/``list`` para ``range`` contiguo aqui:
        # ``[3, 5]`` -> ``range(3, 6)`` baixa as paginas 3, 4 e 5.
        paginas_norm = normalize_paginas(paginas)
        if isinstance(paginas_norm, list):
            paginas_norm = (
                range(min(paginas_norm), max(paginas_norm) + 1)
                if paginas_norm
                else None
            )

        _pop_plural_aliases(kwargs)
        try:
            inp = InputListarProcessosDataJud(paginas=paginas_norm, **kwargs)
        except ValidationError as exc:
            raise_on_extra_kwargs(exc, "DatajudScraper.listar_processos()")
            raise

        numero_processo = inp.numero_processo
        tribunal = inp.tribunal
        ano_ajuizamento = inp.ano_ajuizamento
        classe = inp.classe
        assunto = inp.assunto
        data_ajuizamento_inicio = inp.data_ajuizamento_inicio
        data_ajuizamento_fim = inp.data_ajuizamento_fim
        orgao_julgador = inp.orgao_julgador
        query_override = inp.query
        mostrar_movs = inp.mostrar_movs
        tamanho_pagina = inp.tamanho_pagina

        # Resolve ``tipos_movimentacao`` (nomes amigaveis) -> codigos TPU e
        # concatena com ``movimentos_codigo`` direto. O builder em download.py
        # recebe so a lista plana — mantemos o mapping numa unica camada.
        # Schema garantiu que cada nome em ``tipos_movimentacao`` esta em
        # ``TIPOS_MOVIMENTACAO``, entao o ``[]`` de fallback aqui e defesa.
        movimentos_codigo: list[int] | None = None
        if inp.tipos_movimentacao or inp.movimentos_codigo:
            codigos: list[int] = []
            for tipo in inp.tipos_movimentacao or []:
                codigos.extend(TIPOS_MOVIMENTACAO.get(tipo, []))
            codigos.extend(inp.movimentos_codigo or [])
            # Dedup mantendo ordem (uniao das duas fontes).
            movimentos_codigo = list(dict.fromkeys(codigos))

        all_dfs = []
        # Determine target aliases
        target_aliases = []
        if tribunal:
            alias = TRIBUNAL_TO_ALIAS.get(tribunal.upper())
            if alias:
                target_aliases.append(alias)
            else:
                raise ValueError(
                    f"Tribunal {tribunal!r} não encontrado nos mappings do DataJud. "
                    f"Verifique a sigla (ex: TJSP, TRT2, TRE-SP)."
                )
        elif numero_processo:
            # Group by alias if multiple CNJs from different tribunals are provided
            processos_por_alias = defaultdict(list)
            cnjs_to_query = [numero_processo] if isinstance(numero_processo, str) else numero_processo
            for num_cnj in cnjs_to_query:
                num_limpo = clean_cnj(num_cnj)
                if len(num_limpo) == 20:
                    id_justica_cnj = num_limpo[13]
                    id_tribunal_cnj = num_limpo[14:16]
                    alias = ID_JUSTICA_TRIBUNAL_TO_ALIAS.get((id_justica_cnj, id_tribunal_cnj))
                    if alias:
                        processos_por_alias[alias].append(num_limpo)
                    else:
                        warnings.warn(
                            f"CNJ {num_cnj!r}: tribunal não mapeado no DataJud "
                            f"(id_justica={id_justica_cnj}, id_tribunal={id_tribunal_cnj}). "
                            f"Processo será ignorado.",
                            UserWarning,
                            stacklevel=2,
                        )
                        logger.warning("Não foi possível determinar alias para CNJ: %s", num_cnj)
                else:
                    warnings.warn(
                        f"CNJ inválido: {num_cnj!r} (após limpeza tem {len(num_limpo)} "
                        f"dígitos, deveria ter 20). Processo será ignorado.",
                        UserWarning,
                        stacklevel=2,
                    )
                    logger.warning("CNJ inválido: %s", num_cnj)
            if not processos_por_alias:
                # Os warnings por CNJ (CNJ inválido / tribunal não mapeado) já
                # comunicam o problema. O `logger.error` mantém o registro de
                # que nenhum alias foi determinado sem duplicar o warning.
                logger.error("Nenhum CNJ válido para determinar tribunal/alias.")
                return pd.DataFrame()
            target_aliases = list(processos_por_alias.keys())
        else:
            raise ValueError(
                "É necessário especificar 'tribunal' (sigla) ou 'numero_processo' (CNJ)."
            )

        for alias_idx, alias_name in enumerate(target_aliases):
            logger.info("Consultando: %s (%d/%d)", alias_name, alias_idx+1, len(target_aliases))
            # If CNJs were grouped, use only the CNJs for this specific alias
            current_cnjs_for_alias: str | list[str] | None
            if numero_processo and not tribunal:
                current_cnjs_for_alias = processos_por_alias[alias_name]
            else:
                current_cnjs_for_alias = numero_processo
            df_alias = self._listar_processos_por_alias(
                alias=alias_name,
                numero_processo=current_cnjs_for_alias,
                ano_ajuizamento=ano_ajuizamento,
                classe=classe,
                assunto=assunto,
                data_ajuizamento_inicio=data_ajuizamento_inicio,
                data_ajuizamento_fim=data_ajuizamento_fim,
                movimentos_codigo=movimentos_codigo,
                orgao_julgador=orgao_julgador,
                query_override=query_override,
                mostrar_movs=mostrar_movs,
                paginas_range=paginas_norm,
                tamanho_pagina=tamanho_pagina,
            )
            if not df_alias.empty:
                all_dfs.append(df_alias)

        if not all_dfs:
            return pd.DataFrame()
        return pd.concat(all_dfs, ignore_index=True)

    def _listar_processos_por_alias(
        self,
        alias: str,
        numero_processo: str | list[str] | None,
        ano_ajuizamento: int | None,
        classe: str | None,
        assunto: list[str] | None,
        data_ajuizamento_inicio: str | None,
        data_ajuizamento_fim: str | None,
        movimentos_codigo: list[int] | None,
        orgao_julgador: str | None,
        query_override: dict | None,
        mostrar_movs: bool,
        paginas_range: range | None,
        tamanho_pagina: int,
    ) -> pd.DataFrame:
        """Helper to fetch and parse data for a single alias with pagination."""
        dfs_alias = []
        current_page = paginas_range.start if paginas_range else 1
        end_page = paginas_range.stop if paginas_range else float('inf')
        search_after_params: list[Any] | None = None  # For deep pagination

        # Initialize tqdm progress bar
        if paginas_range:
            total_pages_to_fetch = paginas_range.stop - paginas_range.start
            # Disable pbar if no pages are to be fetched based on range
            pbar_disabled = total_pages_to_fetch <= 0
            pbar = tqdm(
                total=total_pages_to_fetch,
                desc=f"Paginando {alias}",
                unit=" página",
                disable=pbar_disabled
            )
        else:
            # If paginas_range is None, total is unknown
            pbar = tqdm(desc=f"Paginando {alias}", unit=" página")

        try:
            while current_page < end_page:
                logger.info("Fetching page %d for alias %s...", current_page, alias)
                query_payload = build_listar_processos_payload(
                    numero_processo=numero_processo,
                    ano_ajuizamento=ano_ajuizamento,
                    classe=classe,
                    assunto=assunto,
                    data_ajuizamento_inicio=data_ajuizamento_inicio,
                    data_ajuizamento_fim=data_ajuizamento_fim,
                    movimentos_codigo=movimentos_codigo,
                    orgao_julgador=orgao_julgador,
                    query=query_override,
                    mostrar_movs=mostrar_movs,
                    tamanho_pagina=tamanho_pagina,
                    search_after=search_after_params,
                )
                api_response_json = call_datajud_api(
                    base_url=self.BASE_API_URL,
                    alias=alias,
                    api_key=self.api_key,
                    session=self.session,
                    query_payload=query_payload,
                    verbose=self.verbose > 1  # Pass verbose flag for more detailed logging
                )

                if api_response_json is None:
                    warnings.warn(
                        f"DataJud: falha ao consultar alias {alias!r} na página "
                        f"{current_page}. Resultados parciais retornados.",
                        UserWarning,
                        stacklevel=3,
                    )
                    logger.error(
                        "Failed to get API response for alias %s, page %d."
                        "Stopping.",
                        alias,
                        current_page
                    )
                    break

                if current_page == (paginas_range.start if paginas_range else 1):
                    total_info = api_response_json.get("hits", {}).get("total", {})
                    total_value = total_info.get("value", "?")
                    total_relation = total_info.get("relation", "eq")
                    logger.info("Total de processos encontrados para %s: %s (%s)", alias, total_value, total_relation)

                df_page = parse_datajud_api_response(api_response_json, mostrar_movs)
                if df_page.empty:
                    logger.info(
                        "No more results for alias %s on page %d (or parsing failed).",
                        alias,
                        current_page
                    )
                    break
                dfs_alias.append(df_page)
                pbar.update(1)  # Update progress bar

                # For search_after pagination: extract the sort values of the last hit
                # This part depends on the exact structure of api_response_json
                # Assuming api_response_json is a dict parsed from the JSON string
                hits = api_response_json.get("hits", {}).get("hits", [])
                # Quando ``call_datajud_api`` aciona o fallback de 504/timeout,
                # ele muta ``query_payload["size"]`` em place. Propagamos o
                # size efetivo para ``tamanho_pagina`` para que paginas
                # subsequentes ja partam do size reduzido — em gateway
                # saturado consistentemente, isso evita pagar ~60s a cada
                # pagina antes de cair no fallback de novo.
                effective_size = query_payload.get("size", tamanho_pagina)
                if effective_size < tamanho_pagina:
                    tamanho_pagina = effective_size
                if not hits or len(hits) < effective_size:
                    logger.info(
                        "Last page reached for alias %s (less than %d results or no hits).",
                        alias,
                        effective_size,
                    )
                    break
                last_hit = hits[-1]
                search_after_params = last_hit.get("sort")
                if search_after_params is None:
                    logger.warning(
                        "Sort parameters for 'search_after' not found in last hit."
                        "Cannot continue deep pagination."
                    )
                    break  # Fallback or stop if search_after cannot be determined

                if paginas_range is None or current_page < paginas_range.stop - 1:  # if fetching all, continue
                    current_page += 1
                else:  # reached end of specified range
                    break
                time.sleep(self.sleep_time)  # Respect sleep time
        finally:
            pbar.close()  # Ensure progress bar is closed

        if not dfs_alias:
            return pd.DataFrame()
        return pd.concat(dfs_alias, ignore_index=True)
