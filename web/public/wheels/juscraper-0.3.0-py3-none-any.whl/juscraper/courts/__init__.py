"""Per-tribunal scraper packages."""
