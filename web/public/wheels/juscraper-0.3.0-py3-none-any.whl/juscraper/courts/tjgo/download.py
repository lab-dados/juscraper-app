"""HTTP-level helpers for the TJGO jurisprudence search."""
from __future__ import annotations

import logging
import math
import re
import time

from juscraper.core.http import RequestFn
from juscraper.utils.pagination import extract_count_with_cascade

logger = logging.getLogger("juscraper.tjgo")

SEARCH_URL = "https://projudi.tjgo.jus.br/ConsultaJurisprudencia"
RESULTS_PER_PAGE = 10

_PAGINATION_CSS_SELECTORS: tuple[str, ...] = ("legend.formLocalizarLegenda",)
_PAGINATION_REGEXES: tuple[re.Pattern[str], ...] = (
    re.compile(r"(\d[\d\.]*)\s*resultados?\s+encontrados?", re.IGNORECASE),
    re.compile(r"(\d[\d\.]*)\s*resultados?", re.IGNORECASE),
)


def build_cjsg_payload(
    pesquisa: str,
    page: int = 1,
    *,
    id_instancia: str | int = "0",
    id_area: str | int = "0",
    id_serventia_subtipo: str | int = "0",
    numero_processo: str = "",
    data_publicacao_inicio: str = "",
    data_publicacao_fim: str = "",
    qtde_itens_pagina: int = RESULTS_PER_PAGE,
) -> dict:
    """Build the form-encoded body for the TJGO Projudi search endpoint.

    ``page`` is 1-based; the backend uses a 0-based ``PosicaoPaginaAtual``
    offset, which this helper computes. ``cf-turnstile-response`` is sent
    empty: the widget exists on the page but the backend does not validate
    the token.
    """
    return {
        "PaginaAtual": "2",
        "PosicaoPaginaAtual": str(page - 1),
        "Viewstate": "",
        "Texto": pesquisa,
        "Id_Instancia": str(id_instancia),
        "Id_Area": str(id_area),
        "Id_ServentiaSubTipo": str(id_serventia_subtipo),
        "Serventia": "",
        "Id_Serventia": "",
        "Usuario": "",
        "Id_Usuario": "",
        "ArquivoTipo": "",
        "Id_ArquivoTipo": "",
        "ProcessoNumero": numero_processo,
        "DataInicial": data_publicacao_inicio,
        "DataFinal": data_publicacao_fim,
        "cf-turnstile-response": "",
        "g-recaptcha-response": "",
        "Localizar": "Consultar",
        "qtdeItensPagina": str(qtde_itens_pagina),
    }


def _extract_total(html: str) -> int:
    n = extract_count_with_cascade(
        html,
        css_selectors=_PAGINATION_CSS_SELECTORS,
        regex_patterns=_PAGINATION_REGEXES,
        fallback_max_int=False,
    )
    return n if n is not None else 0


def _fetch_page(
    request_fn: RequestFn,
    pesquisa: str,
    page: int,
    id_instancia: str,
    id_area: str,
    id_serventia_subtipo: str,
    data_publicacao_inicio: str,
    data_publicacao_fim: str,
    numero_processo: str,
    qtde_itens_pagina: int,
) -> str:
    payload = build_cjsg_payload(
        pesquisa=pesquisa,
        page=page,
        id_instancia=id_instancia,
        id_area=id_area,
        id_serventia_subtipo=id_serventia_subtipo,
        data_publicacao_inicio=data_publicacao_inicio,
        data_publicacao_fim=data_publicacao_fim,
        numero_processo=numero_processo,
        qtde_itens_pagina=qtde_itens_pagina,
    )
    resp = request_fn("POST", SEARCH_URL, data=payload, timeout=90)
    resp.encoding = "iso-8859-1"
    return resp.text


def cjsg_download(
    pesquisa: str,
    paginas,
    *,
    request_fn: RequestFn,
    id_instancia: str,
    id_area: str,
    id_serventia_subtipo: str,
    data_publicacao_inicio: str,
    data_publicacao_fim: str,
    numero_processo: str,
    qtde_itens_pagina: int,
    sleep_time: float,
) -> list:
    """Run a TJGO search and return the raw HTML of each page.

    Args:
        request_fn: HTTP callable que aplica retry + ``raise_for_status``.
            Em uso normal e ``TJGOScraper._request_with_retry`` (via
            ``core.http.HTTPScraper``).
    """
    # Prime the session (cookies) with a GET on the form.
    request_fn("GET", SEARCH_URL, timeout=60)

    first = _fetch_page(
        request_fn=request_fn,
        pesquisa=pesquisa,
        page=1,
        id_instancia=id_instancia,
        id_area=id_area,
        id_serventia_subtipo=id_serventia_subtipo,
        data_publicacao_inicio=data_publicacao_inicio,
        data_publicacao_fim=data_publicacao_fim,
        numero_processo=numero_processo,
        qtde_itens_pagina=qtde_itens_pagina,
    )
    total = _extract_total(first)
    n_pags = max(1, math.ceil(total / qtde_itens_pagina)) if total else 1

    if paginas is None:
        paginas = range(1, n_pags + 1)

    results: list = []
    for pagina in paginas:
        if pagina < 1 or pagina > n_pags:
            logger.warning("TJGO: pagina %s fora do intervalo 1-%s", pagina, n_pags)
            continue
        if pagina == 1:
            results.append(first)
            continue
        time.sleep(sleep_time)
        html = _fetch_page(
            request_fn=request_fn,
            pesquisa=pesquisa,
            page=pagina,
            id_instancia=id_instancia,
            id_area=id_area,
            id_serventia_subtipo=id_serventia_subtipo,
            data_publicacao_inicio=data_publicacao_inicio,
            data_publicacao_fim=data_publicacao_fim,
            numero_processo=numero_processo,
            qtde_itens_pagina=qtde_itens_pagina,
        )
        results.append(html)
    return results
