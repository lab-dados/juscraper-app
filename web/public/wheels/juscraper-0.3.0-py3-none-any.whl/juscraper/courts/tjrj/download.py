"""HTTP-level helpers for the TJRJ jurisprudence search."""
from __future__ import annotations

import logging
import math
import re
import time

from juscraper.core.http import RequestFn

logger = logging.getLogger("juscraper.tjrj")

FORM_URL = "https://www3.tjrj.jus.br/ejuris/ConsultarJurisprudencia.aspx"
RESULT_URL = (
    "https://www3.tjrj.jus.br/EJURIS/ProcessarConsJurisES.aspx"
    "/ExecutarConsultarJurisprudencia"
)
RESULTS_PER_PAGE = 10

_FIELD_PREFIX = "ctl00$ContentPlaceHolder1$"
_BLOCKED_WORDS_FIELD = f"{_FIELD_PREFIX}hfListaPalavrasBloqueadas"

_HIDDEN_RE = re.compile(
    r'<input[^>]*name="(?P<name>__VIEWSTATE|__VIEWSTATEGENERATOR|__EVENTVALIDATION'
    r'|ctl00\$ContentPlaceHolder1\$hfListaPalavrasBloqueadas)"[^>]*value="(?P<value>[^"]*)"',
    re.IGNORECASE,
)

# Bloco <select name="...cmbAnoInicio">...</select> e suas <option value="AAAA">.
_ANO_SELECT_RE = re.compile(
    r'<select[^>]*name="ctl00\$ContentPlaceHolder1\$cmbAnoInicio".*?</select>',
    re.IGNORECASE | re.DOTALL,
)
_ANO_OPTION_RE = re.compile(r'<option[^>]*value="(?P<value>[^"]*)"', re.IGNORECASE)


def extract_viewstate_fields(html: str) -> dict:
    """Extrai os quatro hidden fields exigidos pelo POST ASP.NET do TJRJ.

    Retorna ``__VIEWSTATE``, ``__VIEWSTATEGENERATOR``, ``__EVENTVALIDATION`` e
    ``ctl00$ContentPlaceHolder1$hfListaPalavrasBloqueadas``. Campos ausentes
    sao omitidos do dict — o caller substitui defaults explicitamente.

    O hidden de palavras bloqueadas carrega a stopword list do backend
    (``"A;ACIMA;COM;..."``); o servidor le esse valor de volta para validar o
    termo de busca, e um POST que omite o campo pode disparar 500 Runtime
    Error em janelas onde o backend espera o roundtrip (refs #143, exposto
    em 2026-04-30).
    """
    fields: dict = {}
    for match in _HIDDEN_RE.finditer(html):
        fields[match.group("name")] = match.group("value")
    return fields


def extract_default_year(html: str) -> str:
    r"""Devolve o ano-padrao do form — a primeira ``<option>`` de ``cmbAnoInicio``.

    O backend do TJRJ passou a exigir ``cmbAnoInicio``/``cmbAnoFim`` nao-vazios:
    um POST com ano em branco dispara ``HTTP 500`` ja na submissao do form
    (refs #278). Nenhuma ``<option>`` do dropdown vem marcada com ``selected``,
    entao o ``<select>`` do navegador submete a primeira opcao (a mais nova) —
    o ano corrente. Replicamos esse default em vez de usar ``date.today().year``
    porque o valor parseado e garantidamente uma opcao que o backend aceita
    (``date.today()`` poderia enviar um ano ainda ausente do dropdown na virada
    do ano e cair em erro de validacao).

    Fallback: se o ``<select>`` nao parsear (formato mudou), devolve o maior
    ``\\d{4}`` encontrado no bloco; em ultimo caso, o maior do HTML inteiro.
    Nunca devolve ``""`` — string vazia e exatamente o que provoca o 500.
    """
    block_match = _ANO_SELECT_RE.search(html)
    block = block_match.group(0) if block_match else html
    values = [
        m.group("value")
        for m in _ANO_OPTION_RE.finditer(block)
        if m.group("value").strip()
    ]
    if values:
        return values[0]
    anos = re.findall(r"\b(\d{4})\b", block) or re.findall(r"\b(\d{4})\b", html)
    return str(max(anos)) if anos else ""


def build_cjsg_payload(
    hidden: dict,
    pesquisa: str,
    *,
    ano_inicio: str = "",
    ano_fim: str = "",
    competencia: str = "1",
    origem: str = "1",
    tipo_acordao: bool = True,
    tipo_monocratica: bool = True,
    magistrado_codigo: str | None = None,
    orgao_codigo: str | None = None,
) -> dict:
    """Monta o body URL-encoded para o POST ASPX do TJRJ.

    ``hidden`` carrega os quatro hidden fields devolvidos por
    :func:`extract_viewstate_fields`. ``g-recaptcha-response`` fica vazio
    propositalmente — o widget e decorativo, o backend nao valida o token.
    """
    data = {
        "__EVENTTARGET": f"{_FIELD_PREFIX}btnPesquisar",
        "__EVENTARGUMENT": "",
        "__LASTFOCUS": "",
        "__VIEWSTATE": hidden.get("__VIEWSTATE", ""),
        "__VIEWSTATEGENERATOR": hidden.get("__VIEWSTATEGENERATOR", ""),
        "__EVENTVALIDATION": hidden.get("__EVENTVALIDATION", ""),
        _BLOCKED_WORDS_FIELD: hidden.get(_BLOCKED_WORDS_FIELD, ""),
        f"{_FIELD_PREFIX}hfCodRamos": "",
        f"{_FIELD_PREFIX}hfCodMags": magistrado_codigo or "",
        f"{_FIELD_PREFIX}hfCodOrgs": orgao_codigo or "",
        f"{_FIELD_PREFIX}txtTextoPesq": pesquisa,
        f"{_FIELD_PREFIX}cmbOrigem": origem,
        f"{_FIELD_PREFIX}cmbAnoInicio": ano_inicio,
        f"{_FIELD_PREFIX}cmbAnoFim": ano_fim,
        f"{_FIELD_PREFIX}cmbCompetencia": competencia,
        f"{_FIELD_PREFIX}cmbRamo": "",
        f"{_FIELD_PREFIX}cmbMagistrado": "",
        f"{_FIELD_PREFIX}chkAtivo": "on",
        f"{_FIELD_PREFIX}chkInativo": "on",
        f"{_FIELD_PREFIX}cmbOrgaoJulgador": "",
        f"{_FIELD_PREFIX}cmbTipNumeracao": "1",
        f"{_FIELD_PREFIX}txtNumeracao": "",
        f"{_FIELD_PREFIX}chkIntTeor": "on",
        f"{_FIELD_PREFIX}chkEmentario": "on",
        "g-recaptcha-response": "",
    }
    if tipo_acordao:
        data[f"{_FIELD_PREFIX}chkAcordao"] = "on"
    if tipo_monocratica:
        data[f"{_FIELD_PREFIX}chkDecMon"] = "on"
    return data


def _init_session(
    request_fn: RequestFn,
    pesquisa: str,
    ano_inicio: str | None,
    ano_fim: str | None,
    competencia: str,
    origem: str,
    tipo_acordao: bool,
    tipo_monocratica: bool,
    magistrado_codigo: str | None,
    orgao_codigo: str | None,
) -> None:
    """Submit the search form so the result XHR has a valid server session."""
    resp = request_fn("GET", FORM_URL, timeout=30)
    hidden = extract_viewstate_fields(resp.text)
    # O backend exige cmbAnoInicio/cmbAnoFim nao-vazios (refs #278); quando o
    # usuario nao filtra por ano, replicamos o padrao do site preenchendo ambos
    # com o ano corrente (a opcao default do dropdown). O preenchimento e por
    # campo: passar so um dos dois (ex.: ano_inicio=2020 sem ano_fim) faz o
    # outro virar o ano corrente, resultando num intervalo 2020..ano-corrente.
    default_year = extract_default_year(resp.text)
    data = build_cjsg_payload(
        hidden=hidden,
        pesquisa=pesquisa,
        ano_inicio=ano_inicio or default_year,
        ano_fim=ano_fim or default_year,
        competencia=competencia,
        origem=origem,
        tipo_acordao=tipo_acordao,
        tipo_monocratica=tipo_monocratica,
        magistrado_codigo=magistrado_codigo,
        orgao_codigo=orgao_codigo,
    )
    request_fn("POST", FORM_URL, data=data, allow_redirects=True, timeout=30)


def _fetch_page(request_fn: RequestFn, num_pagina_0: int) -> dict:
    payload = {"numPagina": num_pagina_0, "pageSeq": "0"}
    resp = request_fn(
        "POST",
        RESULT_URL,
        json=payload,
        headers={
            "Content-Type": "application/json; charset=UTF-8",
            "X-Requested-With": "XMLHttpRequest",
        },
        timeout=60,
    )
    resp.encoding = "utf-8"
    data: dict = resp.json().get("d", {})
    return data


def cjsg_download(
    pesquisa: str,
    paginas,
    *,
    request_fn: RequestFn,
    ano_inicio: str | None,
    ano_fim: str | None,
    competencia: str,
    origem: str,
    tipo_acordao: bool,
    tipo_monocratica: bool,
    magistrado_codigo: str | None,
    orgao_codigo: str | None,
    sleep_time: float,
) -> list:
    """Run a TJRJ search and return the raw JSON page payloads.

    Args:
        request_fn: HTTP callable que aplica retry + ``raise_for_status``.
            Em uso normal e ``TJRJScraper._request_with_retry`` (via
            ``core.http.HTTPScraper``).
    """
    _init_session(
        request_fn=request_fn,
        pesquisa=pesquisa,
        ano_inicio=ano_inicio,
        ano_fim=ano_fim,
        competencia=competencia,
        origem=origem,
        tipo_acordao=tipo_acordao,
        tipo_monocratica=tipo_monocratica,
        magistrado_codigo=magistrado_codigo,
        orgao_codigo=orgao_codigo,
    )
    first = _fetch_page(request_fn, 0)
    total = int(first.get("TotalDocs") or 0)
    n_pags = max(1, math.ceil(total / RESULTS_PER_PAGE)) if total else 1

    if paginas is None:
        paginas = range(1, n_pags + 1)

    results: list = []
    for pagina in paginas:
        if pagina < 1 or pagina > n_pags:
            logger.warning("TJRJ: pagina %s fora do intervalo 1-%s", pagina, n_pags)
            continue
        if pagina == 1:
            results.append(first)
            continue
        time.sleep(sleep_time)
        data = _fetch_page(request_fn, pagina - 1)
        results.append(data)
    return results
