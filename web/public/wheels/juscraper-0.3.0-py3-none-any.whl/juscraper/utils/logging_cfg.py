"""Logging configuration for juscraper."""
