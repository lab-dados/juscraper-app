"""Downloads raw results from the TJPI jurisprudence search (HTML scraping)."""
import time
from urllib.parse import parse_qs, urlparse

from bs4 import BeautifulSoup, Tag
from tqdm import tqdm

from juscraper.core.http import RequestFn

BASE_URL = "https://jurisprudencia.tjpi.jus.br/jurisprudences/search"
RESULTS_PER_PAGE = 25


def build_cjsg_params(
    pesquisa: str,
    page: int = 1,
    tipo: str = "",
    relator: str = "",
    classe: str = "",
    orgao: str = "",
    data_min: str = "",
    data_max: str = "",
) -> dict:
    """Build the query-string params dict for the TJPI CJSG search endpoint.

    ``data_min``/``data_max`` are the BFF date filter (ISO ``YYYY-MM-DD``);
    they are wired by ``TJPIScraper.cjsg`` after going through
    ``normalize_datas`` + ``to_iso_date``.
    """
    params = {"q": pesquisa, "page": str(page)}
    if tipo:
        params["tipo"] = tipo
    if relator:
        params["relator"] = relator
    if classe:
        params["classe"] = classe
    if orgao:
        params["orgao"] = orgao
    if data_min:
        params["data_min"] = data_min
    if data_max:
        params["data_max"] = data_max
    return params


_PAGINATOR_SELECTOR = "ul.pagination"
_LAST_PAGE_TEXT = "\u00bb"  # », rótulo do link de última página


def _page_from_last_link(link: Tag) -> int:
    """Lê o ``page=N`` do href de um link ``»``; exige N inteiro >= 1.

    ``isdecimal`` e não ``isdigit``: ``isdigit`` aceita dígitos Unicode como
    ``²``, que ``int()`` recusa com uma mensagem que não diz de onde veio.
    ``page=0`` passaria no teste de dígito e viraria total 0, e o download
    pararia na primeira página sem erro.
    """
    page = parse_qs(urlparse(str(link["href"])).query).get("page", [""])[0]
    if not page.isdecimal() or int(page) < 1:
        raise ValueError(f"TJPI: link de última página sem page=N válido (N >= 1) no href: {link['href']!r}")
    return int(page)


def _last_pages_from_paginator(paginator: Tag) -> set[int]:
    """Lê os totais dos links ``»`` de um paginador.

    O link de última página não tem classe, ``rel`` nem ``aria-label``
    próprios: é um ``a.page-link`` como os numerados, e só o rótulo ``»``
    o distingue. A posição (último ``li``) não serve, porque sem o ``»`` o
    último item passa a ser o ``›``, que aponta para a página seguinte.

    Devolve o conjunto de todos os ``»``, não só o primeiro: dois ``»`` com
    totais diferentes no mesmo paginador caem na mesma checagem de
    discordância de ``_get_total_pages``, em vez de o primeiro vencer.
    """
    totals = {
        _page_from_last_link(link)
        for link in paginator.select("a[href]")
        if link.get_text(strip=True) == _LAST_PAGE_TEXT
    }
    if not totals:
        raise ValueError(
            "TJPI: paginador sem o link de última página (»); "
            "o total de páginas não pode ser determinado sem estimar."
        )
    return totals


def _get_total_pages(html: str) -> int:
    """Extrai o total de páginas da primeira página de resultados.

    O total vem do link ``»`` do paginador, e não do maior ``page=N``: o
    paginador mostra só uma janela de páginas, e sem o ``»`` o maior número
    visível é o fim da janela, não o total. Sem ``ul.pagination`` a busca
    tem uma página só (ou nenhum resultado) e o retorno é 1.

    Vale para a primeira página, a única que ``cjsg_download_manager`` lê.
    O paginador esconde os links que não levam a lugar nenhum: a página 1
    não traz ``«`` nem ``‹``, que aparecem na 2, e pelo mesmo padrão a
    última página deve omitir ``»``. Na página 1, porém, busca de página
    única não tem paginador, então paginador sem ``»`` só ocorre se o
    markup mudou. O TJPI desenha dois paginadores iguais, acima e abaixo
    da lista; todos precisam trazer o ``»`` com o mesmo total.

    Raises:
        ValueError: Paginador sem o link ``»``, ``»`` sem ``page=N`` com
            N >= 1, ou links ``»`` com totais diferentes, no mesmo
            paginador ou entre paginadores.
    """
    paginators = BeautifulSoup(html, "html.parser").select(_PAGINATOR_SELECTOR)
    if not paginators:
        return 1
    totals = set().union(*(_last_pages_from_paginator(paginator) for paginator in paginators))
    if len(totals) > 1:
        raise ValueError(f"TJPI: links de última página discordam do total de páginas: {sorted(totals)}")
    return totals.pop()


def cjsg_download_manager(
    pesquisa: str,
    paginas=None,
    *,
    request_fn: RequestFn,
    sleep_time: float = 1.0,
    **kwargs,
) -> list:
    """Download raw HTML pages from the TJPI jurisprudence search.

    Returns a list of raw HTML strings (one per page).

    Args:
        pesquisa: Search term.
        paginas (list, range, or None): Pages to download (1-based).
        request_fn: HTTP callable that handles retry + raise_for_status — em
            uso normal e ``TJPIScraper._request_with_retry`` (via
            ``core.http.HTTPScraper``), centralizando backoff exponencial
            para 429/5xx.
        sleep_time: Delay (em segundos) entre páginas. Default 1.0; o client
            normalmente passa ``self.sleep_time`` herdado de ``HTTPScraper``.
        **kwargs: Additional filter parameters (tipo, relator, classe, orgao).

    Raises:
        ValueError: Com ``paginas=None``, quando a primeira página traz
            paginador mas não dá para ler dele o total de páginas: falta o
            link de última página (``»``), o ``»`` não tem ``page=N`` com
            N >= 1, ou há links ``»`` com totais diferentes. Nesses casos o
            download para depois da primeira requisição, em vez de estimar.
    """
    def _get_page(pagina_1based: int) -> str:
        params = build_cjsg_params(pesquisa=pesquisa, page=pagina_1based, **kwargs)
        resp = request_fn("GET", BASE_URL, params=params, timeout=30)
        resp.encoding = "utf-8"
        return resp.text

    if paginas is None:
        first = _get_page(1)
        resultados = [first]
        n_pags = _get_total_pages(first)
        if n_pags > 1:
            for pagina in tqdm(range(2, n_pags + 1), desc="Baixando CJSG TJPI"):
                time.sleep(sleep_time)
                resultados.append(_get_page(pagina))
        return resultados

    paginas_iter = list(paginas)
    resultados = []
    for pagina_1based in tqdm(paginas_iter, desc="Baixando CJSG TJPI"):
        if resultados:
            time.sleep(sleep_time)
        resultados.append(_get_page(pagina_1based))
    return resultados
