"""
Downloads processes from the TJSP Consulta de Processos Originarios do Primeiro Grau (CPOSG).
"""
import logging
import time
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import requests
from bs4 import BeautifulSoup
from tqdm import tqdm

from ...utils import safe_path_component
from ...utils.cnj import clean_cnj, format_cnj, split_cnj

logger = logging.getLogger('juscraper.cposg_download')


def cposg_download_html(id_cnj_list, session, u_base, download_path, sleep_time=0.5):
    """
    Downloads the HTML of one or more processes from the CPOSG.
    Returns a list of paths if list, or a single path if string.
    """
    if isinstance(id_cnj_list, str):
        id_cnj_list = [id_cnj_list]
    paths = []
    for id_cnj in tqdm(id_cnj_list, desc="Baixando processos"):
        try:
            path = _cposg_download_html_single(id_cnj, session, u_base, download_path)
        except (OSError, UnicodeDecodeError, ValueError,
                AttributeError, RuntimeError, requests.RequestException) as e:
            logger.error("Erro ao baixar o processo %s: %s", id_cnj, e)
            continue
        paths.append(path)
        time.sleep(sleep_time)
    if not paths:
        raise RuntimeError("Nenhum processo foi baixado com sucesso.")
    return paths if len(paths) > 1 else paths[0]


def _cposg_download_html_single(id_cnj, session, u_base, download_path):
    id_clean = clean_cnj(id_cnj)
    p = split_cnj(id_clean)
    id_format = format_cnj(id_clean)
    u = f"{u_base}cposg/search.do"
    # 1. Acessar página inicial para garantir cookies válidos
    open_url = f"{u_base}cposg/open.do?gateway=true"
    session.get(open_url)
    # 2. Montar parâmetros corretos
    params = {
        'conversationId': '',
        'paginaConsulta': '1',
        'localPesquisa.cdLocal': '-1',
        'cbPesquisa': 'NUMPROC',
        'tipoNuProcesso': 'UNIFICADO',
        'numeroDigitoAnoUnificado': f"{p['num']}-{p['dv']}.{p['ano']}",
        'foroNumeroUnificado': p['orgao'],
        'dePesquisaNuUnificado': id_format,
        'dePesquisa': '',
        'uuidCaptcha': '',
        'pbEnviar': 'Pesquisar'
    }
    r = session.get(u, params=params)
    soup = BeautifulSoup(r.text, 'html.parser')
    # id_clean vem de clean_cnj (so digitos), seguro como componente de path.
    path = f"{download_path}/cposg/{id_clean}"
    if not Path(path).is_dir():
        Path(path).mkdir(parents=True)
    # 3. Tratar tipos de resposta
    # Caso 1: listagem de processos
    if soup.find('div', id='listagemDeProcessos'):
        links = [str(a['href']) for a in soup.select('a.linkProcesso')]
        for link in links:
            codigos = parse_qs(urlparse(link).query).get('processo.codigo', [])
            if not codigos:
                raise RuntimeError(f"Link sem 'processo.codigo': {link}")
            codigo = codigos[0]
            safe_codigo = safe_path_component(codigo, field="processo.codigo")
            show_url = f"{u_base}cposg/show.do?processo.codigo={codigo}"
            r_show = session.get(show_url)
            file_name = Path(path) / f"{id_clean}_cd_processo_{safe_codigo}.html"
            with file_name.open('w', encoding='utf-8') as f:
                f.write(r_show.text)
    # Caso 2: incidentes/modal
    elif soup.find('div', id='modalIncidentes'):
        codigos = [str(i['value']) for i in soup.select('input#processoSelecionado')]
        for codigo in codigos:
            safe_codigo = safe_path_component(codigo, field="processo.codigo")
            show_url = f"{u_base}cposg/show.do?processo.codigo={codigo}"
            r_show = session.get(show_url)
            file_name = Path(path) / f"{id_clean}_cd_processo_{safe_codigo}.html"
            with file_name.open('w', encoding='utf-8') as f:
                f.write(r_show.text)
    # Caso 3: resposta simples — o id vem do input[name=cdProcesso] (nao de
    # processo.codigo como nos casos 1/2), dai field="cdProcesso".
    else:
        codigo_simples: str | None = None
        input_cd = soup.find('input', {'name': 'cdProcesso'})
        if input_cd:
            value = input_cd.get('value')
            codigo_simples = str(value) if value is not None else None
        codigo_part = safe_path_component(codigo_simples, field="cdProcesso") if codigo_simples else "simples"
        file_name = Path(path) / f"{id_clean}_cd_processo_{codigo_part}.html"
        with file_name.open('w', encoding='utf-8') as f:
            f.write(r.text)
    return path


def cposg_download_api(id_cnj_list, session, api_base, download_path, sleep_time=0.5):
    """
    Downloads the JSON of one or more processes from the CPOSG via API.
    """
    if isinstance(id_cnj_list, str):
        id_cnj_list = [id_cnj_list]
    paths = []
    endpoint = 'processo/cposg/search/numproc/'
    for id_cnj in tqdm(id_cnj_list, desc="Baixando processos"):
        id_clean = clean_cnj(id_cnj)
        u = f"{api_base}{endpoint}{id_clean}"
        path = f"{download_path}/cposg/{id_clean}"
        if not Path(path).is_dir():
            Path(path).mkdir(parents=True)
        r = session.get(u)
        if r.status_code != 200:
            raise RuntimeError(f"A consulta à API falhou. Status code {r.status_code}.")
        with Path(f"{path}/{id_clean}.json").open('w', encoding='utf-8') as f:
            f.write(r.text)
        paths.append(path)
        time.sleep(sleep_time)
    return paths if len(paths) > 1 else paths[0]
