"""Client publico do agregador PDPJ.

Wrapper sobre a API ``DATALAKE - API Processos`` do PDPJ
(``https://api-processo-integracao.data-lake.pdpj.jus.br/processo-api/api/v1``).
A autenticacao e via JWT no header ``Authorization: Bearer <token>``.
"""
from __future__ import annotations

import logging
import time
from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass
from functools import partial
from typing import Any, ClassVar, cast

import pandas as pd
import requests
from pydantic import ValidationError

from ...core.auth import validar_jwt
from ...core.failures import (
    COLUNA_MOTIVO_FALHA,
    EXCECOES_DE_FALHA_POR_LINHA,
    MOTIVO_NAO_ENCONTRADO,
    STATUS_CONSULTA_FALHA,
    anotar_falhas_anteriores,
    avisar_falhas,
    e_token_invalido,
    motivo_falha,
)
from ...core.http import HTTPScraper, RequestFn, RequestPolicy
from ...core.parse_utils import clean_document_text
from ...utils.cnj import clean_cnj
from ...utils.pagination import Paginas, maior_pagina, pagina_pedida
from ...utils.params import normalize_paginas, raise_on_extra_kwargs
from .._pdpj_sso import CredencialPdpj, PdpjSsoMixin
from .._pdpj_sso.renovacao import ErroSsoPdpj, anotar_falhas_antes_do_sso
from .download import (
    BASE_URL,
    PERFIL_DOCUMENTO,
    PERFIL_LISTAGEM,
    STATUS_SEM_REGISTRO,
    USER_AGENT,
    ProcessoAusenteError,
    confirmador_de_ausencia,
    e_status,
    fetch_contar,
    fetch_documento_binario,
    fetch_documento_texto,
    fetch_pesquisa,
    fetch_processo_detalhes,
    fetch_processo_documentos,
    fetch_processo_existe,
    fetch_processo_movimentos,
    fetch_processo_partes,
    levantar_parcial_da_pesquisa,
)
from .params import _to_query_params
from .parse import (
    _document_to_row,
    _iter_documents,
    build_documento_rows,
    build_movimento_rows,
    build_parte_rows,
    build_processo_row,
    parse_pesquisa_response,
)
from .schemas import (
    InputAuthGovbrPdpj,
    InputAuthPdpj,
    InputCnjPdpj,
    InputContarPdpj,
    InputDownloadDocumentsPdpj,
    InputPesquisaPdpj,
)

logger = logging.getLogger(__name__)


_ITEM_CONSULTA = "consulta(s) de processo"
_ITEM_DOWNLOAD = "download(s) de documento"

# Status retentáveis dos dois perfis: os do core sem o 403. No PDPJ, com token
# válido, o 403 nega um recurso só (um documento sigiloso, por exemplo), e
# retentar gastaria as tentativas numa resposta que não muda.
_STATUS_RETENTAVEIS = frozenset({429, 500, 502, 503, 504})

# 6 tentativas com base 2.0 esperam 2, 4, 8, 16 e 32 s entre elas, perto do
# retry que o agregador tinha antes da política do core. Menos tentativas
# contariam como instabilidade da API o que antes passava na quarta.
_PERFIS_HTTP: dict[str, RequestPolicy] = {
    PERFIL_LISTAGEM: RequestPolicy(
        timeout=30.0,
        max_retries=6,
        base_backoff=2.0,
        retryable_statuses=_STATUS_RETENTAVEIS,
        retry_on_timeout=True,
    ),
    PERFIL_DOCUMENTO: RequestPolicy(
        timeout=60.0,
        max_retries=6,
        base_backoff=2.0,
        retryable_statuses=_STATUS_RETENTAVEIS,
        retry_on_timeout=True,
    ),
}


def _buscar_conteudo(
    buscar: Callable[..., Any],
    request_fn: RequestFn,
    cnj_limpo: str,
    id_documento: str,
    base_url: str,
) -> tuple[Any, str | None]:
    """Busca texto ou binario; devolve ``(conteudo, None)`` ou ``(None, motivo)``.

    O 401 propaga (ver ``e_token_invalido``). Uma resposta 200 com corpo vazio
    chega como ``""`` ou ``b""`` e não é falha.
    """
    try:
        return buscar(request_fn, cnj_limpo, id_documento, base_url=base_url), None
    except EXCECOES_DE_FALHA_POR_LINHA as exc:
        if e_token_invalido(exc):
            raise
        return None, motivo_falha(exc)


_COLUNAS_CPOPG_VAZIA = (
    "numero_processo",
    "id",
    "sigla_tribunal",
    "segmento_justica",
    "nivel_sigilo",
    "data_atualizacao",
    "detalhes",
)


def _linha_cpopg_vazia(cnj: str, status_consulta: str) -> dict[str, Any]:
    """Linha de ``cpopg`` sem tramitacao: processo ausente ou consulta que falhou."""
    return {"processo": cnj, **dict.fromkeys(_COLUNAS_CPOPG_VAZIA), "status_consulta": status_consulta}


def _linha_processo(cnj: str) -> dict[str, Any]:
    """Linha de falha de movimentos e partes: so o processo, o motivo entra depois."""
    return {"processo": cnj}


def _sem_arquivo(row: dict[str, Any]) -> bool:
    """Diz se a linha declara que o documento não tem arquivo no data lake.

    A API omite ``arquivo`` no documento sem conteúdo e responde 404 ao pedido
    de texto dele. Só a linha com a coluna ``arquivo_id`` (de
    :meth:`PdpjScraper.documentos` ou de ``detalhes`` do :meth:`PdpjScraper.cpopg`)
    diz isso; uma base montada sem a coluna não informa, e o download segue.
    """
    return "arquivo_id" in row and bool(pd.isna(row["arquivo_id"]))


@dataclass(frozen=True)
class _Conteudos:
    """Conteúdos que :meth:`PdpjScraper.download_documents` baixa de cada documento."""

    texto: bool
    binario: bool


def _linha_sem_conteudo(row: dict[str, Any], conteudos: _Conteudos) -> dict[str, Any]:
    """Linha do documento sem arquivo: as colunas pedidas vazias e sem motivo de falha."""
    if conteudos.texto:
        row["texto"] = row["_raw_texto"] = None
    if conteudos.binario:
        row["binario"] = None
    row[COLUNA_MOTIVO_FALHA] = None
    return row


def _ordenar_colunas(rows: list[dict[str, Any]]) -> pd.DataFrame:
    """DataFrame com as colunas das linhas de sucesso primeiro e o motivo por último.

    O pandas ordena as colunas pela chegada, e a linha de falha tem menos
    colunas que a de sucesso: se ela viesse primeiro, as colunas dela
    (``id_documento``, o motivo) passariam na frente das de conteúdo, e a
    ordem dependeria de qual processo falhou. As linhas de sucesso dão a
    ordem, as colunas só da linha de falha vêm depois e o motivo por último.
    """
    df = pd.DataFrame(rows)
    ordem = list(dict.fromkeys(
        coluna
        for row in rows if row[COLUNA_MOTIVO_FALHA] is None
        for coluna in row if coluna != COLUNA_MOTIVO_FALHA
    ))
    ordem += [c for c in df.columns if c not in ordem and c != COLUNA_MOTIVO_FALHA]
    if COLUNA_MOTIVO_FALHA in df.columns:
        ordem.append(COLUNA_MOTIVO_FALHA)
    return df[ordem]


def _linha_documentos(cnj: str) -> dict[str, Any]:
    """Linha de falha de :meth:`PdpjScraper.documentos`.

    Leva ``id_documento`` vazio para que o DataFrame continue aceito por
    ``download_documents`` mesmo quando todos os processos falharam; a linha
    sem id é pulada lá.
    """
    return {"processo": cnj, "id_documento": None}


class PdpjScraper(PdpjSsoMixin, HTTPScraper):
    """Raspador para a API DATALAKE - Processos do PDPJ.

    A API consome JWT do SSO PJe (mesmo provedor do JusBR), entao o uso
    tipico e: obter o token via portal do PDPJ logado, chamar
    :meth:`auth` e usar os endpoints de consulta/download.

    Os metodos por processo (:meth:`cpopg`, :meth:`documentos`,
    :meth:`movimentos`, :meth:`partes` e :meth:`existe` com lista) e
    :meth:`download_documents` devolvem uma linha de falha quando a requisicao
    de um item falha, com o motivo na coluna ``motivo_falha`` (vocabulario em
    :mod:`juscraper.core.failures`) e um ``UserWarning`` agregado ao fim.

    Nos metodos por processo, o processo ausente do data lake sai com o motivo
    ``nao_encontrado``. A API diz isso de duas formas: 404 no endpoint do
    processo, ou 500 no endpoint com 404 na :meth:`pesquisa` por
    ``numeroProcesso``. No primeiro 500 de um processo, o raspador faz essa
    pesquisa, numa tentativa so: com 404, para de retentar; com qualquer outra
    resposta, segue as tentativas do perfil. Assim o processo ausente custa
    duas requisicoes, e nao as seis tentativas do perfil. O 401
    e a falha do SSO ao renovar o token (``ErroSsoPdpj``) interrompem a
    coleta. Metodos sem linha por item (:meth:`existe` com
    ``str``, :meth:`contar` e :meth:`pesquisa`) levantam o erro (na :meth:`pesquisa`,
    depois de pagina pedida ja lida, no ``__cause__`` de um ``ColetaParcialError``).

    As requisicoes usam os perfis ``"listagem"`` e ``"documento"`` de
    :class:`~juscraper.core.http.RequestPolicy`, ajustaveis no construtor com
    ``politica=``.
    """

    perfis_http: ClassVar[Mapping[str, RequestPolicy]] = _PERFIS_HTTP

    BASE_URL = BASE_URL

    INPUT_AUTH = InputAuthPdpj
    INPUT_AUTH_GOVBR = InputAuthGovbrPdpj
    INPUT_CPOPG = InputCnjPdpj
    INPUT_DOCUMENTOS = InputCnjPdpj
    INPUT_MOVIMENTOS = InputCnjPdpj
    INPUT_PARTES = InputCnjPdpj
    INPUT_EXISTE = InputCnjPdpj
    INPUT_PESQUISA = InputPesquisaPdpj
    INPUT_CONTAR = InputContarPdpj
    INPUT_DOWNLOAD_DOCUMENTS = InputDownloadDocumentsPdpj

    def __init__(
        self,
        verbose: int = 0,
        download_path: str | None = None,
        sleep_time: float = 0.5,
        token: str | None = None,
        politica: Mapping[str, Mapping[str, Any]] | None = None,
    ) -> None:
        """Cria o raspador; ``token`` passa por :meth:`auth`.

        Args:
            verbose: Nivel de log.
            download_path: Diretorio de download.
            sleep_time: Pausa entre requisicoes de itens, em segundos.
            token: JWT do SSO da PDPJ, validado por :meth:`auth`. ``None``
                carrega a credencial de ``PDPJ_JWT`` ou do cache de
                :meth:`auth_govbr`; ``""`` e sem nenhuma exigem :meth:`auth`
                antes das consultas.
            politica: Ajustes por campo dos perfis ``"listagem"`` e
                ``"documento"``, como ``{"documento": {"timeout": 20}}``. O
                que nao for passado fica como o raspador declara.

        Raises:
            ValueError: Quando ``politica`` cita perfil ou campo desconhecido
                ou traz valor inválido (``max_retries`` que não é inteiro >= 1,
                ``base_backoff``, ``max_backoff`` ou ``max_retry_after`` que
                não é número positivo e finito, ``expect_json`` que não é
                ``bool``, ``timeout`` que não é ``None``, número positivo e
                finito nem o par ``(conexão, leitura)``), ou quando ``token``
                é inválido ou está expirado.
        """
        super().__init__(
            "pdpj",
            verbose=verbose,
            download_path=download_path,
            sleep_time=sleep_time,
            politica=politica,
        )
        self.token: str | None = None
        if token:
            self.auth(token)
        elif token is None:
            self._carregar_credencial_padrao()

    def _configure_session(self, session: requests.Session) -> None:
        # A API recusa User-Agent que não é de navegador; troca o default do
        # HTTPScraper (``juscraper/<version>``).
        session.headers.update({
            "User-Agent": USER_AGENT,
            "Accept": "application/json, text/plain, */*",
        })

    def auth(self, token: str) -> bool:
        """Define o JWT usado em todas as chamadas autenticadas.

        O token passa por :func:`juscraper.core.auth.validar_jwt`, que recusa
        token malformado ou vencido antes do primeiro uso. O conteudo do JWT
        nao e logado.

        Args:
            token: JWT da PDPJ, sem o prefixo ``Bearer``.

        Returns:
            Sempre ``True``; token recusado levanta ``ValueError``.

        Raises:
            ValueError: Quando o token e malformado ou ja expirou. O token e o
                header anteriores ficam como estavam.
        """
        InputAuthPdpj(token=token)
        validar_jwt(token)
        self._instalar_credencial(CredencialPdpj(token), salvar_renovacao=False)
        if self.verbose:
            logger.info("PDPJ: token JWT aceito.")
        return True

    def _check_auth(self) -> None:
        if not self.token:
            raise RuntimeError(
                "Autenticacao necessaria. Chame auth_govbr() para entrar pelo gov.br, auth(token) "
                "com um JWT ja obtido, ou defina a variavel de ambiente PDPJ_JWT."
            )

    @staticmethod
    def _normalize_cnj_input(id_cnj: str | list[str]) -> list[str]:
        InputCnjPdpj(id_cnj=id_cnj)
        items = [id_cnj] if isinstance(id_cnj, str) else list(id_cnj)
        return [clean_cnj(c) for c in items]

    def _coletar_por_processo(
        self,
        origem: str,
        cnjs: Iterable[str],
        buscar: Callable[..., Any],
        montar: Callable[[Any, str], list[dict[str, Any]]],
        linha_falha: Callable[[str], dict[str, Any]],
    ) -> pd.DataFrame:
        """Uma requisicao por CNJ; a que falha vira linha com ``motivo_falha``.

        ``montar`` transforma a resposta nas linhas do processo e
        ``linha_falha`` da as colunas da linha de um processo cuja requisicao
        falhou. O 401 e a falha do SSO ao renovar o token (``ErroSsoPdpj``)
        interrompem, com as falhas anteriores numa nota do erro;
        exceção fora de ``EXCECOES_DE_FALHA_POR_LINHA`` propaga como veio.
        """
        rows: list[dict[str, Any]] = []
        falhas: list[str] = []
        try:
            for cnj in cnjs:
                rows.extend(self._consultar_processo(cnj, buscar, montar, linha_falha, falhas))
                if self.sleep_time:
                    time.sleep(self.sleep_time)
        except requests.HTTPError as erro:
            anotar_falhas_anteriores(erro, falhas, _ITEM_CONSULTA)
            raise
        except ErroSsoPdpj as erro_sso:
            anotar_falhas_antes_do_sso(erro_sso, falhas, _ITEM_CONSULTA)
            raise
        avisar_falhas(falhas, origem, _ITEM_CONSULTA)
        return _ordenar_colunas(rows)

    def _consultar_processo(
        self,
        cnj: str,
        buscar: Callable[..., Any],
        montar: Callable[[Any, str], list[dict[str, Any]]],
        linha_falha: Callable[[str], dict[str, Any]],
        falhas: list[str],
    ) -> list[dict[str, Any]]:
        """Linhas de um CNJ, ou a linha de falha com o motivo; o 401 propaga.

        O 404 do endpoint e o 500 confirmado por :func:`confirmador_de_ausencia`
        saem ``nao_encontrado``; as demais falhas, pelo vocabulário do core.
        """
        confirmar = confirmador_de_ausencia(self._request_with_retry, cnj, base_url=self.BASE_URL)
        request_fn = partial(self._request_with_retry, on_response=confirmar)
        try:
            data = buscar(request_fn, cnj, base_url=self.BASE_URL)
        except ProcessoAusenteError:
            motivo = MOTIVO_NAO_ENCONTRADO
        except EXCECOES_DE_FALHA_POR_LINHA as exc:
            if e_token_invalido(exc):
                raise
            motivo = MOTIVO_NAO_ENCONTRADO if e_status(exc, STATUS_SEM_REGISTRO) else motivo_falha(exc)
        else:
            return [{**row, COLUNA_MOTIVO_FALHA: None} for row in montar(data, cnj)]
        falhas.append(f"processo {cnj}: {motivo}")
        return [{**linha_falha(cnj), COLUNA_MOTIVO_FALHA: motivo}]

    def existe(self, id_cnj: str | list[str]) -> bool | pd.DataFrame:
        """Checa presenca de processo(s) no Data Lake.

        Args:
            id_cnj: Numero CNJ unico (``str``) ou lista de numeros.

        Returns:
            ``bool`` quando ``id_cnj`` e ``str``; ``pd.DataFrame`` com
                colunas ``processo``, ``existe`` e ``motivo_falha`` quando e
                ``list``. Na lista, o processo cuja consulta falhou sai com
                ``existe=None`` e o motivo, ``nao_encontrado`` no processo ausente
                (ver a classe).

        Raises:
            requests.HTTPError: No 401, e com ``str`` em qualquer erro HTTP.
            ErroSsoPdpj: Quando o SSO do PJe recusa ou não consegue renovar o
                token; na lista, com as falhas anteriores numa nota do erro.
            RetryExhaustedError: Com ``str``, quando a consulta falha.
            requests.Timeout: Com ``str``, quando a consulta falha.
            requests.ConnectionError: Com ``str``, quando a consulta falha.
            InvalidJSONResponseError: Com ``str``, quando a consulta falha ou a resposta nao traz ``true``/``false``.

        See Also:
            :class:`InputCnjPdpj` -- schema pydantic.
        """
        self._check_auth()
        cnjs = self._normalize_cnj_input(id_cnj)
        if isinstance(id_cnj, str):
            return fetch_processo_existe(self._request_with_retry, cnjs[0], base_url=self.BASE_URL)
        return self._coletar_por_processo(
            "PdpjScraper.existe",
            cnjs,
            fetch_processo_existe,
            lambda existe, cnj: [{"processo": cnj, "existe": existe}],
            lambda cnj: {"processo": cnj, "existe": None},
        )

    def cpopg(self, id_cnj: str | list[str]) -> pd.DataFrame:
        """Recupera os detalhes de processo(s) via API ``/processos/{n}``.

        Args:
            id_cnj: Numero CNJ ou lista de numeros.

        Returns:
            DataFrame com uma linha por tramitacao do processo. Colunas
                principais: ``processo`` (CNJ pesquisado, dignos de digito),
                ``numero_processo`` (formatado pela API), ``sigla_tribunal``,
                ``segmento_justica``, ``data_atualizacao``, ``detalhes``
                (dict com a resposta completa) e ``motivo_falha``. A API que
                responde lista vazia gera uma linha com
                ``status_consulta="Nao encontrado"``; a consulta que falha gera
                uma linha com ``status_consulta`` igual a
                :data:`juscraper.core.failures.STATUS_CONSULTA_FALHA` e o motivo.
                O processo ausente do data lake (ver a classe) sai nessa linha,
                com o motivo ``nao_encontrado``.

        Raises:
            requests.HTTPError: No 401 (token ausente, expirado ou invalido),
                com as falhas anteriores numa nota do erro.
            ErroSsoPdpj: Quando o SSO do PJe recusa ou não consegue renovar o
                token no meio do lote. Propaga como o 401, com as falhas
                anteriores numa nota do erro.

        Avisos:
            ``UserWarning``: Quando pelo menos uma consulta falhou.

        See Also:
            :class:`InputCnjPdpj` -- schema pydantic.
        """
        self._check_auth()
        return self._coletar_por_processo(
            "PdpjScraper.cpopg",
            self._normalize_cnj_input(id_cnj),
            fetch_processo_detalhes,
            lambda detalhes, cnj: (
                [build_processo_row(det, cnj) for det in detalhes]
                if detalhes
                else [_linha_cpopg_vazia(cnj, "Nao encontrado")]
            ),
            lambda cnj: _linha_cpopg_vazia(cnj, STATUS_CONSULTA_FALHA),
        )

    def documentos(self, id_cnj: str | list[str]) -> pd.DataFrame:
        """Lista documentos do(s) processo(s) (sem baixar conteudo).

        O processo cuja consulta falha sai numa linha so, com ``processo`` e
        ``motivo_falha`` preenchidos e as demais colunas vazias. O processo
        ausente do data lake sai assim, com ``nao_encontrado``, e nao como lista
        sem documentos. O 401 interrompe; ver :meth:`cpopg`.

        Args:
            id_cnj: Número CNJ ou lista de números, com ou sem formatação.

        Returns:
            Uma linha por documento, com ``processo`` (CNJ pesquisado),
                ``numero_processo`` e os metadados do documento.
        """
        self._check_auth()
        return self._coletar_por_processo(
            "PdpjScraper.documentos",
            self._normalize_cnj_input(id_cnj),
            fetch_processo_documentos,
            build_documento_rows,
            _linha_documentos,
        )

    def movimentos(self, id_cnj: str | list[str]) -> pd.DataFrame:
        """Lista movimentos do(s) processo(s).

        Falha por processo como em :meth:`documentos`.

        Args:
            id_cnj: Número CNJ ou lista de números, com ou sem formatação.

        Returns:
            Uma linha por movimento, com ``processo`` (CNJ pesquisado),
                ``numero_processo``, ``sequencia``, ``data_hora``,
                ``descricao`` e o tipo do movimento.
        """
        self._check_auth()
        return self._coletar_por_processo(
            "PdpjScraper.movimentos",
            self._normalize_cnj_input(id_cnj),
            fetch_processo_movimentos,
            build_movimento_rows,
            _linha_processo,
        )

    def partes(self, id_cnj: str | list[str]) -> pd.DataFrame:
        """Lista partes do(s) processo(s).

        Falha por processo como em :meth:`documentos`.

        Args:
            id_cnj: Número CNJ ou lista de números, com ou sem formatação.

        Returns:
            Uma linha por parte, com ``processo`` (CNJ pesquisado),
                ``numero_processo``, ``polo``, ``tipo_parte``, ``nome`` e o
                documento principal da parte.
        """
        self._check_auth()
        return self._coletar_por_processo(
            "PdpjScraper.partes",
            self._normalize_cnj_input(id_cnj),
            fetch_processo_partes,
            build_parte_rows,
            _linha_processo,
        )

    def pesquisa(
        self,
        paginas: int | list[int] | range | None = None,
        **kwargs: Any,
    ) -> pd.DataFrame:
        """Busca profunda em ``GET /api/v1/processos`` (com paginacao).

        Args:
            paginas: Intervalo 1-based. Aceita ``int`` (``3`` -> primeiras
                3 paginas), ``list``, ``range`` ou ``None`` (todas).
            **kwargs: Filtros aceitos por :class:`InputPesquisaPdpj`, todos
                opcionais (``None`` = sem filtro). Os valores citados vem da
                especificacao publica da API (``/processo-api/v2/api-docs``,
                Swagger v1.7.36); o cliente nao os valida.

                * ``numero_processo`` (str | None): numero do processo
                * ``numero_processo_sintetico`` (str | None): numero sintetico do processo
                * ``id`` (str | None): id interno do processo no Data Lake
                * ``id_fonte_dados_codex`` (str | None): ``idFonteDadosCodex`` do processo, nome da API
                * ``numero_historico`` (str | None): numero historico da tramitacao no STF, como "HC-244185"
                * ``cpf_cnpj_parte`` (str | None): CPF ou CNPJ da parte, com ou sem formatacao
                * ``nome_parte`` (str | None): nome da parte
                * ``outro_nome_parte`` (str | None): outro nome da parte
                * ``polo_parte`` (str | None): "ATIVO" ou "PASSIVO"
                * ``situacao_parte`` (str | None): situacao da parte
                * ``nome_representante`` (str | None): nome do representante
                * ``oab_representante`` (str | None): OABs separadas por virgula, como "GO64656,SP12345"
                * ``href`` (str | None): caminho da pessoa no endpoint ``/pessoas``, como
                  "/pessoas/1fe353ba-98a2-5ba7-889b-324e2e901d09"
                * ``id_classe`` (str | None): codigos numericos separados por virgula
                * ``id_assunto_judicial`` (str | None): ids numericos separados por virgula
                * ``id_orgao_julgador`` (str | list[str] | None): lista vira texto separado por virgula
                * ``instancia`` (str | None): "PRIMEIRO_GRAU"/"SEGUNDO_GRAU"/etc.
                * ``segmento_justica`` (str | None): "JUSTICA_FEDERAL"/"JUSTICA_ESTADUAL"/etc.
                * ``tribunal`` (str | None): siglas separadas por virgula (max 5)
                * ``fase`` (str | None): "CONHECIMENTO", "EXECUÇÃO", "INVÁLIDO", "INVESTIGATÓRIA",
                  "NÃO INFORMADO", "OUTRO" ou "PRÉ-PROCESSUAL"
                * ``situacao_atual`` (str | None): situacao do processo, com os acentos e maiusculas
                  da API, como "Tramitando", "Baixado definitivamente", "Arquivado
                  provisoriamente" ou "Suspenso/sobrestado por Recurso Repetitivo"; a lista
                  completa esta na especificacao
                * ``tipo_operacao`` (str | None): tipo de operacao do processo: "Inserção de
                  processo", "Alteração de documentos", "Alteração de metadados", "Alteração de
                  movimentos", "Alteração de partes", "Exclusão de processo" ou "Identificação
                  de petição inicial"
                * ``data_atualizacao_inicio`` / ``data_atualizacao_fim`` (str | None): atualizacao
                  no Data Lake, no formato ``yyyy-MM-dd'T'HH:mm:ss.SSS``
                * ``data_primeiro_ajuizamento_inicio`` / ``data_primeiro_ajuizamento_fim`` (str | None):
                  primeiro ajuizamento, no mesmo formato
                * ``campo_ordenacao`` (str | None): campo de ordenacao decrescente:
                  "dataHoraUltimoMovimento" (padrao da API), "dataHoraAtualizacao",
                  "dataHoraPrimeiroAjuizamento" ou "dataHoraUltimoAjuizamento"
                * ``itens_por_pagina`` (int): default 100, minimo 1. Vai a API como
                  ``maxElementsSize``, mas a API ignora o valor: a
                  especificacao publica do data lake traz
                  ``maxElementsSize`` so na resposta, como o maximo por
                  consulta, e nao declara parametro de tamanho de pagina.
                  Em campo, o pedido de 5 devolveu 100 itens. A pagina nao
                  se corta no cliente, porque o cursor ``searchAfter`` da
                  pagina seguinte vem da ultima linha que a API mandou;
                  para limitar o total, use ``paginas``.

        Returns:
            DataFrame com uma linha por processo retornado. A API responde 404
                ("Não foram encontrados registros") a pagina seguinte a ultima com
                dados e a busca sem resultado; o 404 encerra a coleta, e a busca
                sem resultado devolve DataFrame vazio.

        Raises:
            TypeError: Quando um kwarg desconhecido e passado ou ``paginas`` tem tipo invalido.
            ValidationError: Quando ``paginas`` (pagina < 1, vazia, ``range`` descendente) ou um filtro e invalido.
            ColetaParcialError: Quando uma pagina falha depois de linhas lidas: ``resultado`` traz
                essas linhas, ``falhas`` tem um item ``(None, None, exc)``, ``__cause__`` e a falha da
                pagina (inclusive o 401 e o ``ErroSsoPdpj``) e a mensagem diz de onde faltam as paginas.
                Antes de alguma linha lida, as falhas abaixo sobem como vieram.
            requests.HTTPError: Quando a requisicao falha com status diferente de 404.
            RetryExhaustedError: Quando a requisicao falha depois das tentativas.
            requests.Timeout: Quando a requisicao estoura o prazo.
            requests.ConnectionError: Quando a conexao falha.
            InvalidJSONResponseError: Quando uma pagina vem sem JSON valido.
            ErroSsoPdpj: Quando o SSO recusa ou nao renova o token.

        See Also:
            :class:`InputPesquisaPdpj` -- schema pydantic e a fonte da
            verdade dos filtros aceitos.
        """
        self._check_auth()
        try:
            inp = InputPesquisaPdpj(paginas=normalize_paginas(paginas), **kwargs)
        except ValidationError as exc:
            raise_on_extra_kwargs(
                exc, "PdpjScraper.pesquisa()", schema_cls=InputPesquisaPdpj,
            )
            raise

        base_data = inp.model_dump(exclude={"paginas", "itens_por_pagina"})
        base_params = _to_query_params(base_data)
        # Sem efeito na API hoje (ver ``itens_por_pagina`` no docstring); o
        # parâmetro segue na querystring para não mudar a requisição de quem já
        # o passa, caso a API volte a aceitá-lo.
        base_params["maxElementsSize"] = inp.itens_por_pagina
        return pd.DataFrame(self._paginar(base_params, inp.paginas_normalizadas))

    def _paginar(
        self,
        base_params: dict[str, Any],
        permitidas: Paginas | None,
    ) -> list[dict[str, Any]]:
        """Segue o cursor ``searchAfter`` até a página vazia, o fim do cursor ou a maior página pedida.

        A API devolve em cada página o cursor da seguinte; as linhas de uma
        página entram só quando ela está em ``permitidas`` (``None`` = todas).
        A página seguinte à última com dados vem como 404 com ``{code, message}``
        ("Não foram encontrados registros"), e a página 1 da busca sem resultado
        também: os dois encerram a coleta com o que já foi lido. Outro status
        de erro levanta.

        Raises:
            ColetaParcialError: Quando uma página falha depois de linhas lidas
                (ver :meth:`pesquisa`).
        """
        rows: list[dict[str, Any]] = []
        pagina = 1
        search_after: list[Any] | None = None
        while True:
            try:
                lida = self._pagina_da_pesquisa(base_params, search_after)
            except Exception as exc:  # vai para ColetaParcialError, se houver o que guardar
                levantar_parcial_da_pesquisa(rows, pagina, exc)
                raise
            if lida is None:
                return rows
            page_rows, search_after = lida
            if pagina_pedida(permitidas, pagina):
                rows.extend(page_rows)
            ultima = permitidas is not None and pagina >= maior_pagina(permitidas)
            if not search_after or not page_rows or ultima:
                return rows
            pagina += 1
            if self.sleep_time:
                time.sleep(self.sleep_time)

    def _pagina_da_pesquisa(
        self,
        base_params: dict[str, Any],
        search_after: list[Any] | None,
    ) -> tuple[list[dict[str, Any]], list[Any] | None] | None:
        """Linhas e cursor de uma página da ``pesquisa``; ``None`` no 404 sem registros."""
        params = dict(base_params)
        if search_after is not None:
            # API espera searchAfter como string CSV: timestamp,id
            params["searchAfter"] = ",".join(str(v) for v in search_after)
        data = fetch_pesquisa(self._request_with_retry, params, base_url=self.BASE_URL)
        if data is None:
            return None
        page_rows, proximo, _total = parse_pesquisa_response(data)
        return page_rows, proximo

    def contar(self, **kwargs: Any) -> int:
        """Total de processos que casam com os filtros (``/processos:contar``).

        Args:
            **kwargs: Filtros aceitos por :class:`InputContarPdpj`, todos
                opcionais (``None`` = sem filtro), com o significado e o formato
                descritos em :meth:`pesquisa`. Ficam de fora paginacao,
                ordenacao, ``fase``, ``situacao_atual`` e ``tipo_operacao``, que
                a especificacao publica da API nao declara neste endpoint.

                * ``numero_processo`` / ``numero_processo_sintetico`` / ``id`` (str | None)
                * ``id_fonte_dados_codex`` / ``numero_historico`` / ``href`` (str | None)
                * ``cpf_cnpj_parte`` / ``nome_parte`` / ``outro_nome_parte`` (str | None)
                * ``polo_parte`` / ``situacao_parte`` (str | None)
                * ``nome_representante`` / ``oab_representante`` (str | None)
                * ``id_classe`` / ``id_assunto_judicial`` (str | None)
                * ``id_orgao_julgador`` (str | list[str] | None)
                * ``instancia`` / ``segmento_justica`` / ``tribunal`` (str | None)
                * ``data_atualizacao_inicio`` / ``data_atualizacao_fim`` (str | None)
                * ``data_primeiro_ajuizamento_inicio`` / ``data_primeiro_ajuizamento_fim`` (str | None)

        Returns:
            Total informado pela API.

        Raises:
            TypeError: Quando um kwarg desconhecido e passado.
            ValidationError: Quando um filtro e invalido.
            requests.HTTPError: Quando a requisicao falha.
            RetryExhaustedError: Quando a requisicao falha.
            requests.Timeout: Quando a requisicao falha.
            requests.ConnectionError: Quando a requisicao falha.
            InvalidJSONResponseError: Quando a resposta nao traz um inteiro.

        See Also:
            :class:`InputContarPdpj` -- schema pydantic e a fonte da
            verdade dos filtros aceitos.
        """
        self._check_auth()
        try:
            inp = InputContarPdpj(**kwargs)
        except ValidationError as exc:
            raise_on_extra_kwargs(
                exc, "PdpjScraper.contar()", schema_cls=InputContarPdpj,
            )
            raise
        params = _to_query_params(inp.model_dump())
        return fetch_contar(self._request_with_retry, params, base_url=self.BASE_URL)

    def download_documents(
        self,
        base_df: pd.DataFrame,
        max_docs_per_process: int | None = None,
        *,
        with_text: bool = True,
        with_binary: bool = False,
    ) -> pd.DataFrame:
        """Baixa textos e/ou binarios dos documentos listados.

        ``base_df`` pode vir de :meth:`documentos` (uma linha por
        documento, ja com ``id_documento`` e ``numero_processo``) ou de
        :meth:`cpopg` (uma linha por processo com ``detalhes`` -- nesse
        caso a lista de documentos e extraida de
        ``detalhes['documentos']`` e de ``documentos`` de cada item de
        ``detalhes['tramitacoes']``, com as mesmas colunas de
        :meth:`documentos`, inclusive ``_raw``).

        Um documento cujo download falha não interrompe a coleta: a linha
        sai com ``texto``/``_raw_texto`` e/ou ``binario`` iguais a ``None``
        e o método segue para o próximo documento. Conta como falha qualquer
        erro HTTP diferente de 401 (inclusive o 403, que a API pode devolver
        para um documento isolado, como um sigiloso, e que por isso não é
        retentado), o retry de 429/5xx/timeout esgotado e o erro de conexão.
        A coluna ``motivo_falha`` guarda o motivo, no vocabulário de
        :mod:`juscraper.core.failures`; com texto e binário, guarda o do texto
        quando o texto falhou, senão o do binário, e o ``None`` de cada coluna
        diz qual conteúdo faltou. Ao fim, um único ``UserWarning`` informa
        quantos downloads falharam e cita alguns, com processo, documento,
        conteúdo e motivo. O 401 propaga, porque token inválido atinge o lote
        inteiro.

        O documento sem arquivo (``arquivo_id`` vazio, na base que traz a
        coluna) não tem conteúdo no data lake, e a API responde 404 ao pedido
        de texto dele. Ele sai com os conteúdos ``None`` e ``motivo_falha``
        ``None``, sem requisição e fora do aviso, e ocupa vaga do limite, como
        qualquer linha devolvida.

        Args:
            base_df: DataFrame fonte das chamadas.
            max_docs_per_process: Limite de linhas devolvidas por processo,
                na ordem de ``base_df``. Linhas sem ``id_documento`` sao
                puladas sem ocupar vaga do limite; um documento cujo
                download falhou ocupa vaga, como no JusBR, porque sua linha
                sai no resultado (com conteúdo ``None``) e a requisição já
                foi feita. ``None`` = sem limite; ``0`` devolve DataFrame vazio
                sem fazer requisicao.
            with_text: Se ``True`` (default), baixa o texto via
                ``/documentos/{id}/texto``.
            with_binary: Se ``True``, baixa o binario via
                ``/documentos/{id}/binario``. Default ``False`` para nao
                consumir banda quando o usuario so quer texto.

        Returns:
            DataFrame com uma linha por documento. Inclui colunas
                ``texto`` e ``binario`` (quando solicitados), ``None`` nos
                documentos cujo download falhou, e ``motivo_falha``.

        Raises:
            ValidationError: Quando ``base_df`` nao e um DataFrame ou
                ``max_docs_per_process`` e negativo.
            ValueError: Quando ``with_text`` e ``with_binary`` sao ambos
                ``False``, ou quando ``base_df`` nao tem coluna
                ``id_documento`` nem ``detalhes``.
            requests.HTTPError: Quando a API responde 401 (token ausente,
                expirado ou inválido). O erro atinge o lote inteiro, então
                propaga e as linhas já baixadas se perdem; as falhas
                anteriores ao 401 vão numa nota do próprio erro
                (``__notes__``), não no ``UserWarning``.
            ErroSsoPdpj: Quando o SSO do PJe recusa ou não consegue renovar o
                token no meio do lote. Propaga como o 401, com as falhas
                anteriores numa nota do erro.

        Avisos:
            ``UserWarning``: Quando pelo menos um download de documento falhou.
            Um aviso por chamada, com a contagem e alguns exemplos,
            emitido só quando a coleta termina.

        See Also:
            :class:`InputDownloadDocumentsPdpj`: schema pydantic e fonte
            da verdade dos parametros aceitos.
        """
        self._check_auth()
        # Validacao via schema -- garante que kwargs desconhecidos viram TypeError.
        try:
            inp = InputDownloadDocumentsPdpj(
                base_df=base_df,
                max_docs_per_process=max_docs_per_process,
                with_text=with_text,
                with_binary=with_binary,
            )
        except ValidationError as exc:
            raise_on_extra_kwargs(
                exc,
                "PdpjScraper.download_documents()",
                schema_cls=InputDownloadDocumentsPdpj,
            )
            raise
        base_df = inp.base_df
        max_docs_per_process = inp.max_docs_per_process
        conteudos = _Conteudos(texto=inp.with_text, binario=inp.with_binary)
        if not conteudos.texto and not conteudos.binario:
            raise ValueError(
                "Pelo menos um de 'with_text' ou 'with_binary' deve ser True."
            )

        docs_df = self._coerce_to_documentos_df(base_df)
        if docs_df.empty:
            return pd.DataFrame()

        rows: list[dict[str, Any]] = []
        falhas: list[str] = []
        try:
            for processo, grupo in docs_df.groupby("processo", sort=False):
                rows.extend(self._download_process_documents(
                    grupo, processo, max_docs_per_process, conteudos, falhas,
                ))
        except requests.HTTPError as erro:
            anotar_falhas_anteriores(erro, falhas, _ITEM_DOWNLOAD)
            raise
        except ErroSsoPdpj as erro_sso:
            anotar_falhas_antes_do_sso(erro_sso, falhas, _ITEM_DOWNLOAD)
            raise
        avisar_falhas(falhas, "PdpjScraper.download_documents", _ITEM_DOWNLOAD)
        return pd.DataFrame(rows)

    def _download_process_documents(
        self,
        grupo: pd.DataFrame,
        processo: object,
        max_docs_per_process: int | None,
        conteudos: _Conteudos,
        falhas: list[str],
    ) -> list[dict[str, Any]]:
        """Baixa os documentos de um processo ate o limite de linhas devolvidas.

        O limite e conferido antes de cada documento, e nao com ``head(N)``
        sobre ``grupo``: assim uma linha sem ``id_documento``, que
        :meth:`_download_document` pula, nao ocupa uma vaga do limite.
        """
        rows: list[dict[str, Any]] = []
        for _, doc_row in grupo.iterrows():
            if max_docs_per_process is not None and len(rows) >= max_docs_per_process:
                break
            row = self._download_document(doc_row, processo, conteudos, falhas)
            if row is not None:
                rows.append(row)
        return rows

    def _download_document(
        self,
        doc_row: pd.Series,
        processo: object,
        conteudos: _Conteudos,
        falhas: list[str],
    ) -> dict[str, Any] | None:
        """Baixa os conteúdos selecionados para uma linha de documento.

        Falha de download de texto ou binario vira ``None`` na coluna e uma
        entrada em ``falhas``; o 401 propaga (ver ``e_token_invalido``).
        """
        row = cast(dict[str, Any], doc_row.to_dict())
        id_documento = row.get("id_documento")
        numero_processo = row.get("numero_processo") or processo
        # ``pd.isna`` cobre o ``NaN`` que o pandas põe no id ausente; ``NaN`` é
        # truthy e passaria por ``not id_documento`` como id válido.
        if pd.isna(id_documento) or id_documento == "":
            # A linha de falha de ``documentos`` não tem id e já foi contada no
            # aviso daquela chamada; o log fica para o documento que veio sem id.
            if pd.isna(row.get(COLUNA_MOTIVO_FALHA)):
                logger.warning(
                    "Documento sem id_documento no processo %s; pulando.",
                    numero_processo,
                )
            return None
        if _sem_arquivo(row):
            return _linha_sem_conteudo(row, conteudos)
        cnj_clean = clean_cnj(str(numero_processo))
        descricao = f"processo {numero_processo}, documento {id_documento}"
        motivo_texto = motivo_binario = None
        if conteudos.texto:
            raw, motivo_texto = _buscar_conteudo(
                fetch_documento_texto, self._request_with_retry, cnj_clean, str(id_documento), self.BASE_URL,
            )
            if motivo_texto is not None:
                falhas.append(f"{descricao}, texto: {motivo_texto}")
            row["texto"] = clean_document_text(raw)
            row["_raw_texto"] = raw
        if conteudos.binario:
            row["binario"], motivo_binario = _buscar_conteudo(
                fetch_documento_binario, self._request_with_retry, cnj_clean, str(id_documento), self.BASE_URL,
            )
            if motivo_binario is not None:
                falhas.append(f"{descricao}, binario: {motivo_binario}")
        # Uma coluna de motivo para duas requisições: o texto tem precedência.
        row[COLUNA_MOTIVO_FALHA] = motivo_texto if motivo_texto is not None else motivo_binario
        if self.sleep_time:
            time.sleep(self.sleep_time)
        return row

    def _coerce_to_documentos_df(self, base_df: pd.DataFrame) -> pd.DataFrame:
        """Aceita tanto o DataFrame de :meth:`documentos` quanto o de :meth:`cpopg`.

        No primeiro caso o df ja vem no shape esperado. No segundo, cada
        linha tem ``detalhes['documentos']`` e os ``documentos`` de cada
        item de ``detalhes['tramitacoes']``, que precisamos achatar antes
        de baixar conteudo.
        """
        if base_df.empty:
            return pd.DataFrame()
        if "id_documento" in base_df.columns:
            return base_df
        if "detalhes" not in base_df.columns:
            raise ValueError(
                "base_df precisa ter coluna 'id_documento' (de PdpjScraper.documentos) "
                "ou 'detalhes' (de PdpjScraper.cpopg)."
            )
        rows: list[dict[str, Any]] = []
        for _, linha in base_df.iterrows():
            cnj = linha.get("processo")
            detalhes = linha.get("detalhes") or {}
            if not isinstance(detalhes, dict):
                continue
            for document in _iter_documents(detalhes):
                row = _document_to_row(document, cnj, detalhes.get("numeroProcesso"))
                if row is not None:
                    rows.append(row)
        return pd.DataFrame(rows)
