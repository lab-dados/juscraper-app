"""Funcoes de parse para o agregador PDPJ.

A API responde com JSON ja estruturado — o trabalho deste modulo e
adicionar a coluna pivot ``processo`` com o CNJ pesquisado e achatar os
campos aninhados. A limpeza do texto de documento fica em
:func:`juscraper.core.parse_utils.clean_document_text`.
"""
from __future__ import annotations

import logging
from collections.abc import Iterator
from typing import Any

logger = logging.getLogger(__name__)


def build_processo_row(
    detalhe: dict[str, Any],
    cnj_pesquisado: str,
) -> dict[str, Any]:
    """Constroi uma linha do DataFrame de :meth:`PdpjScraper.cpopg`.

    Mantem o JSON completo em ``detalhes`` para os campos auxiliares e
    extrai o que e mais usado (``numeroProcesso``, ``siglaTribunal``,
    ``segmentoJustica``, ``dataHoraAtualizacao``) para colunas top-level.
    """
    return {
        "processo": cnj_pesquisado,
        "numero_processo": detalhe.get("numeroProcesso"),
        "id": detalhe.get("id"),
        "sigla_tribunal": detalhe.get("siglaTribunal"),
        "segmento_justica": detalhe.get("segmentoJustica"),
        "nivel_sigilo": detalhe.get("nivelSigilo"),
        "data_atualizacao": detalhe.get("dataHoraAtualizacao"),
        "detalhes": detalhe,
    }


def build_documento_rows(
    json_data: dict[str, Any] | None,
    cnj_pesquisado: str,
) -> list[dict[str, Any]]:
    """Cada documento da resposta vira uma linha do DataFrame.

    A API embute a lista em ``documentos``; o restante do JSON descreve
    o processo. O achatamento de cada documento fica em
    :func:`_document_to_row`, o mesmo do caminho do ``cpopg`` em
    :meth:`PdpjScraper.download_documents`.
    """
    if not json_data:
        return []
    numero_processo = json_data.get("numeroProcesso")
    rows: list[dict[str, Any]] = []
    for doc in json_data.get("documentos", []) or []:
        row = _document_to_row(doc, cnj_pesquisado, numero_processo)
        if row is not None:
            rows.append(row)
    return rows


def build_movimento_rows(
    json_data: dict[str, Any] | None,
    cnj_pesquisado: str,
) -> list[dict[str, Any]]:
    """Cada movimento da resposta vira uma linha do DataFrame."""
    if not json_data:
        return []
    numero_processo = json_data.get("numeroProcesso")
    rows: list[dict[str, Any]] = []
    for mov in json_data.get("movimentos", []) or []:
        if not isinstance(mov, dict):
            continue
        tipo = mov.get("tipo") or {}
        classe = mov.get("classe") or {}
        rows.append({
            "processo": cnj_pesquisado,
            "numero_processo": numero_processo,
            "sequencia": mov.get("sequencia"),
            "data_hora": mov.get("dataHora"),
            "id_codex": mov.get("idCodex"),
            "id_origem": mov.get("idOrigem"),
            "descricao": mov.get("descricao"),
            "tipo_id": tipo.get("id"),
            "tipo_nome": tipo.get("nome"),
            "tipo_hierarquia": tipo.get("hierarquia"),
            "classe_codigo": classe.get("codigo"),
            "classe_descricao": classe.get("descricao"),
            "_raw": mov,
        })
    return rows


def build_parte_rows(
    json_data: dict[str, Any] | None,
    cnj_pesquisado: str,
) -> list[dict[str, Any]]:
    """Cada parte da resposta vira uma linha do DataFrame."""
    if not json_data:
        return []
    numero_processo = json_data.get("numeroProcesso")
    rows: list[dict[str, Any]] = []
    for parte in json_data.get("partes", []) or []:
        if not isinstance(parte, dict):
            continue
        documentos = parte.get("documentosPrincipais") or []
        doc_principal = documentos[0] if documentos else {}
        rows.append({
            "processo": cnj_pesquisado,
            "numero_processo": numero_processo,
            "polo": parte.get("polo"),
            "tipo_parte": parte.get("tipoParte"),
            "situacao": parte.get("situacao"),
            "nome": parte.get("nome"),
            "tipo_pessoa": parte.get("tipoPessoa"),
            "documento_numero": doc_principal.get("numero"),
            "documento_tipo": doc_principal.get("tipo"),
            "_raw": parte,
        })
    return rows


def parse_pesquisa_response(
    json_data: dict[str, Any] | None,
) -> tuple[list[dict[str, Any]], list[Any] | None, int | None]:
    """Extrai (linhas, ``searchAfter``, total) do JSON de ``/processos``.

    Cada elemento de ``content`` vira uma linha bruta — o caller decide
    o shape final do DataFrame (varios cnj's na mesma chamada).
    ``fetch_pesquisa`` garante ``content`` como lista.
    """
    if not json_data:
        return [], None, None
    content = json_data.get("content") or []
    rows: list[dict[str, Any]] = []
    for item in content:
        if not isinstance(item, dict):
            continue
        rows.append({
            "numero_processo": item.get("numeroProcesso"),
            "id": item.get("id"),
            "sigla_tribunal": item.get("siglaTribunal"),
            "segmento_justica": item.get("segmentoJustica"),
            "data_atualizacao": item.get("dataHoraAtualizacao"),
            "data_ultimo_movimento": item.get("dataHoraUltimoMovimento"),
            "data_primeiro_ajuizamento": item.get("dataHoraPrimeiroAjuizamento"),
            "_raw": item,
        })
    search_after = json_data.get("searchAfter")
    total = json_data.get("total")
    if not isinstance(total, int):
        total = None
    return rows, search_after, total


def _iter_documents(details: dict[str, Any]) -> Iterator[Any]:
    """Itera documentos do topo e das tramitacoes na ordem da API."""
    top_documents = details.get("documentos")
    if isinstance(top_documents, list):
        yield from top_documents
    traversals = details.get("tramitacoes")
    if not isinstance(traversals, list):
        return
    for traversal in traversals:
        if isinstance(traversal, dict) and isinstance(traversal.get("documentos"), list):
            yield from traversal["documentos"]


def _document_to_row(
    document: object,
    process: object,
    process_number: object,
) -> dict[str, Any] | None:
    """Achata um documento PDPJ bem-formado numa linha de DataFrame.

    Fonte unica das colunas de documento: serve a :meth:`PdpjScraper.documentos`
    (via :func:`build_documento_rows`) e a :meth:`PdpjScraper.download_documents`
    quando ``base_df`` vem de :meth:`PdpjScraper.cpopg`. Item que nao e objeto
    devolve ``None`` e o caller o pula.
    """
    if not isinstance(document, dict):
        return None
    file_data = document.get("arquivo") or {}
    document_type = document.get("tipo") or {}
    return {
        "processo": process,
        "numero_processo": process_number,
        "id_documento": document.get("id"),
        "id_codex": document.get("idCodex"),
        "id_origem": document.get("idOrigem"),
        "sequencia": document.get("sequencia"),
        "data_juntada": document.get("dataHoraJuntada"),
        "nome": document.get("nome"),
        "nivel_sigilo": document.get("nivelSigilo"),
        "tipo_codigo": document_type.get("codigo"),
        "tipo_nome": document_type.get("nome"),
        "arquivo_id": file_data.get("id"),
        "arquivo_tipo": file_data.get("tipo"),
        "arquivo_tamanho": file_data.get("tamanho"),
        "arquivo_tamanho_texto": file_data.get("tamanhoTexto"),
        "arquivo_paginas": file_data.get("quantidadePaginas"),
        "_raw": document,
    }
