"""
Functions for parsing specific to TJDFT
"""
import pandas as pd

from juscraper.core.parse_utils import coerce_date_columns, normalizar_texto

# Chaves da API com nome canonico no projeto (refs #12). As demais passam como
# vem: ``codigoClasseCnj``, por exemplo, e o codigo da classe, nao o nome que
# ``classe`` traz nos outros tribunais.
_RENOMEAR = {
    "nomeRelator": "relator",
    "descricaoOrgaoJulgador": "orgao_julgador",
    "dataJulgamento": "data_julgamento",
    "dataPublicacao": "data_publicacao",
}


def cjsg_parse(resultados_brutos):
    """Uma linha por registro da API, com as chaves de :data:`_RENOMEAR` renomeadas.

    A ``ementa`` passa por :func:`normalizar_texto`.
    """
    return [
        {
            _RENOMEAR.get(chave, chave): normalizar_texto(valor) if chave == "ementa" else valor
            for chave, valor in item.items()
        }
        for item in resultados_brutos
    ]


def cjsg_tabela(registros: list) -> pd.DataFrame:
    """O DataFrame do ``cjsg``: :func:`cjsg_parse` com as datas convertidas.

    A data fica em UTC de propósito: é a que o filtro ``data_*`` da API usa.
    """
    df = pd.DataFrame(cjsg_parse(registros))
    coerce_date_columns(df, ["data_julgamento", "data_publicacao"], date_format="ISO8601")
    return df
