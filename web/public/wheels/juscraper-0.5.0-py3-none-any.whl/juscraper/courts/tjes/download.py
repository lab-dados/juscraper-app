"""Downloads raw results from the TJES jurisprudence search."""
from typing import Final, get_args

from juscraper.core.http import RequestFn
from juscraper.utils.pagination import RespostaJson, baixar_paginas_pedidas, paginas_declaradas_json

from .parse import cjsg_parse
from .schemas import CoreCJSG

BASE_URL = "https://sistemas.tjes.jus.br/consulta-jurisprudencia/api"

# Maps tab names used in the UI to core identifiers in the API
CORES = {
    "pje1g": "pje1g",
    "pje2g": "pje2g",
    "pje2g_mono": "pje2g_mono",
    "legado": "legado",
    "turma_recursal_legado": "turma_recursal_legado",
}

DEFAULT_CORE: Final = "pje2g"
CJSG_CORES = frozenset(get_args(CoreCJSG))
CJPG_CORE = "pje1g"
DEFAULT_PER_PAGE = 20


# Onde a resposta traz a contagem, os itens e o id de cada item.
_RESPOSTA = RespostaJson(("total",), ("docs",), "id")


def _build_params(
    pesquisa,
    pagina,
    per_page,
    core,
    busca_exata,
    data_inicio,
    data_fim,
    magistrado,
    orgao_julgador,
    classe_judicial,
    jurisdicao,
    assunto,
    ordenacao,
):
    """Build the query-string parameters for the search endpoint."""
    params = {
        "core": core,
        "q": pesquisa or "*",
        "page": pagina,
        "per_page": per_page,
    }
    if busca_exata:
        params["exact_match"] = "true"
    if data_inicio:
        params["dataIni"] = data_inicio
    if data_fim:
        params["dataFim"] = data_fim
    if magistrado:
        params["magistrado"] = magistrado
    if orgao_julgador:
        params["orgao_julgador"] = orgao_julgador
    if classe_judicial:
        params["classe_judicial"] = classe_judicial
    if jurisdicao:
        params["jurisdicao"] = jurisdicao
    if assunto:
        params["lista_assunto"] = assunto
    if ordenacao:
        params["sort"] = ordenacao
    return params


def cjsg_download(
    pesquisa=None,
    paginas=None,
    core=DEFAULT_CORE,
    busca_exata=False,
    data_inicio=None,
    data_fim=None,
    magistrado=None,
    orgao_julgador=None,
    classe_judicial=None,
    jurisdicao=None,
    assunto=None,
    ordenacao=None,
    per_page=DEFAULT_PER_PAGE,
    *,
    request_fn: RequestFn,
    sleep_time: float = 1.0,
) -> list:
    """Download raw JSON results from the TJES jurisprudence search.

    Returns a list of raw page responses (each containing ``docs``, ``total``,
    ``page``, ``per_page``, ``total_pages``). HTTP via ``request_fn`` (tipicamente
    ``TJESScraper._request_with_retry`` de ``core.http.HTTPScraper``), que
    centraliza retry exponencial para 429/5xx.

    Raises:
        PaginaInesperadaError: Quando a primeira página pedida não traz
            ``total``, ou quando uma página dentro do total vem sem a lista
            ``docs``, sem documento ou com os documentos de outra.
    """
    url = f"{BASE_URL}/search"
    common = {
        "pesquisa": pesquisa,
        "per_page": per_page,
        "core": core,
        "busca_exata": busca_exata,
        "data_inicio": data_inicio,
        "data_fim": data_fim,
        "magistrado": magistrado,
        "orgao_julgador": orgao_julgador,
        "classe_judicial": classe_judicial,
        "jurisdicao": jurisdicao,
        "assunto": assunto,
        "ordenacao": ordenacao,
    }

    def _get_page(pagina):
        params = _build_params(pagina=pagina, **common)
        # O perfil cjsg exige JSON: o backend Solr do TJES devolve esporadicamente 200 com
        # corpo vazio; _request_with_retry retenta e, persistindo, levanta
        # InvalidJSONResponseError com contexto em vez de JSONDecodeError opaco (#275).
        resp = request_fn("GET", url, params=params, perfil="cjsg")
        return resp.json()

    def _n_pags(first: dict) -> int:
        return _RESPOSTA.n_pags(
            first,
            resultados_por_pagina=per_page,
            totais_links=paginas_declaradas_json(first, "total_pages"),
            tribunal="TJES",
        )

    return baixar_paginas_pedidas(
        paginas,
        _get_page,
        _n_pags,
        tribunal="TJES",
        ler_parcial=cjsg_parse,
        sleep_time=sleep_time,
        n_itens=_RESPOSTA.n_itens,
        chaves=_RESPOSTA.chaves,
        itens="documentos",
        contar_resultados=_RESPOSTA.n_resultados,
    )
