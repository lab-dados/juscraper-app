"""
Scraper do Tribunal de Justiça do Estado de Mato Grosso (TJMT).
"""

from collections.abc import Mapping
from datetime import date
from functools import partial
from typing import Any, ClassVar

import pandas as pd

from juscraper.core.http import HTTPScraper, RequestPolicy
from juscraper.utils.params import apply_input_pipeline_search, resolve_deprecated_alias

from .download import PRODUCTION_API_URL, _get_api_config, cjsg_download
from .parse import cjsg_parse, cjsg_tabela
from .schemas import InputCJSGTJMT, TipoConsulta


class TJMTScraper(HTTPScraper):
    """Scraper do Tribunal de Justiça do Estado de Mato Grosso (TJMT)."""

    BASE_URL = PRODUCTION_API_URL

    perfis_http: ClassVar[Mapping[str, RequestPolicy]] = {
        "configuracao": RequestPolicy(timeout=30),
        "busca": RequestPolicy(timeout=60, expect_json=True),
    }

    def __init__(self, *, sleep_time: float = 1.0, politica: Mapping[str, Mapping[str, Any]] | None = None):
        super().__init__("TJMT", sleep_time=sleep_time, politica=politica)
        self._api_config: dict[str, str] | None = None

    def _get_cached_api_config(self, *, force_refresh: bool = False) -> dict[str, str]:
        """Descobre a configuração do portal uma vez por instância.

        A descoberta não envia o token em cache: ``headers={"token": None}``
        o retira só dessas requisições, sem mexer na sessão.
        """
        if force_refresh or self._api_config is None:
            sem_token = {"token": None}  # nosec B105  # remove o header, não é senha
            self._api_config = _get_api_config(partial(self._request_with_retry, headers=sem_token))
        return self._api_config

    def cpopg(self, id_cnj: str | list[str]):
        """Consulta de processos de primeiro grau ainda não implementada no TJMT."""
        raise NotImplementedError("Consulta de processos de 1 grau nao implementada para TJMT.")

    def cposg(self, id_cnj: str | list[str]):
        """Consulta de processos de segundo grau ainda não implementada no TJMT."""
        raise NotImplementedError("Consulta de processos de 2 grau nao implementada para TJMT.")

    def cjsg_download(
        self,
        pesquisa: str | None = None,
        paginas: int | list | range | None = None,
        tipo_consulta: TipoConsulta = "Acordao",
        relator: str | None = None,
        orgao_julgador: str | None = None,
        tipo_processo: str | None = None,
        thesaurus: bool = False,
        tamanho_pagina: int = 10,
        data_publicacao_inicio: str | date | None = None,
        data_publicacao_fim: str | date | None = None,
        classe: str | list[str] | None = None,
        **kwargs,
    ) -> list:
        """Baixa as respostas JSON brutas da API de jurisprudência do TJMT.

        Aceita os mesmos parâmetros e aliases deprecados de :meth:`cjsg`; veja lá a
        lista completa. Levanta nos mesmos casos de :meth:`cjsg`. Cada página
        baixada é uma resposta da API, sem parsear.

        Returns:
            Resposta JSON de cada página, na ordem pedida.
        """
        tamanho_pagina = resolve_deprecated_alias(
            kwargs, "quantidade_por_pagina", "tamanho_pagina", tamanho_pagina, sentinel=10
        )
        inp = apply_input_pipeline_search(
            InputCJSGTJMT,
            "TJMTScraper.cjsg_download()",
            pesquisa=pesquisa,
            paginas=paginas,
            kwargs=kwargs,
            consume_pesquisa_aliases=True,
            data_publicacao_inicio=data_publicacao_inicio,
            data_publicacao_fim=data_publicacao_fim,
            tipo_consulta=tipo_consulta,
            relator=relator,
            orgao_julgador=orgao_julgador,
            tipo_processo=tipo_processo,
            classe=classe,
            thesaurus=thesaurus,
            tamanho_pagina=tamanho_pagina,
        )
        return cjsg_download(
            pesquisa=inp.pesquisa,
            paginas=inp.paginas_normalizadas,
            tipo_consulta=inp.tipo_consulta,
            data_publicacao_inicio=inp.data_publicacao_inicio,
            data_publicacao_fim=inp.data_publicacao_fim,
            relator=inp.relator,
            orgao_julgador=inp.orgao_julgador,
            tipo_processo=inp.tipo_processo,
            classe=inp.classe,
            thesaurus=inp.thesaurus,
            quantidade_por_pagina=inp.tamanho_pagina,
            request_fn=self._request_with_retry,
            sleep_time=self.sleep_time,
            session=self.session,
            api_config_provider=self._get_cached_api_config,
        )

    def cjsg_parse(self, resultados_brutos: list, tipo_consulta: str = "Acordao") -> list[dict]:
        """Converte as respostas de :meth:`cjsg_download` em registros planos.

        Args:
            resultados_brutos: Respostas JSON brutas, uma por
                página.
            tipo_consulta: ``"Acordao"`` ou ``"DecisaoMonocratica"``.
                Mantido por compatibilidade; a resposta da API já traz o
                tipo de cada documento.

        Returns:
            Um dicionário por documento, com as colunas descritas
                em :meth:`cjsg`.
        """
        return cjsg_parse(resultados_brutos, tipo_consulta=tipo_consulta)

    def cjsg(
        self,
        pesquisa: str | None = None,
        paginas: int | list | range | None = None,
        tipo_consulta: TipoConsulta = "Acordao",
        relator: str | None = None,
        orgao_julgador: str | None = None,
        tipo_processo: str | None = None,
        thesaurus: bool = False,
        tamanho_pagina: int = 10,
        data_publicacao_inicio: str | date | None = None,
        data_publicacao_fim: str | date | None = None,
        classe: str | list[str] | None = None,
        **kwargs,
    ) -> pd.DataFrame:
        """Pesquisa jurisprudência do TJMT (acórdãos ou decisões monocráticas).

        Delega para :meth:`cjsg_download` e
        :func:`~juscraper.courts.tjmt.parse.cjsg_tabela`. Na primeira
        busca de cada instância, lê a configuração pública do portal (URL da
        API e token) nos scripts de ``jurisprudencia.tjmt.jus.br`` e a
        reutiliza nas buscas seguintes. Se a API recusar o token (HTTP 401 ou
        403), lê a configuração de novo e repete a consulta; se a recusa
        persistir, propaga ``requests.HTTPError`` ou ``RetryExhaustedError``.

        A API devolve no máximo os 10.000 primeiros resultados de uma
        consulta; páginas além desse teto respondem HTTP 500.

        Args:
            pesquisa: Termo livre buscado no documento.
            paginas: Páginas 1-based; ``None``
                baixa todas, até o teto de 10.000 resultados. Página pedida
                além do teto levanta ``ValueError``.
            tipo_consulta: ``"Acordao"`` (default) ou
                ``"DecisaoMonocratica"``.
            relator: Nome do relator. A API casa só o nome
                exato; acentos, espaços repetidos e caixa são normalizados
                (``"João da Silva"`` vai como ``"JOAO DA SILVA"``). A API
                atual não aceita mais o identificador numérico, que é
                rejeitado antes da rede. Nome com vírgula levanta
                ``ValueError``, porque a API a lê como separador e somaria
                os resultados de cada parte. ``None`` não filtra.
            orgao_julgador: Nome do órgão julgador, como
                aparece na coluna ``orgao_julgador`` (ex.:
                ``"PRIMEIRA CÂMARA DE DIREITO PRIVADO"``), com a mesma
                normalização de ``relator`` e a mesma recusa de vírgula.
                ``None`` não filtra.
            tipo_processo: ``"Civel"``, ``"Cível"`` ou
                ``"Criminal"``. ``None`` não filtra.
            thesaurus: Se ``True``, a API amplia a busca com
                sinônimos. Default ``False``.
            tamanho_pagina: Documentos por página, de 1 a 10.000.
                Default 10.
            data_publicacao_inicio: Início do intervalo
                de publicação: ``DD/MM/AAAA``, ``DD-MM-AAAA``, ``AAAA-MM-DD``,
                ``AAAA/MM/DD``, ``date`` ou ``datetime``. Com só
                ``data_publicacao_fim``, assume o piso
                ``OPEN_ENDED_DATE_FLOOR`` e emite ``UserWarning``.
            data_publicacao_fim: Fim do intervalo de
                publicação, nos mesmos formatos, inclusivo: o dia informado
                entra inteiro. Com só ``data_publicacao_inicio``, assume a
                data de hoje e emite ``UserWarning``.
            classe: Nome da classe processual, como
                aparece na coluna ``classe`` (ex.: ``"Apelação Cível"``), com
                a mesma normalização de ``relator``. A API casa só o nome
                exato: ``"Apelação"`` e ``"Apelação Cível"`` são classes
                distintas, e nome que não existe devolve busca vazia. Uma
                lista soma as classes
                (``["Apelação Cível", "Agravo de Instrumento"]``); nela, o
                nome que não existe é ignorado, sem aviso. Texto com vírgula
                levanta ``ValueError``: a classe com vírgula no nome vai
                dentro de uma lista
                (``["Exceção de Incompetência, Suspeição e Impedimento"]``),
                e chega à API com a vírgula trocada por U+FF0C, a forma que
                filtrou essas classes em 16/11/2026. Lista sem nomes levanta
                ``ValueError``. ``None`` não filtra.
            **kwargs: Só os aliases deprecados abaixo. Qualquer outro nome,
                inclusive ``data_julgamento_inicio``/``data_julgamento_fim``,
                que a API não filtra, levanta ``TypeError``.

        Aliases deprecados:
            * ``query`` / ``termo`` -> ``pesquisa``
            * ``quantidade_por_pagina`` -> ``tamanho_pagina``
            * ``data_publicacao_de`` / ``data_publicacao_ate`` -> ``data_publicacao_inicio`` / ``data_publicacao_fim``
            * ``data_inicio`` / ``data_fim`` -> ``data_julgamento_inicio`` / ``data_julgamento_fim``,
              que o TJMT não aceita: depois do aviso, levanta ``TypeError``.

        Raises:
            TypeError: Kwarg desconhecido ou sem suporte na API
                (``data_julgamento_*``).
            ValidationError: Para os demais erros de validação do schema,
                como ``relator``, ``orgao_julgador`` ou ``classe`` passados
                como número, ``tipo_consulta`` desconhecido e
                ``tamanho_pagina`` menor que 1 ou booleano.
            ValueError: Data inválida ou início depois do fim; ``relator``,
                ``orgao_julgador`` ou ``classe`` só com dígitos; ``relator``,
                ``orgao_julgador`` ou ``classe`` em texto com vírgula;
                ``classe`` em lista sem nomes; ``tipo_processo`` desconhecido;
                ``tamanho_pagina`` acima de 10.000; página além do teto de
                10.000 resultados.
            TJMTConfigError: A configuração pública do portal não foi
                encontrada ou aponta para outra API.
            TJMTResponseError: A API respondeu com erro ou num formato
                inesperado.

        Avisos:
            ``UserWarning``: com ``paginas=None``, quando a consulta tem mais
            de 10.000 resultados; baixa só os que cabem no teto, e a
            mensagem traz o total de páginas da busca e quantas a API
            entrega. Também quando só um dos
            lados do intervalo de publicação é informado.

        Returns:
            Uma linha por documento, com as colunas de
                ``CJSG_COLUMNS`` em :mod:`juscraper.courts.tjmt.parse`
                (``processo``, ``ementa``, ``relator``, ``orgao_julgador``,
                ``data_julgamento``, ``data_publicacao`` e outras, descritas em
                :class:`OutputCJSGTJMT`). Datas vêm como ``datetime.date``. Busca
                sem resultados devolve DataFrame vazio com as mesmas colunas.
                ``id`` vem ``0`` em decisões monocráticas antigas
                (``origem="Proteus"``); para deduplicar, use ``uuid``,
                distinto em cada documento.

        Examples: Exemplo
            >>> import juscraper as jus
            >>> tjmt = jus.scraper("tjmt")
            >>> df = tjmt.cjsg(
            ...     "dano moral",
            ...     paginas=1,
            ...     data_publicacao_inicio="2025-03-10",
            ...     data_publicacao_fim="2025-03-10",
            ... )

        See Also:
            :class:`InputCJSGTJMT`: fonte dos filtros aceitos.
        """
        brutos = self.cjsg_download(
            pesquisa=pesquisa,
            paginas=paginas,
            tipo_consulta=tipo_consulta,
            relator=relator,
            orgao_julgador=orgao_julgador,
            tipo_processo=tipo_processo,
            thesaurus=thesaurus,
            tamanho_pagina=tamanho_pagina,
            data_publicacao_inicio=data_publicacao_inicio,
            data_publicacao_fim=data_publicacao_fim,
            classe=classe,
            **kwargs,
        )
        return cjsg_tabela(brutos, tipo_consulta=tipo_consulta)
