"""
Scraper for the Tribunal de Justica do Estado do Para (TJPA).
"""
from collections.abc import Mapping
from typing import Any, ClassVar, Literal

import pandas as pd

from juscraper.core.http import HTTPScraper, RequestPolicy
from juscraper.utils.params import apply_input_pipeline_search, to_iso_date

from .download import cjsg_download_manager
from .parse import cjsg_parse_manager
from .schemas import InputCJSGTJPA


class TJPAScraper(HTTPScraper):
    """Scraper for the Tribunal de Justica do Estado do Para."""

    BASE_URL = "https://jurisprudencia.tjpa.jus.br/bff/api/decisoes/buscar"

    perfis_http: ClassVar[Mapping[str, RequestPolicy]] = {
        "cjsg": RequestPolicy(timeout=30),
    }

    def __init__(self, *, politica: Mapping[str, Mapping[str, Any]] | None = None):
        super().__init__("TJPA", politica=politica)

    def cpopg(self, id_cnj: str | list[str]):
        """Stub: first instance case consultation not implemented for TJPA."""
        raise NotImplementedError("Consulta de processos de 1o grau nao implementada para TJPA.")

    def cposg(self, id_cnj: str | list[str]):
        """Stub: second instance case consultation not implemented for TJPA."""
        raise NotImplementedError("Consulta de processos de 2o grau nao implementada para TJPA.")

    def cjsg_download(
        self,
        pesquisa: str | None = None,
        paginas: int | list | range | None = None,
        relator: str | None = None,
        orgao_julgador_colegiado: str | None = None,
        classe: str | None = None,
        assunto: str | None = None,
        origem: list | None = None,
        tipo: list | None = None,
        sort_by: str = "datajulgamento",
        sort_order: Literal["asc", "desc"] = "desc",
        query_type: str = "free",
        query_scope: str = "ementa",
        **kwargs,
    ) -> list:
        """Baixa resultados crus da busca de jurisprudencia do TJPA (varias paginas).

        Filtros de data (``data_julgamento_inicio``/``_fim``,
        ``data_publicacao_inicio``/``_fim``) chegam via ``**kwargs`` e sao
        validados pelo schema :class:`InputCJSGTJPA`; as de julgamento vao ao
        portal um dia antes (#508). Aliases deprecados
        (``data_inicio``/``data_fim``, ``query``/``termo``) sao popados antes
        da validacao.

        Returns:
            Respostas JSON cruas (uma por pagina).

        See also:
            :class:`InputCJSGTJPA` — fonte da verdade dos filtros aceitos.
        """
        inp = apply_input_pipeline_search(
            InputCJSGTJPA,
            "TJPAScraper.cjsg_download()",
            pesquisa=pesquisa,
            paginas=paginas,
            kwargs=kwargs,
            consume_pesquisa_aliases=True,
            relator=relator,
            orgao_julgador_colegiado=orgao_julgador_colegiado,
            classe=classe,
            assunto=assunto,
            origem=origem,
            tipo=tipo,
            sort_by=sort_by,
            sort_order=sort_order,
            query_type=query_type,
            query_scope=query_scope,
        )

        return cjsg_download_manager(
            pesquisa=inp.pesquisa,
            paginas=inp.paginas,
            request_fn=self._request_with_retry,
            relator=inp.relator,
            orgao_julgador_colegiado=inp.orgao_julgador_colegiado,
            classe=inp.classe,
            assunto=inp.assunto,
            origem=inp.origem,
            tipo=inp.tipo,
            data_julgamento_inicio=to_iso_date(inp.data_julgamento_inicio),
            data_julgamento_fim=to_iso_date(inp.data_julgamento_fim),
            data_publicacao_inicio=to_iso_date(inp.data_publicacao_inicio),
            data_publicacao_fim=to_iso_date(inp.data_publicacao_fim),
            sort_by=inp.sort_by,
            sort_order=inp.sort_order,
            query_type=inp.query_type,
            query_scope=inp.query_scope,
        )

    def cjsg_parse(self, resultados_brutos: list) -> pd.DataFrame:
        """
        Extracts relevant data from the raw results returned by TJPA.
        Returns a DataFrame with the decisions.
        """
        return cjsg_parse_manager(resultados_brutos)

    def cjsg(
        self,
        pesquisa: str | None = None,
        paginas: int | list | range | None = None,
        relator: str | None = None,
        orgao_julgador_colegiado: str | None = None,
        classe: str | None = None,
        assunto: str | None = None,
        origem: list | None = None,
        tipo: list | None = None,
        sort_by: str = "datajulgamento",
        sort_order: Literal["asc", "desc"] = "desc",
        query_type: str = "free",
        query_scope: str = "ementa",
        **kwargs,
    ) -> pd.DataFrame:
        """Busca jurisprudencia no TJPA (download + parse).

        Args:
            pesquisa (str): Termo de busca livre.
            paginas (int | list | range | None): Paginas 1-based; ``None`` baixa
                todas. Default ``None``.
            relator (str | None): Nome do relator.
            orgao_julgador_colegiado (str | None): Orgao colegiado.
            classe (str | None): Classe processual.
            assunto (str | None): Assunto.
            origem (list | None): Lista de origens (default backend:
                ``["tribunal de justica do estado do para"]``).
            tipo (list | None): Lista de tipos de decisao (default backend:
                ``["acordao", "decisao monocratica"]``).
            sort_by (str): ``"datajulgamento"`` (default), ``"datapublicacao"``
                ou ``"relevancia"``. O indice do portal tem decisoes com data
                de julgamento impossivel, como o ano 8201 ou 2106 (observado
                em 15/11/2026), e, com o default (``"datajulgamento"`` em
                ordem ``"desc"``), elas vem primeiro. O juscraper repassa a
                data como a fonte a entrega; para exclui-las, filtre
                ``data_julgamento_fim``. Outra ordenacao so as tira do topo.
            sort_order (str): ``"asc"`` ou ``"desc"``. Default ``"desc"``.
            query_type (str): ``"free"`` (default) ou ``"anywords"``.
            query_scope (str): ``"ementa"`` (default) ou ``"inteiroTeor"``.
            **kwargs: Filtros aceitos pelo schema :class:`InputCJSGTJPA`.
                Listados abaixo (todos opcionais; ``None`` = sem filtro):

                * ``data_julgamento_inicio`` / ``data_julgamento_fim``
                  (str | date | None): ``DD/MM/AAAA``, ``DD-MM-AAAA``,
                  ``AAAA-MM-DD``, ``AAAA/MM/DD``, ``date`` ou ``datetime``.
                  Enviadas ao portal um dia antes, que compensa o desvio do
                  filtro do TJPA (#508).
                * ``data_publicacao_inicio`` / ``data_publicacao_fim``
                  (str | date | None): nos mesmos formatos.

        Aliases deprecados (popados com ``DeprecationWarning`` antes do pydantic):
            * ``query`` / ``termo`` -> ``pesquisa``
            * ``data_inicio`` / ``data_fim`` -> ``data_julgamento_inicio`` / ``_fim``
            * ``data_julgamento_de`` / ``_ate`` -> ``data_julgamento_inicio`` / ``_fim``
            * ``data_publicacao_de`` / ``_ate`` -> ``data_publicacao_inicio`` / ``_fim``

        Raises:
            TypeError: Quando um kwarg desconhecido e passado.
            ValidationError: Quando um filtro tem formato invalido.

        Returns:
            DataFrame com as decisoes.

        See also:
            :class:`InputCJSGTJPA` — schema pydantic e a fonte da verdade dos
            filtros aceitos.
        """
        return self.cjsg_parse(self.cjsg_download(
            pesquisa=pesquisa,
            paginas=paginas,
            relator=relator,
            orgao_julgador_colegiado=orgao_julgador_colegiado,
            classe=classe,
            assunto=assunto,
            origem=origem,
            tipo=tipo,
            sort_by=sort_by,
            sort_order=sort_order,
            query_type=query_type,
            query_scope=query_scope,
            **kwargs,
        ))
