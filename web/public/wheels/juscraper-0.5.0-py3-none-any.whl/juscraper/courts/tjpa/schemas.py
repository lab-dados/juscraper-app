"""Pydantic schemas for TJPA scraper endpoints."""
from __future__ import annotations

from datetime import date
from typing import ClassVar, Literal

from ...schemas import (
    BuscarEm,
    DataJulgamentoMixin,
    DataPublicacaoMixin,
    OutputCJSGBase,
    OutputDataPublicacaoMixin,
    OutputRelatoriaMixin,
    SearchBase,
)

# Dominios dos filtros de ``cjsg``, usados tambem nas assinaturas de ``TJPAScraper``.
SortBy = Literal["datajulgamento", "datapublicacao", "relevancia"]
QueryType = Literal["free", "anywords"]


class InputCJSGTJPA(SearchBase, DataJulgamentoMixin, DataPublicacaoMixin):
    """Accepted input for TJPA ``cjsg`` / ``cjsg_download``.

    Wired em :meth:`juscraper.courts.tjpa.client.TJPAScraper.cjsg_download`
    desde o #183 (eliminada duplicacao do pipeline em ``cjsg``) — kwargs
    desconhecidos viram :class:`TypeError` em ambos ``cjsg`` e
    ``cjsg_download``. ``cjsg`` e wrapper trivial (``download → parse``).

    Endpoint REST JSON (BFF). ``pesquisa`` aceita os aliases deprecados
    ``query`` / ``termo`` via :func:`juscraper.utils.params.normalize_pesquisa`,
    que roda *antes* deste modelo. Datas aceitam os aliases
    ``data_inicio``/``data_fim`` via :func:`juscraper.utils.params.normalize_datas`.
    Filtros de data herdados dos mixins. Backend espera ``YYYY-MM-DD``.
    """

    BACKEND_DATE_FORMAT: ClassVar[str] = "%Y-%m-%d"

    relator: str | None = None
    orgao_julgador_colegiado: str | None = None
    classe: str | None = None
    assunto: str | None = None
    origem: list | None = None
    tipo: list | None = None
    sort_order: Literal["asc", "desc"] = "desc"
    sort_by: SortBy = "datajulgamento"
    query_type: QueryType = "free"
    # O portal recebe "ementa" ou "inteiroTeor" em ``queryScope``.
    buscar_em: BuscarEm = "ementa"


class OutputCJSGTJPA(OutputCJSGBase, OutputRelatoriaMixin, OutputDataPublicacaoMixin):
    """Colunas observaveis em uma linha do DataFrame de :meth:`TJPAScraper.cjsg`.

    Reflete ``tjpa.parse.cjsg_parse_manager``. ``assunto`` vem como string
    com multiplas entradas separadas por ``"; "`` (parser concatena dicts).
    """

    id: int | str | None = None
    tipo: str | None = None
    area: str | None = None
    origem: str | None = None
    classe: str | None = None
    id_classe: str | int | None = None
    assunto: str | None = None
    id_assunto: str | int | None = None
    orgao_julgador_colegiado: str | None = None
    competencia: str | None = None
    data_documento: date | str | None = None
    sentido_decisao: str | None = None
    especie: str | None = None
    sistema_origem: str | None = None
    hash_storage: str | None = None
