"""Scraper for the Tribunal de Justica da Paraiba (TJPB)."""
from collections.abc import Mapping
from datetime import date, datetime
from typing import Any, ClassVar

import pandas as pd

from juscraper.core.exceptions import ColetaParcialError
from juscraper.core.http import HTTPScraper, RequestPolicy
from juscraper.utils.params import apply_input_pipeline_search, coerce_brazilian_date, resolve_deprecated_alias

from .download import cjsg_download_manager
from .parse import cjsg_parse_manager
from .schemas import IdOrigem, InputCJSGTJPB


def _to_date(value, fallback: date) -> date:
    """Coerce a user-supplied date to ``datetime.date`` for the local post-filter.

    Reuses :func:`coerce_brazilian_date` so all four canonical string formats
    plus ``date``/``datetime`` are accepted. Returns ``fallback`` when the
    input is ``None``, empty, or unparseable — used to keep ``DataFrame.between``
    open on one side when the user only supplied ``inicio`` or ``fim``.
    """
    coerced = coerce_brazilian_date(value, "%d/%m/%Y")
    if not coerced or not isinstance(coerced, str):
        return fallback
    try:
        return datetime.strptime(coerced, "%d/%m/%Y").date()
    except ValueError:
        return fallback


def _na_janela_de_julgamento(df: pd.DataFrame, raw_inicio, raw_fim) -> pd.DataFrame:
    """As linhas com ``data_julgamento`` na janela pedida (o pós-filtro do ``cjsg``, também no parcial).

    O filtro ``dt_inicio``/``dt_fim`` do backend age sobre uma data interna de
    disponibilização, não sobre ``dt_ementa``, e volta linhas com
    ``dt_ementa`` longe da janela pedida. Os limites abertos
    (``date.min``/``date.max``) mantêm o filtro quando só um lado da janela
    foi passado (refs #195).
    """
    if df.empty or "data_julgamento" not in df.columns:
        return df
    mask = df["data_julgamento"].between(_to_date(raw_inicio, date.min), _to_date(raw_fim, date.max))
    return df[mask].reset_index(drop=True)


def _first_present(kwargs: dict, *keys: str):
    """Retorna o primeiro valor cuja key esta em ``kwargs`` (mesmo que vazio).

    Distinto de ``or`` chain: trata ``""`` como valor explicito do usuario
    (canonico empty vence alias preenchido), nao como "passa adiante".
    """
    for key in keys:
        if key in kwargs:
            return kwargs[key]
    return None


class TJPBScraper(HTTPScraper):
    """Scraper for the Tribunal de Justica da Paraiba (TJPB).

    Uses the PJe jurisprudence search at pje-jurisprudencia.tjpb.jus.br.
    Built on the same platform developed by TJRN (Laravel + Elasticsearch).
    """

    BASE_URL = "https://pje-jurisprudencia.tjpb.jus.br"

    perfis_http: ClassVar[Mapping[str, RequestPolicy]] = {
        "classes": RequestPolicy(timeout=30),
        "cjsg": RequestPolicy(timeout=30),
    }

    def __init__(self, *, sleep_time: float = 1.0, politica: Mapping[str, Mapping[str, Any]] | None = None):
        super().__init__("TJPB", sleep_time=sleep_time, politica=politica)

    def cpopg(self, id_cnj: str | list[str]):
        """Stub: first instance case consultation not implemented for TJPB."""
        raise NotImplementedError("Consulta de processos de 1o grau nao implementada para TJPB.")

    def cposg(self, id_cnj: str | list[str]):
        """Stub: second instance case consultation not implemented for TJPB."""
        raise NotImplementedError("Consulta de processos de 2o grau nao implementada para TJPB.")

    def cjsg(
        self,
        pesquisa: str | None = None,
        paginas: int | list | range | None = None,
        numero_processo: str | None = None,
        id_classe: str | None = None,
        id_orgao_julgador: str | None = None,
        id_relator: str | None = None,
        id_origem: IdOrigem = "8,2",
        decisoes: bool = False,
        **kwargs,
    ) -> pd.DataFrame:
        """Busca jurisprudencia no TJPB.

        Args:
            pesquisa: Termo de busca livre (busca na ementa).
            paginas: Paginas 1-based; ``None`` baixa
                todas. Default ``None``. O portal so entrega os 10.000
                primeiros resultados de uma busca (1000 paginas): pagina
                pedida alem da 1000 levanta ``ValueError`` antes de qualquer
                requisicao, e ``None`` numa busca maior baixa as 1000
                primeiras e emite ``UserWarning``.
            numero_processo: Numero CNJ do processo. Aceita o alias
                deprecado ``nr_processo``.
            id_classe: ID da classe judicial. Aceita o alias deprecado
                ``id_classe_judicial`` (refs #129).
            id_orgao_julgador: ID do orgao julgador.
            id_relator: ID do relator.
            id_origem: Filtro de origem. ``"8,2"`` para todos (default),
                ``"8"`` para Turmas Recursais, ``"2"`` para Tribunal Pleno/Camaras.
            decisoes: Se ``True``, inclui decisoes monocraticas.
            **kwargs: Filtros aceitos pelo schema :class:`InputCJSGTJPB`.
                Listados abaixo (todos opcionais; ``None`` = sem filtro):

                * ``data_julgamento_inicio`` / ``data_julgamento_fim``
                  (str | date | None): ``DD/MM/YYYY``, ``DD-MM-YYYY``,
                  ``YYYY-MM-DD``, ``YYYY/MM/DD``, ``date`` ou ``datetime``. Convertido para
                  ``YYYY-MM-DD`` antes do envio ao backend. O backend filtra
                  por uma data interna de disponibilizacao (nao por
                  ``dt_ementa``); o cliente aplica um post-filter local sobre
                  ``data_julgamento`` para garantir que a janela pedida bate
                  com o que e devolvido (refs #195).

        Aliases deprecados:
            * ``query`` / ``termo`` -> ``pesquisa``
            * ``nr_processo`` -> ``numero_processo``
            * ``id_classe_judicial`` -> ``id_classe``
            * ``data_inicio`` / ``data_fim`` -> ``data_julgamento_inicio`` / ``data_julgamento_fim``
            * ``data_julgamento_de`` / ``data_julgamento_ate`` -> ``data_julgamento_inicio`` / ``data_julgamento_fim``

        Raises:
            TypeError: Quando um kwarg desconhecido e passado.
            ValueError: Quando um canonico e seu alias deprecado sao passados
                simultaneamente.
            ValidationError: Quando um filtro tem formato invalido.
            ColetaParcialError: Quando uma página falha depois de outra pedida
                já baixada; ``resultado`` traz as anteriores, com o mesmo
                pós-filtro de ``data_julgamento``.

        Returns:
            DataFrame com as decisoes.

        See Also:
            :class:`InputCJSGTJPB` — schema pydantic e a fonte da verdade dos
            filtros aceitos.
        """
        # Lookup passivo das datas para o post-filter local. Sem `pop` para
        # nao consumir aliases antes do pipeline em `cjsg_download`, que e
        # quem valida e emite DeprecationWarning. `_first_present` (em vez
        # de `or` chain) preserva canonico empty contra alias preenchido.
        raw_inicio = _first_present(
            kwargs, "data_julgamento_inicio", "data_julgamento_de", "data_inicio"
        )
        raw_fim = _first_present(
            kwargs, "data_julgamento_fim", "data_julgamento_ate", "data_fim"
        )

        try:
            brutos = self.cjsg_download(
                pesquisa=pesquisa,
                paginas=paginas,
                numero_processo=numero_processo,
                id_classe=id_classe,
                id_orgao_julgador=id_orgao_julgador,
                id_relator=id_relator,
                id_origem=id_origem,
                decisoes=decisoes,
                **kwargs,
            )
        except ColetaParcialError as exc:
            exc.resultado = _na_janela_de_julgamento(exc.resultado, raw_inicio, raw_fim)
            raise
        return _na_janela_de_julgamento(self.cjsg_parse(brutos), raw_inicio, raw_fim)

    def cjsg_download(
        self,
        pesquisa: str | None = None,
        paginas: int | list | range | None = None,
        numero_processo: str | None = None,
        id_classe: str | None = None,
        id_orgao_julgador: str | None = None,
        id_relator: str | None = None,
        id_origem: IdOrigem = "8,2",
        decisoes: bool = False,
        **kwargs,
    ) -> list:
        """Baixa as respostas JSON brutas da busca de jurisprudência do TJPB.

        Aceita os mesmos parâmetros e aliases deprecados de :meth:`cjsg`; veja lá a
        lista completa.

        Returns:
            Lista de respostas JSON cruas (uma por pagina).
        """
        numero_processo = resolve_deprecated_alias(
            kwargs, "nr_processo", "numero_processo", numero_processo
        )
        id_classe = resolve_deprecated_alias(
            kwargs, "id_classe_judicial", "id_classe", id_classe
        )
        inp = apply_input_pipeline_search(
            InputCJSGTJPB,
            "TJPBScraper.cjsg_download()",
            pesquisa=pesquisa,
            paginas=paginas,
            kwargs=kwargs,
            consume_pesquisa_aliases=True,
            numero_processo=numero_processo,
            id_classe=id_classe,
            id_orgao_julgador=id_orgao_julgador,
            id_relator=id_relator,
            id_origem=id_origem,
            decisoes=decisoes,
        )
        return cjsg_download_manager(
            pesquisa=inp.pesquisa,
            paginas=inp.paginas_normalizadas,
            request_fn=self._request_with_retry,
            sleep_time=self.sleep_time,
            nr_processo=inp.numero_processo or "",
            id_classe=inp.id_classe or "",
            id_orgao_julgador=inp.id_orgao_julgador or "",
            id_relator=inp.id_relator or "",
            id_origem=inp.id_origem,
            decisoes=inp.decisoes,
            dt_inicio=inp.data_julgamento_inicio or "",
            dt_fim=inp.data_julgamento_fim or "",
        )

    def cjsg_parse(self, resultados_brutos: list) -> pd.DataFrame:
        """Parse downloaded CJSG JSON responses.

        Args:
            resultados_brutos: Lista devolvida por :meth:`cjsg_download`.

        Returns:
            DataFrame com as decisoes.
        """
        return cjsg_parse_manager(resultados_brutos)
