"""Parse raw results from the TJPB jurisprudence search."""
import pandas as pd

from juscraper.core.parse_utils import normalizar_texto


def cjsg_parse_manager(resultados_brutos: list) -> pd.DataFrame:
    """Extract relevant data from the raw TJPB API responses.

    Returns a DataFrame with the decisions.

    Args:
        resultados_brutos: List of raw JSON responses from the TJPB API.
    """
    registros: list[dict] = []
    for response in resultados_brutos:
        hits = response.get("hits", [])
        registros.extend(
            {
                "processo": hit.get("numero_processo"),
                "ementa": normalizar_texto(hit.get("ementa")),
                "data_julgamento": hit.get("dt_ementa"),
            }
            for hit in hits
        )

    df = pd.DataFrame(registros, columns=["processo", "ementa", "data_julgamento"])
    if df.empty:
        return df

    if "data_julgamento" in df.columns:
        df["data_julgamento"] = pd.to_datetime(
            df["data_julgamento"], format="%d/%m/%Y", errors="coerce"
        ).dt.date

    return df
