"""Downloads raw results from the TJPI jurisprudence search (HTML scraping)."""
import re
from urllib.parse import parse_qs, urlparse

from bs4 import BeautifulSoup

from juscraper.core.http import RequestFn
from juscraper.utils.pagination import (
    AvisoVazio,
    baixar_paginas_pedidas,
    extract_count_with_cascade,
    parse_page_number,
    resolve_total_pages,
)

from .parse import cjsg_parse_manager

BASE_URL = "https://jurisprudencia.tjpi.jus.br/jurisprudences/search"
RESULTS_PER_PAGE = 25


def build_cjsg_params(
    pesquisa: str,
    page: int = 1,
    tipo: str = "",
    relator: str = "",
    classe: str = "",
    orgao: str = "",
    data_min: str = "",
    data_max: str = "",
) -> dict:
    """Build the query-string params dict for the TJPI CJSG search endpoint.

    ``data_min``/``data_max`` are the BFF date filter (ISO ``YYYY-MM-DD``);
    they are wired by ``TJPIScraper.cjsg`` after going through
    ``normalize_datas`` + ``to_iso_date``.
    """
    params = {"q": pesquisa, "page": str(page)}
    if tipo:
        params["tipo"] = tipo
    if relator:
        params["relator"] = relator
    if classe:
        params["classe"] = classe
    if orgao:
        params["orgao"] = orgao
    if data_min:
        params["data_min"] = data_min
    if data_max:
        params["data_max"] = data_max
    return params


_LAST_PAGE_TEXT = "\u00bb"  # », rótulo do link de última página
# Cascata da contagem. O rótulo fica num ``<div class="pb-3">`` sem outra
# classe; o seletor exige a classe exata porque ``div.pb-3`` casaria também o
# contêiner da página (``content pt-3 pb-3 d-flex``), que guarda as ementas.
# O HTML da página só entra (``fallback_html``) quando o seletor não casa
# nenhum elemento com texto, e por isso as duas regex começam em "Exibindo" e
# exigem "jurisprudência(s)" depois do número: "de um total de 84 prestações"
# numa ementa não casa. Se o seletor casar um div cujo texto as regex não
# reconhecem, a contagem vem ``None`` e, sem o aviso de busca vazia,
# ``resolve_total_pages`` levanta.
_COUNT_SELECTORS = ('div[class="pb-3"]',)
# O número vem em ``<b>``; ``_SEP`` aceita espaço e tag entre as palavras para
# que a mesma regex sirva ao texto do rótulo e ao HTML do fallback.
_SEP = r"(?:\s|&nbsp;|<[^>]+>)*"
_COUNT_PATTERNS = (
    # Várias páginas: "Exibindo 1 - 25 de um total de <b>137865</b> jurisprudência(s)".
    re.compile(
        rf"Exibindo{_SEP}[\d.]+{_SEP}-{_SEP}[\d.]+{_SEP}de um total de{_SEP}([\d.]+){_SEP}jurisprud",
        re.IGNORECASE,
    ),
    # Página única: "Exibindo <b>5</b> jurisprudência(s)".
    re.compile(rf"Exibindo{_SEP}([\d.]+){_SEP}jurisprud", re.IGNORECASE),
)
# Busca sem resultados: "Sem resultados para:" e o termo pesquisado num
# ``div.col-md-6`` dentro de ``div.p-4``, contêiner que a página de resultados
# não tem (lá é ``div.p-md-4``). O marcador só vale nesse contêiner: "sem
# resultados para a localização de bens" numa ementa não zera a contagem.
_AVISO_VAZIO = AvisoVazio(("div.p-4 div.col-md-6",), ("Sem resultados para:",))


# Cada jurisprudência é um ``div[data-controller="clipboard reveal"]`` com o
# link ``/jurisprudences/<id>/public``.
_ITEM = 'data-controller="clipboard reveal"'
_ITEM_ID = re.compile(r'href="/jurisprudences/(\d+)/public"')


def _n_jurisprudencias(html: str) -> int | None:
    """Jurisprudências da página; ``None`` quando ela não traz a contagem nem o aviso de busca vazia.

    As regex da contagem e o marcador do aviso rodam no HTML bruto, como no
    ``fallback_html`` de :func:`_get_total_pages`, sem parsear a página de novo.
    """
    if any(regex.search(html) for regex in _COUNT_PATTERNS):
        return html.count(_ITEM)
    return 0 if any(marcador in html for marcador in _AVISO_VAZIO.marcadores) else None


def _ids_das_jurisprudencias(html: str) -> list[str]:
    return _ITEM_ID.findall(html)


def _last_page_links(soup: BeautifulSoup) -> set[int]:
    """Lê os totais dos links ``»`` da página inteira.

    O link de última página não tem classe, ``rel`` nem ``aria-label``
    próprios: é um ``a.page-link`` como os numerados, e só o rótulo ``»``
    o distingue. A busca cobre a página inteira, e não só ``ul.pagination``,
    para que uma troca de tema do paginador não esconda o link da conferência.
    """
    totais = set()
    for link in soup.select("a[href]"):
        if link.get_text(strip=True) != _LAST_PAGE_TEXT:
            continue
        pagina = parse_qs(urlparse(str(link["href"])).query).get("page", [""])[0]
        totais.add(parse_page_number(pagina, tribunal="TJPI", origem=f"link » {link['href']!r}"))
    return totais


def _get_total_pages(html: str) -> int:
    """Extrai o total de páginas de uma página de resultados.

    O total sai da contagem "de um total de N jurisprudência(s)" dividida por
    ``RESULTS_PER_PAGE``, e os links ``»`` da página são conferidos contra ele
    por :func:`~juscraper.utils.pagination.resolve_total_pages`. Toda página de
    resultados traz a contagem; ``cjsg_download_manager`` a lê na menor página pedida.

    Raises:
        ValueError: Nos casos de :func:`~juscraper.utils.pagination.resolve_total_pages`
            e de :func:`~juscraper.utils.pagination.parse_page_number`.
    """
    soup = BeautifulSoup(html, "html.parser")
    n_resultados = extract_count_with_cascade(
        soup,
        css_selectors=_COUNT_SELECTORS,
        regex_patterns=_COUNT_PATTERNS,
        aviso_vazio=_AVISO_VAZIO,
        fallback_html=True,
    )
    return resolve_total_pages(
        n_resultados,
        resultados_por_pagina=RESULTS_PER_PAGE,
        totais_links=_last_page_links(soup),
        tribunal="TJPI",
    )


def cjsg_download_manager(
    pesquisa: str,
    paginas=None,
    *,
    request_fn: RequestFn,
    sleep_time: float = 1.0,
    **kwargs,
) -> list:
    """Download raw HTML pages from the TJPI jurisprudence search.

    Returns a list of raw HTML strings (one per page).

    Args:
        pesquisa: Search term.
        paginas (list, range, or None): Pages to download (1-based).
        request_fn: HTTP callable that handles retry + raise_for_status — em
            uso normal e ``TJPIScraper._request_with_retry`` (via
            ``core.http.HTTPScraper``), centralizando backoff exponencial
            para 429/5xx.
        sleep_time: Delay (em segundos) entre páginas. Default 1.0; o client
            normalmente passa ``self.sleep_time`` herdado de ``HTTPScraper``.
        **kwargs: Additional filter parameters (tipo, relator, classe, orgao).

    Raises:
        ValueError: Quando a menor página pedida (a 1, com ``paginas=None``)
            não permite fixar o total de páginas; os casos estão em
            :func:`_get_total_pages`. O download para depois da primeira
            requisição, em vez de estimar.
        PaginaInesperadaError: Quando uma página dentro do total não traz a
            contagem, vem sem jurisprudência ou repete as de outra. Herda de
            ``ValueError``.
    """
    def _get_page(pagina_1based: int) -> str:
        params = build_cjsg_params(pesquisa=pesquisa, page=pagina_1based, **kwargs)
        resp = request_fn("GET", BASE_URL, params=params, perfil="cjsg")
        resp.encoding = "utf-8"
        return resp.text

    return baixar_paginas_pedidas(
        paginas,
        _get_page,
        _get_total_pages,
        tribunal="TJPI",
        ler_parcial=cjsg_parse_manager,
        sleep_time=sleep_time,
        n_itens=_n_jurisprudencias,
        chaves=_ids_das_jurisprudencias,
        itens="jurisprudências",
    )
