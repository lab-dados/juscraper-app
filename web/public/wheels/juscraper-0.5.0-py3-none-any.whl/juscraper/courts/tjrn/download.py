"""Downloads raw results from the TJRN jurisprudence search (Elasticsearch API)."""

from juscraper.core.http import RequestFn
from juscraper.utils.pagination import RespostaJson, baixar_paginas_pedidas

from ...schemas import BuscarEm
from .parse import cjsg_parse_manager

BASE_URL = "https://jurisprudencia.tjrn.jus.br/api/pesquisar"
RESULTS_PER_PAGE = 10


# Onde a resposta traz a contagem, os itens e o id de cada item.
_RESPOSTA = RespostaJson(("hits", "total"), ("hits", "hits"), "_id")


def build_cjsg_payload(
    pesquisa: str,
    page: int = 1,
    buscar_em: BuscarEm = "ementa",
    nr_processo: str = "",
    id_classe: str = "",
    id_orgao_julgador: str = "",
    id_relator: str = "",
    id_colegiado: str = "",
    id_juiz: str = "",
    id_vara: str = "",
    dt_inicio: str = "",
    dt_fim: str = "",
    origem: str = "",
    sistema: str = "",
    decisoes: str = "",
    jurisdicoes: str = "",
    grau: str = "",
) -> dict:
    """Build the JSON payload for the TJRN CJSG search API.

    The public parameter ``id_classe`` is the canonical name; the backend
    PJe field is ``id_classe_judicial`` and stays unchanged. ``pesquisa``
    goes in the field named by ``buscar_em`` (``"ementa"`` or
    ``"inteiro_teor"``); the other one is sent empty.
    """
    return {
        "jurisprudencia": {
            "ementa": pesquisa if buscar_em == "ementa" else "",
            "inteiro_teor": pesquisa if buscar_em == "inteiro_teor" else "",
            "nr_processo": nr_processo,
            "id_classe_judicial": id_classe,
            "id_orgao_julgador": id_orgao_julgador,
            "id_relator": id_relator,
            "id_colegiado": id_colegiado,
            "id_juiz": id_juiz,
            "id_vara": id_vara,
            "dt_inicio": dt_inicio,
            "dt_fim": dt_fim,
            "origem": origem,
            "sistema": sistema,
            "decisoes": decisoes,
            "jurisdicoes": jurisdicoes,
            "grau": grau,
        },
        "page": page,
        "usuario": {"matricula": "", "token": ""},  # nosec
    }


def cjsg_download_manager(
    pesquisa: str,
    paginas=None,
    *,
    request_fn: RequestFn,
    sleep_time: float = 1.0,
    **kwargs,
) -> list:
    """Download raw results from the TJRN jurisprudence search.

    Returns a list of raw JSON responses (one per page).

    Args:
        pesquisa: Search term.
        paginas (list, range, or None): Pages to download (1-based).
        request_fn: HTTP callable that handles retry + raise_for_status — em
            uso normal e ``TJRNScraper._request_with_retry`` (via
            ``core.http.HTTPScraper``), centralizando backoff exponencial
            para 429/5xx.
        sleep_time: Delay (em segundos) entre páginas. Default 1.0; o client
            normalmente passa ``self.sleep_time`` herdado de ``HTTPScraper``.
        **kwargs: Additional filter parameters.

    Raises:
        PaginaInesperadaError: Quando a primeira página pedida não traz
            ``hits.total``, ou quando uma página dentro do total vem sem a
            lista ``hits.hits``, sem decisão ou com as decisões de outra.
    """
    def _get_page(pagina_1based):
        payload = build_cjsg_payload(pesquisa, page=pagina_1based, **kwargs)
        resp = request_fn("POST", BASE_URL, json=payload, perfil="cjsg")
        data: dict = resp.json()
        return data

    def _n_pags(first: dict) -> int:
        return _RESPOSTA.n_pags(first, resultados_por_pagina=RESULTS_PER_PAGE, tribunal="TJRN")

    return baixar_paginas_pedidas(
        paginas,
        _get_page,
        _n_pags,
        tribunal="TJRN",
        ler_parcial=cjsg_parse_manager,
        sleep_time=sleep_time,
        n_itens=_RESPOSTA.n_itens,
        chaves=_RESPOSTA.chaves,
        itens="decisões",
        contar_resultados=_RESPOSTA.n_resultados,
    )
