"""Downloads raw results from the TJRO jurisprudence search (Elasticsearch API)."""
import math
from datetime import datetime

from juscraper.core.http import RequestFn
from juscraper.utils.divisao_por_data import BuscaComTeto, baixar_dividindo_por_data
from juscraper.utils.pagination import baixar_paginas_pedidas, contador_com_teto
from juscraper.utils.params import OPEN_ENDED_DATE_FLOOR

from .parse import cjsg_parse_manager

BASE_URL = "https://juris-back.tjro.jus.br/search/varios_parametros/"
RESULTS_PER_PAGE = 10
# O backend Elasticsearch entrega só os 10.000 primeiros resultados de uma
# busca. Medido em 16/11/2026: ``from`` + ``size`` acima de 10.000 responde
# HTTP 500 (com 10 por página, ``from=9990`` responde e ``from=10000`` falha),
# embora ``hits.total`` informe o total inteiro (123.574 em "dano moral").
MAX_RESULTS = 10_000
# Início das janelas quando a busca dividida por data não informa
# ``data_julgamento_inicio``: o mesmo piso que a biblioteca dá à busca que só
# informa a data final. Medido em 16/11/2026: em "dano moral", os 123.585
# resultados têm data de julgamento entre 1990 e o dia da medição.
PISO_DATA_JULGAMENTO = datetime.strptime(OPEN_ENDED_DATE_FLOOR, "%d/%m/%Y").date()  # noqa: DTZ007 - data sem hora


def build_cjsg_payload(
    pesquisa: str,
    offset: int = 0,
    size: int = RESULTS_PER_PAGE,
    tipo: list | None = None,
    nr_processo: str = "",
    relator: str = "",
    orgao_julgador: int | str = "",
    orgao_julgador_colegiado: int | str = "",
    classe: str = "",
    data_julgamento_inicio: str = "",
    data_julgamento_fim: str = "",
    instancia: list | None = None,
    termo_exato: bool = False,
) -> dict:
    """Build the JSON payload for the TJRO CJSG search API.

    Public parameters use canonical names (``relator``, ``classe``); the
    backend Elasticsearch field names (``ds_nome``, ``ds_classe_judicial``)
    are an internal detail of the JURIS API and stay unchanged.
    """
    if tipo is None:
        tipo = ["EMENTA"]

    fields: dict = {"tipo.raw": tipo, "query": pesquisa}
    if nr_processo:
        fields["nr_processo"] = nr_processo
    if relator:
        fields["ds_nome"] = relator
    if orgao_julgador:
        fields["id_orgao_julgador"] = str(orgao_julgador)
    if orgao_julgador_colegiado:
        fields["id_orgao_julgador_colegiado"] = str(orgao_julgador_colegiado)
    if classe:
        fields["ds_classe_judicial"] = classe
    if data_julgamento_inicio:
        fields["dtjulgamento_inicio"] = data_julgamento_inicio
    if data_julgamento_fim:
        fields["dtjulgamento_fim"] = data_julgamento_fim
    if instancia:
        fields["grau_jurisdicao"] = instancia
    if termo_exato:
        fields["termoExato"] = True

    return {
        "from": offset,
        "size": size,
        "fields": fields,
        "sort": [{"_score": "desc"}, {"dtjulgamento": "desc"}],
        "token": "",  # nosec
        "highlight": {
            "type": "plain",
            "number_of_fragments": 1,
            "fragment_size": 3000,
            "require_field_match": "true",
            "pre_tags": ["<em>"],
            "post_tags": ["</em>"],
            "fields": [{"ds_modelo_documento": {"number_of_fragments": 1}}],
        },
    }


def cjsg_download_manager(
    pesquisa: str,
    paginas=None,
    *,
    request_fn: RequestFn,
    sleep_time: float = 1.0,
    auto_chunk: bool = True,
    **kwargs,
) -> list:
    """Download raw results from the TJRO jurisprudence search.

    Returns a list of raw JSON responses (one per page).

    Args:
        pesquisa: Search term.
        paginas (list, range, or None): Pages to download (1-based).
        request_fn: HTTP callable que faz retry + raise_for_status — em uso
            normal e ``TJROScraper._request_with_retry`` (via
            ``core.http.HTTPScraper``), centralizando backoff para 429/5xx.
        sleep_time: Delay (em segundos) entre páginas. Default 1.0; o client
            normalmente passa ``self.sleep_time`` herdado de ``HTTPScraper``.
        auto_chunk: Com ``paginas=None``, divide por data de julgamento a
            busca que passa de ``MAX_RESULTS`` (ver
            :func:`juscraper.utils.divisao_por_data.baixar_dividindo_por_data`).
        **kwargs: Additional filter parameters forwarded to ``build_cjsg_payload``.
    """
    def _get_page(pagina_1based, **datas):
        offset = (pagina_1based - 1) * RESULTS_PER_PAGE
        payload = build_cjsg_payload(pesquisa, offset=offset, **{**kwargs, **datas})
        resp = request_fn("POST", BASE_URL, json=payload, perfil="cjsg")
        data: dict = resp.json()
        return data

    def _total(first: dict) -> int:
        total_info = first.get("hits", {}).get("total", {})
        total: int = total_info.get("value", 0) if isinstance(total_info, dict) else total_info
        return total or 0

    def _n_pags(first: dict) -> int:
        return math.ceil(_total(first) / RESULTS_PER_PAGE) or 1

    if paginas is None and auto_chunk:
        busca: BuscaComTeto[dict] = BuscaComTeto(
            tribunal="TJRO",
            rotulo="data_julgamento",
            teto=MAX_RESULTS,
            por_pagina=RESULTS_PER_PAGE,
            piso=PISO_DATA_JULGAMENTO,
            buscar=lambda inicio, fim, pagina: _get_page(
                pagina, data_julgamento_inicio=inicio or "", data_julgamento_fim=fim or ""
            ),
            contar_resultados=_total,
            itens=lambda pagina: pagina.get("hits", {}).get("hits", []),
            chave=lambda hit: hit["_id"],
            parse=cjsg_parse_manager,
            sleep_time=sleep_time,
        )
        return baixar_dividindo_por_data(
            busca, kwargs.get("data_julgamento_inicio") or None, kwargs.get("data_julgamento_fim") or None
        )

    contar = contador_com_teto(paginas, MAX_RESULTS // RESULTS_PER_PAGE, _n_pags, tribunal="TJRO")
    return baixar_paginas_pedidas(paginas, _get_page, contar, tribunal="TJRO", sleep_time=sleep_time)
