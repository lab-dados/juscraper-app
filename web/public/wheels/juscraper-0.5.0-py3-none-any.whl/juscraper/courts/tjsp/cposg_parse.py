"""
Parses downloaded files from the TJSP Consulta de Processos Originarios do Primeiro Grau (CPOSG).
"""
import re
from pathlib import Path

import pandas as pd
from bs4 import BeautifulSoup
from bs4.element import Comment, Script, Stylesheet, Tag, TemplateString
from tqdm import tqdm

from ...core.avisos import avisar
from ...core.failures import COLUNA_MOTIVO_FALHA, MOTIVO_RESPOSTA_INESPERADA
from ._falhas import arquivos_e_falhas, avisar_falhas_de_processo, cnj_da_pasta
from .cpopg_parse import _split_incident_header

_FIELD_MAPPING = (
    ('classe', 'classe'),
    ('assunto', 'assunto'),
    ('seção', 'secao'),
    ('órgão julgador', 'orgao_julgador'),
    ('área', 'area'),
    ('relator', 'relator'),
    ('valor da ação', 'valor_da_acao'),
    ('origem', 'origem'),
    ('volume / apenso', 'volume_apenso'),
)

_OUTPUT_COLUMNS = (
    'id_original',
    'processo',
    'status',
    'classe',
    'assunto',
    'secao',
    'orgao_julgador',
    'area',
    'relator',
    'valor_da_acao',
    'origem',
    'volume_apenso',
    'movimentacoes',
    'partes',
    'historico',
    'decisoes',
    'composicao',
    'primeira_inst',
    COLUNA_MOTIVO_FALHA,
)

_DETAIL_TABLE_STYLE = 'margin-left:15px; margin-top:1px;'


def cposg_parse(path: str) -> pd.DataFrame:
    """Interpreta os arquivos HTML do CPOSG em ``path``."""
    return cposg_parse_manager(path)


def cposg_parse_manager(
    path: str, metodo: str = "TJSPScraper.cposg_parse", pedidos: list | None = None,
) -> pd.DataFrame:
    """Interpreta os arquivos HTML do CPOSG sob ``path`` em um DataFrame.

    A coluna ``motivo_falha`` é ``None`` em cada processo lido. O arquivo que
    não pode ser lido, ou que não é a página de um processo, vira uma linha com ``processo`` (o CNJ da pasta),
    ``motivo_falha`` igual a ``resposta_inesperada`` e as demais colunas
    ``None``. O processo que ``cposg_download`` não baixou nessa pasta vira
    uma linha com ``processo`` e o motivo do download. As falhas também saem
    num ``UserWarning``, aberto por ``metodo``. Com ``pedidos``, só os
    arquivos e as falhas desses CNJs entram, como em ``cpopg_parse_manager``.
    """
    raiz = Path(path)
    # O download grava em <path>/cposg/; o cpopg, no mesmo download_path, em
    # <path>/cpopg/, com os mesmos nomes de arquivo. Só a pasta do cposg entra.
    if (raiz / 'cposg').is_dir():
        raiz = raiz / 'cposg'
    arquivos, sem_arquivo = arquivos_e_falhas(raiz, list(raiz.rglob('*.html')), pedidos)
    dados = []
    falhas = []
    for arq in tqdm(arquivos, total=len(arquivos), desc="Processando arquivos"):
        try:
            linhas = cposg_parse_single_html(arq)
        except (OSError, UnicodeDecodeError, ValueError, AttributeError) as e:
            linhas, erro = [], str(e)
        else:
            # Todo arquivo do download é a página de um processo; a que não
            # rende linha (página de erro do eSAJ gravada como processo) é falha.
            erro = "não é a página de um processo"
        if linhas:
            dados.extend(linhas)
            continue
        dados.append({'processo': cnj_da_pasta(arq), COLUNA_MOTIVO_FALHA: MOTIVO_RESPOSTA_INESPERADA})
        falhas.append(f"{arq}: {MOTIVO_RESPOSTA_INESPERADA} ({erro})")
    dados.extend({'processo': cnj, COLUNA_MOTIVO_FALHA: motivo} for cnj, motivo in sem_arquivo.items())
    avisar_falhas_de_processo(sem_arquivo, falhas, metodo, "Eles saem no DataFrame")
    return pd.DataFrame(dados, columns=_OUTPUT_COLUMNS)


def _extract_header(soup: BeautifulSoup) -> dict:
    """Extract process identifiers and status tags."""
    result = {}
    # No cabeçalho atual, o número fica em span#numeroProcesso.
    numero = soup.find('span', id='numeroProcesso')
    texto_numero = numero.get_text(strip=True) if numero else None
    if texto_numero:
        result['id_original'] = result['processo'] = texto_numero
    else:
        result.update(_extract_header_sem_numero(soup))

    status_tags = soup.select('span.unj-tag')
    if status_tags:
        result['status'] = ' / '.join(tag.get_text(strip=True) for tag in status_tags)
    return result


def _extract_header_sem_numero(soup: BeautifulSoup) -> dict:
    """Lê o cabeçalho de uma página sem ``span#numeroProcesso``.

    Na página de incidente, span.unj-larger traz "Embargos de Declaração
    Criminal (CNJ)". Sem CNJ ali, o primeiro link para processo.codigo pode ser
    de um incidente ("Embargos de Declaração - 50000") ou do processo de 1ª
    instância.
    """
    processo_tag = soup.select_one('span.unj-larger')
    texto = processo_tag.get_text(strip=True) if processo_tag else ''
    cnj, classe = _split_incident_header(texto)
    if cnj:
        return {'id_original': cnj, 'processo': cnj, 'classe': classe}

    fields = {}
    id_link = soup.select_one("a[href*='processo.codigo']")
    if id_link:
        fields['id_original'] = id_link.get_text(strip=True)
    if processo_tag:
        fields['processo'] = texto
    return fields


def _extract_labeled_fields(soup: BeautifulSoup) -> dict:
    """Map visible CPOSG labels to canonical result fields."""
    fields = {}
    for div in soup.find_all('div'):
        label_span = div.find('span', class_='unj-label')
        if not label_span:
            continue
        label_text = label_span.get_text(strip=True).lower()
        value_div = div.find('div')
        if not value_div:
            continue
        field_name = next((field for label, field in _FIELD_MAPPING if label in label_text), None)
        if field_name:
            fields[field_name] = value_div.get_text(strip=True)
    return fields


def _extract_movement_text(desc_cell) -> str:
    """Extract a movement label without its italic description."""
    movimento_link = desc_cell.find('a', class_='linkMovVincProc')
    if movimento_link:
        return str(movimento_link.get_text(strip=True))

    temp_cell = BeautifulSoup(str(desc_cell), 'html.parser')
    for span in temp_cell.find_all('span', style=lambda value: value and 'italic' in value):
        span.decompose()

    br_tag = temp_cell.find('br')
    if not br_tag:
        return str(temp_cell.get_text(strip=True))

    movimento = ''.join(
        str(sibling)
        for sibling in br_tag.previous_siblings
        if isinstance(sibling, str)
        or (hasattr(sibling, 'get_text') and getattr(sibling, 'name', None) != 'br')
    ).strip()
    if movimento:
        return movimento
    return str(temp_cell.get_text(separator=' ', strip=True)).split('\n')[0].strip()


def _extract_movements(movs_table: Tag) -> list[dict]:
    """Extract the movement table in displayed order."""
    movements = []
    for row in movs_table.find_all('tr', class_='movimentacaoProcesso'):
        cells = row.find_all('td')
        if len(cells) < 3 or not cells[0].get_text(strip=True):
            continue
        desc_cell = cells[2]
        descricao_span = desc_cell.find('span', style=lambda value: value and 'italic' in value)
        movements.append({
            'data': cells[0].get_text(strip=True),
            'movimento': _extract_movement_text(desc_cell),
            'descricao': descricao_span.get_text(strip=True) if descricao_span else '',
        })
    return movements


# ``str()`` of these strings returns their raw content, which ``get_text`` would skip.
_NON_TEXT_STRINGS = (Comment, Script, Stylesheet, TemplateString)
_NON_TEXT_TAGS = frozenset({'input', 'script', 'style'})


def _party_child_text(child) -> str:
    """Return the visible text of one direct child of a party cell."""
    if isinstance(child, Tag):
        return '' if child.name in _NON_TEXT_TAGS else str(child.get_text(' ', strip=True))
    if isinstance(child, _NON_TEXT_STRINGS):
        return ''
    return str(child).strip()


def _split_party_cell(cell: Tag) -> list[str]:
    """Split a party cell at ``br`` boundaries without joining adjacent labels."""
    segments: list[str] = []
    pieces: list[str] = []
    for child in cell.children:
        if isinstance(child, Tag) and child.name == 'br':
            segment = ' '.join(pieces).strip()
            if segment:
                segments.append(segment)
            pieces = []
            continue
        text = _party_child_text(child)
        if text:
            pieces.append(text)

    segment = ' '.join(pieces).strip()
    if segment:
        segments.append(segment)
    return segments


def _extract_parties(soup: BeautifulSoup) -> list[dict]:
    """Extract parties and their roles."""
    partes_table = soup.find(id='tableTodasPartes') or soup.find(id='tablePartesPrincipais')
    if not partes_table or soup.find(string=re.compile("Não há Partes")):
        return []

    parties = []
    for index, row in enumerate(partes_table.find_all('tr')):
        cells = row.find_all('td')
        if len(cells) < 2:
            continue
        party_type = cells[0].get_text(' ', strip=True).removesuffix(':').strip()
        segments = _split_party_cell(cells[1])
        if not segments:
            continue
        party_id = index + 1
        parties.append({
            'id_parte': party_id,
            'nome': segments[0],
            'parte': party_type,
            'papel': party_type,
        })
        for segment in segments[1:]:
            role, separator, name = segment.partition(':')
            if separator and name.strip():
                parties.append({
                    'id_parte': party_id,
                    'nome': name.strip(),
                    'parte': party_type,
                    'papel': role.strip(),
                })
    return parties


def _extract_history(soup: BeautifulSoup) -> list[list[str]]:
    """Lê as linhas do histórico de classes (``#tdHistoricoDeClasses``).

    A página atual do 2º grau não mostra o histórico, nem quando a classe foi
    corrigida (em 26/11/2026, o 1089223-45.2024.8.26.0053 trazia a
    movimentação "Realizado Correção de Classe" e nenhum bloco de histórico).
    Nela, a coluna sai ``[]``; o seletor fica para o formato antigo da página.
    """
    hist_table = soup.find(id='tdHistoricoDeClasses')
    if not hist_table:
        return []
    history = []
    for row in hist_table.find_all('tr'):
        cells = row.find_all('td')
        if cells:
            history.append([cell.get_text(strip=True) for cell in cells])
    return history


def _extract_decisions(tables: list) -> list[dict]:
    """Extract judgment rows after the judgment-status header."""
    header_index = next(
        (index for index, table in enumerate(tables) if "Situação do julgamento" in table.get_text()),
        -1,
    )
    if header_index < 0 or header_index + 1 >= len(tables):
        return []

    decisions = []
    for table in tables[header_index + 1:]:
        for row in table.find_all('tr'):
            cells = row.find_all('td')
            if len(cells) < 3:
                continue
            data = cells[0].get_text(strip=True)
            if data and not data.isalpha():
                decisions.append({
                    'data': data,
                    'situacao': cells[1].get_text(strip=True),
                    'decisao': cells[2].get_text(strip=True),
                })
    return decisions


def _extract_composition(tables: list) -> tuple[list[dict], str | None]:
    """Extract chamber composition and the first relator fallback."""
    composition_table = next(
        (table for table in tables if table.get_text().strip().startswith("Relator")),
        None,
    )
    if composition_table is None:
        return [], None

    composition = []
    fallback_relator = None
    for row in composition_table.find_all('tr'):
        cells = row.find_all('td')
        if len(cells) < 2:
            continue
        participation = cells[0].get_text(strip=True)
        if not participation:
            continue
        magistrate = cells[1].get_text(strip=True)
        composition.append({'participacao': participation, 'magistrado': magistrate})
        if participation == "Relator" and magistrate and fallback_relator is None:
            fallback_relator = magistrate
    return composition, fallback_relator


def _extract_first_instance(tables: list) -> list[dict]:
    """Extract first-instance references linked to the appeal."""
    header_index = next(
        (index for index, table in enumerate(tables) if "Nº de 1ª instância" in table.get_text()),
        -1,
    )
    if header_index < 0 or header_index + 1 >= len(tables):
        return []

    first_instance = []
    for row in tables[header_index + 1].find_all('tr'):
        cells = row.find_all('td')
        if len(cells) < 5:
            continue
        first_instance.append({
            'id_1a_inst': cells[0].get_text(strip=True),
            'foro': cells[1].get_text(strip=True),
            'vara': cells[2].get_text(strip=True),
            'juiz': cells[3].get_text(strip=True),
            'obs': cells[4].get_text(strip=True),
        })
    return first_instance


def cposg_parse_single_html(html_path) -> list[dict]:
    """Parse a single HTML document from CPOSG."""
    with Path(html_path).open('r', encoding='utf-8') as file:
        soup = BeautifulSoup(file.read(), 'html.parser')

    if soup.select('.linkProcesso'):
        return []
    # Formato antigo: tabelaTodasMovimentacoes. Atual: o eSAJ carrega as
    # movimentações à parte, e cposg_download as grava em tabelaMovimentacoesAjax.
    movs_table = soup.find(id='tabelaTodasMovimentacoes') or soup.find(id='tabelaMovimentacoesAjax')
    if movs_table is None:
        if soup.find(id='containerMovimentacoesAjax') is None:
            return []
        avisar(
            f"{html_path}: a página do processo não traz as movimentações, que o eSAJ "
            "carrega à parte; a coluna 'movimentacoes' sai vazia para ele. Baixe o "
            "processo de novo com cposg_download, que grava as movimentações no HTML."
        )

    result = _extract_header(soup)
    result.update(_extract_labeled_fields(soup))
    result['movimentacoes'] = _extract_movements(movs_table) if movs_table is not None else []
    result['partes'] = _extract_parties(soup)
    result['historico'] = _extract_history(soup)

    detail_tables = soup.select(f"table[style='{_DETAIL_TABLE_STYLE}']")
    result['decisoes'] = _extract_decisions(detail_tables)
    composition, fallback_relator = _extract_composition(detail_tables)
    if fallback_relator and not result.get('relator'):
        result['relator'] = fallback_relator
    result['composicao'] = composition
    result['primeira_inst'] = _extract_first_instance(detail_tables)

    for field in _OUTPUT_COLUMNS:
        result.setdefault(field, None)
    return [{field: result[field] for field in _OUTPUT_COLUMNS}]
