"""Schemas pydantic do ``cjsg`` do TRF3 (busca de jurisprudência).

Ficam fora de um ``schemas.py`` do tribunal porque a busca de jurisprudência
(``web.trf3.jus.br/jurisprudencia``) é um sistema separado da consulta
processual do PJe, com contrato e ciclo de mudança próprios.
"""
from __future__ import annotations

from typing import Annotated, ClassVar, Literal

from pydantic import BeforeValidator, Field

from ...schemas import DataJulgamentoMixin, DataPublicacaoMixin, InteiroSemBool, OutputCJSGBase, SearchBase
from ...schemas.mixins import OutputDataPublicacaoMixin, OutputRelatoriaMixin

BaseCJSGTRF3 = Literal[
    "acordaos",
    "turmas_recursais",
    "monocraticas",
    "monocraticas_turmas_recursais",
]
"""Bases de pesquisa do portal. Cada valor corresponde a um conjunto de resultados.

* ``acordaos``: acórdãos do TRF3 (aba "TRF3" do portal).
* ``turmas_recursais``: acórdãos das Turmas Recursais dos JEFs.
* ``monocraticas``: decisões monocráticas do TRF3.
* ``monocraticas_turmas_recursais``: decisões monocráticas das Turmas Recursais.

As duas últimas saem da mesma aba ("Monocráticas") e se distinguem pelas caixas
"TRF3" e "Recursal (JEF)". Medido no portal: com as duas marcadas, ou nenhuma, o
resultado é o mesmo da caixa "TRF3" sozinha, e não a união. Por isso cada
origem é uma base, e não um filtro combinável.
"""

#: Filtros que o formulário da aba "Monocráticas" não tem. O servidor ignoraria
#: o campo e devolveria resultado sem o filtro pedido.
FILTROS_SEM_MONOCRATICAS: tuple[str, ...] = ("orgao_julgador", "ementa", "indexacao")

#: Filtros que só o formulário da aba de acórdãos do TRF3 tem. Medido em
#: 15/11/2026, com "medicamento": nas Turmas Recursais, ``numclasse`` e
#: ``tema`` dão "Pesquisa Incorreta" e ``legislacao`` zera o resultado; nas
#: monocráticas, os três dão "Pesquisa Incorreta".
FILTROS_SO_ACORDAOS: tuple[str, ...] = ("numero_classe", "sistema_interamericano", "legislacao")

#: Filtros que o formulário de cada base não tem, recusados por
#: :func:`validar_combinacoes`.
_FILTROS_AUSENTES: dict[str, tuple[str, ...]] = {
    "acordaos": (),
    "turmas_recursais": FILTROS_SO_ACORDAOS,
    "monocraticas": FILTROS_SEM_MONOCRATICAS + FILTROS_SO_ACORDAOS,
    "monocraticas_turmas_recursais": FILTROS_SEM_MONOCRATICAS + FILTROS_SO_ACORDAOS,
}

#: Filtros que, sozinhos, já contam como critério de pesquisa no formulário.
_CRITERIOS = (
    "numero_processo",
    "relator",
    "classe",
    "orgao_julgador",
    "ementa",
    "indexacao",
    *FILTROS_SO_ACORDAOS,
    "data_julgamento_inicio",
    "data_publicacao_inicio",
)


def _id_numerico_como_int(valor: object) -> object:
    """Texto só de dígitos é o ID da opção (``"2"`` vira ``2``), e não um trecho do nome do caso.

    Sem isso, a união ``int | str`` do pydantic guardaria ``"2"`` como texto,
    que nenhum nome de caso contém.
    """
    if isinstance(valor, str) and valor.strip().isdigit():
        return int(valor.strip())
    return valor


class InputCJSGTRF3(SearchBase, DataJulgamentoMixin, DataPublicacaoMixin):
    """Accepted input for :meth:`TRF3Scraper.cjsg` / ``cjsg_download``.

    O formulário tem um só par de datas e um seletor ``data_tipo``
    (publicação ou julgamento); por isso ``data_julgamento_*`` e
    ``data_publicacao_*`` não podem vir juntos. Nas bases de monocráticas, a
    data de julgamento é a data da decisão.

    ``relator``, ``classe`` e ``orgao_julgador`` são texto, não IDs: o portal
    ignora o ID do dropdown e pesquisa o texto nos campos indexados
    (``relator_t``/``relator_acordao_t``, ``classe_t`` e o órgão julgador).

    ``numero_classe``, ``sistema_interamericano`` e ``legislacao`` só existem
    no formulário da base ``acordaos``. ``numero_classe`` é o número do
    processo dentro da classe, o que vem depois da classe na coluna
    ``classe`` dos acórdãos antigos (``1708075`` em
    ``"Ap - APELAÇÃO CÍVEL - 1708075"``). ``sistema_interamericano`` é o ID
    da opção do dropdown "Sistema Interamericano", que o portal pesquisa
    pelo ID, ou um trecho do nome do caso, que o download troca pelo ID da
    opção lida no formulário da aba. ``legislacao`` é texto livre,
    pesquisado nas referências legislativas dos documentos; o painel de
    legislações do formulário escreve nele textos como
    ``"LEI PELÉ FED LEI 9615 1998"``.

    ``pesquisa`` pode ser vazia quando outro critério (número, filtro ou datas)
    for informado; sem nenhum critério o portal recusa a busca. Essas regras de
    combinação ficam em :func:`validar_combinacoes`, chamada pelo client depois
    do modelo.
    """

    BACKEND_DATE_FORMAT: ClassVar[str] = "%d/%m/%Y"

    base: BaseCJSGTRF3 = "acordaos"
    numero_processo: str | None = None
    relator: str | None = None
    classe: str | None = None
    orgao_julgador: str | None = None
    ementa: str | None = None
    indexacao: str | None = None
    numero_classe: str | None = None
    sistema_interamericano: Annotated[
        Annotated[InteiroSemBool, Field(ge=1)] | str | None, BeforeValidator(_id_numerico_como_int)
    ] = None
    legislacao: str | None = None
    tamanho_pagina: Literal[10, 30, 50] = 10


def _informado(valor: object) -> bool:
    """Diz se o filtro foi informado: texto só com espaços conta como ausente.

    ``build_cjsg_payload`` apara relator, classe e órgão antes de montar os
    campos ocultos, então ``"   "`` nesses filtros chega ao portal como campo
    vazio; nos demais filtros de texto, espaços também não descrevem filtro
    nenhum. Contar esse texto como critério deixaria passar uma busca sem
    critério, que o portal recusa com erro do servidor em vez da mensagem de
    :func:`validar_combinacoes`.
    """
    if isinstance(valor, str):
        return bool(valor.strip())
    return bool(valor)


def validar_combinacoes(inp: InputCJSGTRF3) -> None:
    """Rejeita combinações que o formulário do portal não consegue expressar.

    Roda depois do pydantic (o modelo já resolveu aliases e coagiu as datas) e
    antes de qualquer requisição. Levanta :class:`ValueError` simples, e não
    ``ValidationError``, porque o problema é a combinação de campos válidos.

    Filtro de texto só com espaços conta como não informado (:func:`_informado`),
    tanto na recusa de filtro que a base não tem quanto na exigência de critério.

    Raises:
        ValueError: Datas de julgamento e de publicação juntas; filtro que o
            formulário da base não tem; nenhum critério de pesquisa.
    """
    tem_julgamento = bool(inp.data_julgamento_inicio or inp.data_julgamento_fim)
    tem_publicacao = bool(inp.data_publicacao_inicio or inp.data_publicacao_fim)
    if tem_julgamento and tem_publicacao:
        raise ValueError(
            "TRF3 cjsg: o formulário filtra por um só tipo de data. Passe "
            "data_julgamento_* ou data_publicacao_*, não os dois."
        )
    recusados = [nome for nome in _FILTROS_AUSENTES[inp.base] if _informado(getattr(inp, nome))]
    if recusados:
        raise ValueError(
            f"TRF3 cjsg: a base {inp.base!r} não aceita o(s) filtro(s) "
            f"{', '.join(recusados)}; o formulário dessa base não tem esses campos."
        )
    if not _informado(inp.pesquisa) and not any(_informado(getattr(inp, nome)) for nome in _CRITERIOS):
        filtros = ", ".join(nome for nome in _CRITERIOS if not nome.startswith("data_"))
        raise ValueError(f"TRF3 cjsg: informe pesquisa ou ao menos um filtro ({filtros} ou datas).")


class OutputCJSGTRF3(OutputCJSGBase, OutputRelatoriaMixin, OutputDataPublicacaoMixin):
    """Colunas observáveis em uma linha do DataFrame de :meth:`TRF3Scraper.cjsg`.

    Reflete ``trf3.cjsg_parse.cjsg_parse_manager``. Nas bases de monocráticas,
    ``ementa`` traz o texto da decisão (decisão monocrática não tem ementa) e
    ``orgao_julgador`` vem vazio. ``url_inteiro_teor`` só existe em acórdãos
    (TRF3 e Turmas Recursais).
    """

    classe: str | None = None
    relator_acordao: str | None = None
    meio_publicacao: str | None = None
    inteiro_teor: str | None = None
    url_inteiro_teor: str | None = None
    base: str | None = None
