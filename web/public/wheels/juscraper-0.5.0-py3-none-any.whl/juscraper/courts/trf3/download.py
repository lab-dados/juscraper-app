"""Camada HTTP da consulta pública do PJe do TRF3 (API JSON).

A consulta pública do TRF3 é uma aplicação Angular em
``pje1g-consultapublica.trf3.jus.br`` (1º grau) e
``pje2g-consultapublica.trf3.jus.br`` (2º grau), que consome uma API JSON sob
``/v1``. O endereço antigo (``.../pje/ConsultaPublica/listView.seam``)
redirecionava para ela; a situação do 1º grau em 15/11/2026 está na docstring de
:meth:`juscraper.courts.trf3.client.TRF3Scraper.cpopg`. Todas as rotas são
``GET`` e respondem no envelope
``{"status", "code", "messages", "result", "pageInfo"}``.

Uma consulta por CNJ faz estas requisições:

1. ``/v1/processos?page=0&numeroProcesso=<CNJ formatado>`` devolve a lista de
   processos com o ``idProcesso``, um token opaco que identifica o processo
   nas rotas seguintes.
2. ``/v1/processos/<id>/dados`` traz os metadados (classe, assunto, órgão).
3. ``poloAtivo``, ``poloPassivo``, ``outrosInteressados``, ``movimentacoes`` e
   ``documentos`` são paginados. O parâmetro ``page`` é 0-based, enquanto
   ``pageInfo.current`` e ``pageInfo.last`` são 1-based: ``page=0`` devolve
   ``current=1``, e a última página é ``page=last-1``.

O token muda a cada busca, mas continua válido em outra sessão, então o
download das peças não precisa repetir a busca.

A aplicação envia em toda chamada o cabeçalho ``x-pagina-origem`` com a URL da
tela que fez a chamada; :func:`build_pagina_origem_headers` o reproduz. O
Akamai na frente do portal segura sem resposta as requisições sem TLS de
navegador, por isso a sessão usa :data:`API_HEADERS` e o transporte de
:mod:`._tls`.
"""
# pylint: disable=protected-access
from __future__ import annotations

import logging
import re
import time
from typing import Any, TypeGuard

import requests

from ...core.exceptions import BotChallengeBlockedError, RetryExhaustedError
from ...core.http import RequestFn
from .._trf.download import BROWSER_HEADERS, _check_bot_challenge

logger = logging.getLogger("juscraper.trf3")

#: Sigla usada nas mensagens de erro e de log. O módulo serve só ao TRF3.
TRIBUNAL = "TRF3"

BASE_URL_1G = "https://pje1g-consultapublica.trf3.jus.br"
BASE_URL_2G = "https://pje2g-consultapublica.trf3.jus.br"
PROCESSOS_PATH = "/v1/processos"
DOCUMENTOS_PATH = "/v1/documentos"

# Alfabeto dos tokens opacos da API (``idProcesso`` e ``id`` dos documentos)
# observado nos samples: base64 para URL, sem ``=``. Os dois tokens vêm do
# servidor e entram em URL; o do documento vira também nome de arquivo. Aceitar
# ``/`` ou ``.`` deixaria uma resposta com ``../`` ou caminho absoluto gravar
# fora do diretório do processo ou desviar a requisição para outra rota. O
# teto de comprimento existe pelo nome de arquivo: os tokens observados têm de
# 64 a 68 caracteres, e ``<token>.pdf`` acima de 255 bytes é recusado pelo
# sistema de arquivos na hora de gravar, depois de a peça já ter sido baixada.
_TOKEN_RE = re.compile(r"[A-Za-z0-9_-]{1,200}")


def token_valido(valor: object) -> TypeGuard[str]:
    """Diz se ``valor`` é um token da API (``idProcesso`` ou ``id`` de documento) seguro para URL e arquivo."""
    return isinstance(valor, str) and _TOKEN_RE.fullmatch(valor) is not None


#: Recursos paginados de um processo, na ordem em que são baixados. As chaves
#: são os nomes das rotas e também as chaves do dicionário bruto devolvido por
#: :func:`baixar_processo`.
RECURSOS_PAGINADOS: tuple[str, ...] = (
    "poloAtivo",
    "poloPassivo",
    "outrosInteressados",
    "movimentacoes",
    "documentos",
)

# Cabeçalhos de uma chamada XHR do navegador. Os de navegação de página
# (``Upgrade-Insecure-Requests``, ``Sec-Fetch-User``) saem, e os ``Sec-Fetch-*``
# passam a descrever uma chamada ``cors`` da própria origem, como faz o Chrome
# ao executar a aplicação Angular.
API_HEADERS: dict[str, str] = {
    **{
        chave: valor
        for chave, valor in BROWSER_HEADERS.items()
        if chave not in ("Upgrade-Insecure-Requests", "Sec-Fetch-User")
    },
    "Accept": "application/json, text/plain, */*",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-origin",
}


def build_pagina_origem_headers(base_url: str, rota: str) -> dict[str, str]:
    """Monta o cabeçalho ``x-pagina-origem`` que a aplicação envia em toda chamada.

    ``rota`` é a rota da tela que dispara a chamada: ``"/"`` para a busca,
    ``"/processo/<id>"`` para o detalhe.
    """
    return {"x-pagina-origem": f"{base_url}{rota}", "Referer": f"{base_url}{rota}"}


def build_busca_params(numero_processo: str, page: int = 0) -> dict[str, Any]:
    """Monta a query string da busca por número de processo.

    ``numero_processo`` vai com máscara (``NNNNNNN-DD.AAAA.J.TR.OOOO``), como a
    aplicação envia.
    """
    return {"page": page, "numeroProcesso": numero_processo}


def busca_url(base_url: str) -> str:
    """URL da busca de processos."""
    return f"{base_url}{PROCESSOS_PATH}"


def recurso_url(base_url: str, id_processo: str, recurso: str) -> str:
    """URL de um recurso do processo (``dados`` ou um de :data:`RECURSOS_PAGINADOS`)."""
    return f"{base_url}{PROCESSOS_PATH}/{id_processo}/{recurso}"


def documento_download_url(base_url: str, id_documento: str) -> str:
    """URL que devolve o PDF de um documento do processo."""
    return f"{base_url}{DOCUMENTOS_PATH}/{id_documento}/download"


# Marca do 403 que o Akamai devolveu à API em 15/11/2026, quando o sensor de
# bot não liberou o cliente: a página ``403 Forbidden`` do nginx com os scripts
# do sensor e o contêiner do desafio. Não traz ``Access Denied``, então
# :func:`_check_bot_challenge` não a reconhece.
_MARCA_SENSOR_AKAMAI = b'id="sec-overlay"'


def guarda_akamai(resp: requests.Response) -> None:
    """Levanta :class:`BotChallengeBlockedError` no 403 do Akamai, na consulta e no ``cjsg``.

    Reconhece o ``Access Denied`` e a página do sensor de bot. Um 403 com
    outro corpo segue para o retry do ``HTTPScraper``.
    """
    _check_bot_challenge(resp, TRIBUNAL)
    if resp.status_code == 403 and _MARCA_SENSOR_AKAMAI in resp.content:
        raise BotChallengeBlockedError(TRIBUNAL, resp.url)


def _get_json(
    request_fn: RequestFn,
    url: str,
    *,
    base_url: str,
    rota: str,
    params: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Faz um ``GET`` na API e devolve o envelope JSON.

    Raises:
        BotChallengeBlockedError: 403 do Akamai (``Access Denied`` ou sensor de bot).
        ValueError: Envelope com ``status`` diferente de ``"ok"``.
    """
    resp = request_fn(
        "GET",
        url,
        params=params,
        headers=build_pagina_origem_headers(base_url, rota),
        perfil="api",
        on_response=guarda_akamai,
    )
    data: dict[str, Any] = resp.json()
    if data.get("status") != "ok":
        raise ValueError(f"{TRIBUNAL}: resposta da API com status {data.get('status')!r} em {url}: {data}")
    return data


def buscar_processo(request_fn: RequestFn, base_url: str, numero_processo: str) -> dict[str, Any]:
    """Busca o processo pelo número e devolve o envelope da busca."""
    return _get_json(
        request_fn,
        busca_url(base_url),
        base_url=base_url,
        rota="/",
        params=build_busca_params(numero_processo),
    )


def baixar_recurso_paginado(
    request_fn: RequestFn,
    base_url: str,
    id_processo: str,
    recurso: str,
    *,
    sleep_time: float = 0.0,
) -> list[dict[str, Any]]:
    """Baixa todas as páginas de um recurso paginado do processo.

    Devolve a lista dos envelopes, uma entrada por página. A primeira página
    informa em ``pageInfo.last`` quantas páginas existem (1-based); as demais
    são pedidas com ``page`` 0-based, de ``1`` a ``last - 1``.
    """
    url = recurso_url(base_url, id_processo, recurso)
    rota = f"/processo/{id_processo}"
    primeira = _get_json(request_fn, url, base_url=base_url, rota=rota, params={"page": 0})
    paginas = [primeira]
    ultima = int((primeira.get("pageInfo") or {}).get("last") or 1)
    for page in range(1, ultima):
        if sleep_time:
            time.sleep(sleep_time)
        paginas.append(_get_json(request_fn, url, base_url=base_url, rota=rota, params={"page": page}))
    return paginas


def _escolher_processo(busca: dict[str, Any], numero_processo: str) -> dict[str, Any] | None:
    """Escolhe, entre os resultados da busca, o processo com o número pedido.

    A busca por número devolve no máximo um processo nos casos observados; a
    conferência pelo número evita aceitar um resultado de outro processo se a
    API passar a fazer busca aproximada. Se mais de um resultado tiver o
    número pedido, fica o primeiro e os demais são descartados com aviso no
    log: a saída tem uma linha por CNJ, e o aviso é o que permite notar que a
    consulta pública tinha mais de um processo para aquele número.
    """
    resultados: list[dict[str, Any]] = busca.get("result") or []
    iguais = [item for item in resultados if item.get("numeroProcesso") == numero_processo]
    if len(iguais) > 1:
        logger.warning(
            "%s: a busca de %s devolveu %d processos com esse número; só o primeiro é consultado",
            TRIBUNAL,
            numero_processo,
            len(iguais),
        )
    return iguais[0] if iguais else None


def baixar_processo(
    request_fn: RequestFn,
    base_url: str,
    numero_processo: str,
    *,
    sleep_time: float = 0.0,
) -> dict[str, Any] | None:
    """Baixa os envelopes brutos de um processo, ou ``None`` se a busca não o achar.

    O dicionário devolvido tem as chaves ``"busca"`` (item da busca),
    ``"dados"`` (envelope de ``/dados``) e uma chave por recurso de
    :data:`RECURSOS_PAGINADOS`, com a lista de envelopes de cada página.

    Um recurso paginado que a API responde com erro HTTP depois das
    tentativas fica ``None`` e o resto do processo segue. A API responde 500
    de forma reproduzível ao ``poloPassivo`` de alguns mandados de segurança,
    e perder o processo inteiro por isso descartaria dados que vieram certos.
    Erro de rede e erro em ``/dados`` continuam derrubando o processo.

    Raises:
        ValueError: ``idProcesso`` ausente ou recusado por
            :func:`token_valido`; nenhuma requisição de detalhe é feita.
    """
    busca = buscar_processo(request_fn, base_url, numero_processo)
    item = _escolher_processo(busca, numero_processo)
    if item is None:
        return None
    id_processo = item.get("idProcesso")
    if not token_valido(id_processo):
        raise ValueError(f"{TRIBUNAL}: idProcesso inválido na busca de {numero_processo}: {id_processo!r}")
    bruto: dict[str, Any] = {"busca": item}
    bruto["dados"] = _get_json(
        request_fn,
        recurso_url(base_url, id_processo, "dados"),
        base_url=base_url,
        rota=f"/processo/{id_processo}",
    )
    for recurso in RECURSOS_PAGINADOS:
        try:
            bruto[recurso] = baixar_recurso_paginado(request_fn, base_url, id_processo, recurso, sleep_time=sleep_time)
        except (RetryExhaustedError, requests.HTTPError) as exc:
            logger.warning("%s: %s de %s falhou: %s", TRIBUNAL, recurso, numero_processo, exc)
            bruto[recurso] = None
    return bruto


def baixar_documento(
    request_fn: RequestFn,
    base_url: str,
    id_documento: str,
    id_processo: str,
) -> bytes:
    """Baixa o PDF de um documento do processo.

    A rota responde 415 sem ``Content-Type: application/json``, mesmo sendo
    ``GET``; a aplicação manda esse cabeçalho junto com ``Accept:
    application/pdf``. Documentos de texto (``binario=False``) e arquivos
    anexados (``binario=True``) saem em PDF pela mesma rota.

    Raises:
        BotChallengeBlockedError: 403 do Akamai (``Access Denied`` ou sensor de bot).
        ValueError: Token recusado por :func:`token_valido` (nenhuma
            requisição é feita) ou resposta sem ``Content-Type`` de PDF.
    """
    for nome, token in (("id_documento", id_documento), ("id_processo", id_processo)):
        if not token_valido(token):
            raise ValueError(f"{TRIBUNAL}: {nome} inválido: {token!r}")
    url = documento_download_url(base_url, id_documento)
    headers = {
        **build_pagina_origem_headers(base_url, f"/processo/{id_processo}"),
        "Content-Type": "application/json",
        "Accept": "application/pdf",
    }
    resp = request_fn("GET", url, headers=headers, perfil="documento", on_response=guarda_akamai)
    content_type = resp.headers.get("Content-Type", "")
    if "application/pdf" not in content_type:
        raise ValueError(f"{TRIBUNAL}: documento {id_documento} veio como {content_type!r}, não PDF")
    return resp.content
