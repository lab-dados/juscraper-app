"""Shared pydantic schemas for juscraper public APIs (refs #93)."""
from .cjsg import OutputCJSGBase, SearchBase
from .consulta import CnjInputBase, OutputCnjConsultaBase
from .mixins import (
    AutoChunkMixin,
    CountOnlyMixin,
    DataJulgamentoMixin,
    DataPublicacaoMixin,
    OutputDataPublicacaoMixin,
    OutputRelatoriaMixin,
    PaginasMixin,
)
from .types import BuscarEm, IdFiltro, IdFiltroUnico, InteiroSemBool, TamanhoPagina

__all__ = [
    "AutoChunkMixin",
    "BuscarEm",
    "CnjInputBase",
    "CountOnlyMixin",
    "DataJulgamentoMixin",
    "DataPublicacaoMixin",
    "IdFiltro",
    "IdFiltroUnico",
    "InteiroSemBool",
    "OutputCJSGBase",
    "OutputCnjConsultaBase",
    "OutputDataPublicacaoMixin",
    "OutputRelatoriaMixin",
    "PaginasMixin",
    "SearchBase",
    "TamanhoPagina",
]
